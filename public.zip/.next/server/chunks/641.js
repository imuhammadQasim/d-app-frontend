exports.id=641,exports.ids=[641],exports.modules={7036:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/avatar.1ff73c68.png",height:500,width:500,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAANlBMVEVMaXFXSDyojXlpWEkQEA0eGxgrKSYMBgYDAAA4My22mYR5ZFSZf2mPdVsqKSh6aVvRsJnCo4xLBgk4AAAAD3RSTlMA5/yWMlfDDh3m/PfUJ9x+TavdAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAOElEQVR4nEWLORLAIAzExG2TgOH/n2WcFGyjQlq4y3UWZwvRtAHyrBUEGLHv15WoWfriojX/Ny85JOoBCjsikUsAAAAASUVORK5CYII=",blurWidth:8,blurHeight:8}},8905:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/body-img.20bce35f.png",height:1929,width:1929,blurDataURL:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAElBMVEVMaXGU/5SO/46U/5SX/5eY/5j7E4w1AAAABnRSTlMAGQs+Zz4Rf10yAAAACXBIWXMAABCcAAAQnAEmzTo0AAAAJ0lEQVR4nGNgQAAmRkYmCM3MDGYxMrOwMDNCGawgBhMjK0QKrhgKAApCAEkh79bqAAAAAElFTkSuQmCC",blurWidth:8,blurHeight:8}},190:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/dashboard-icon.141bff41.svg",height:18,width:18,blurWidth:0,blurHeight:0}},624:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/down-arrow.450e133c.svg",height:5,width:10,blurWidth:0,blurHeight:0}},9125:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/inProcess-gif.2c73fac6.gif",height:500,width:500,blurWidth:0,blurHeight:0}},1970:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/logo-sm.ec094c7b.svg",height:27,width:28,blurWidth:0,blurHeight:0}},1501:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/logo.d85d3915.svg",height:27,width:232,blurWidth:0,blurHeight:0}},1348:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/logout-icon.acacb6bb.svg",height:19,width:18,blurWidth:0,blurHeight:0}},2225:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/menu-icon.3535b374.svg",height:26,width:26,blurWidth:0,blurHeight:0}},8761:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/notification-icon.60eb5ef3.svg",height:19,width:18,blurWidth:0,blurHeight:0}},1610:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/privacy-icon.0b08dc5a.svg",height:16,width:16,blurWidth:0,blurHeight:0}},9499:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/request-successful-gif.e6835e4e.gif",height:505,width:500,blurWidth:0,blurHeight:0}},7283:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/settings-icon.401b7d29.svg",height:16,width:16,blurWidth:0,blurHeight:0}},3933:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/terms-icon.d8ed0082.svg",height:16,width:16,blurWidth:0,blurHeight:0}},5931:(e,t,i)=>{"use strict";i.d(t,{A:()=>a});let a={src:"/_next/static/media/wallet-icon.b8a774cf.svg",height:19,width:18,blurWidth:0,blurHeight:0}},95:(e,t,i)=>{"use strict";i.d(t,{A:()=>o});var a=i(8732);i(2015);var r=i(2770),n=i.n(r);let s=n().button`
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: ${({$gap:e})=>e||"5px"};
  padding: 12px 15px;
  border-radius: ${({$rounded:e})=>e?"60px":"8px"};
  font-size: 14px;
  line-height: 18px;
  font-weight: 400;
  width: ${({$width:e})=>e||"140px"};
  min-width: 140px;
  background: var(--off-white);
  color: var(--secondary);
  transition: 0.5s all ease-in-out;
  box-shadow: 0px 4px 3px 0px #ffffff45 inset, 0px -3px 5px 0px #ffffff40 inset;
  overflow: hidden;
  z-index: 1;

  @media (min-width: 768px) {
    font-size: 15px;
    line-height: 19px;
  }

  ${({$loader:e,disabled:t})=>e||t&&(0,r.css)`
        cursor: not-allowed;
      `}

  ${({$lg:e})=>e&&(0,r.css)`
      width: ${({$width:e})=>e||"200px"};
      padding: 15px;
    `}

  @media screen and (max-width:786px) {
    padding: 8px 15px;
  }
  /***** Background-Variants-Start *****/

  ${({$variant:e})=>"secondary"==e&&(0,r.css)`
        background: var(--primary);
        color: var(--secondary);
      `||"outline"==e&&(0,r.css)`
        background: var(--white);
        border: 1px solid var(--primary);
        color: var(--primary);
      `||"danger"==e&&(0,r.css)`
        background: var(--danger);
        color: var(--text-color);
      `}

  /*****************Background Variants End*********************/


  /*****************Border Variants Start*********************/

  ${({$outline:e})=>e&&(0,r.css)`
      border: 1px solid var(--blue);
      background: transparent;
      color: var(--blue);
    `}
  /*****************Border Variants End*********************/

    .loader {
    width: 17px;
    height: 17px;
    border-radius: 50%;
    display: inline-block;
    border-top: 3px solid var(--secondary);
    border-right: 3px solid transparent;
    box-sizing: border-box;
    animation: rotation 1s linear infinite;
  }

  @keyframes rotation {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }

  &:before,
  &:after {
    content: "";
    position: absolute;
    height: 1px;
    width: 1px;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    border-radius: 50%;
    z-index: -1;
  }

  &:before {
    display: none;
    background: var(--secondary);
    transition: 0.6s ease-in;
    transition-delay: 0.1s;
  }

  &:after {
    background: var(--primary);
    transition: 0.8s ease;
    transition-delay: 0.4s;

    ${({$variant:e})=>"secondary"==e&&(0,r.css)`
        background: var(--white);
      `}

    ${({$variant:e})=>"danger"==e&&(0,r.css)`
        background: #dc4320;
      `}
  }

  &:hover {
    &:before,
    &:after {
      transform: translate(-50%, -50%) scale(1000);
      z-index: -1;
    }
  }
`,o=({children:e,gap:t,lg:i,outline:r,variant:n,width:o,loader:l,disabled:d,rounded:c,delayAnimation:h,...p})=>(0,a.jsx)(s,{$lg:i,$outline:r,$variant:n,$gap:t,$width:o,$delayAnimation:h,$rounded:c,disabled:l||d,...p,children:l?(0,a.jsx)("span",{className:"loader"}):e})},7129:(e,t,i)=>{"use strict";i.d(t,{h:()=>n});var a=i(2770),r=i.n(a);let n=r().header`
    display: flex;
    align-items: center;
    justify-content: flex-end;
    position: fixed;
    top: 10px;
    left: 10px;
    right: 10px;
    padding: 10px 15px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 16px;
    backdrop-filter: blur(200px);
    z-index: 99;
    transition: 0.3s;

    @media (min-width: 768px) {
        justify-content: space-between;
        padding: 17px;
    }

    .scrolled & {
        top: 0;
        left: 0;
        right: 0;
        border-radius: 0;
        border-top: 0;
        border-left: 0;
        border-right: 0;
    }

    .logo-holder {
        width: 100%;
        max-width: 230px;
        display: none;
        cursor: pointer;
        @media (min-width: 768px) {
            display: block;
        }

        img {
            display: block;
            width: 100%;
            height: auto;
        }
    }

    .logo-sm {
        width: 30px;
        height: 30px;
        display: block;

        @media (min-width: 768px) {
            display: none;
        }

        img {
            width: 100%;
            height: auto;
            object-fit: cover;
        }
    }

    .user-info,
    .head,
    .dropdown-item,
    .logout {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .user-image {
        width: 50px;
        height: 50px;
        flex-shrink: 0;
        border-radius: 50%;
        background: var(--primary);
        overflow: hidden;

        img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    }

    .user-name {
        display: block;
        font-weight: 600;
    }

    .pages-holder {
        display: none;

        @media (min-width: 768px) {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page,
        .notification,
        .logout {
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--dark);
            border-radius: 10px;
            width: 40px;
            height: 40px;
            overflow: hidden;
            transition: 0.4s;

            .text {
                display: none;
                font-weight: 500;
            }

            &.active {
                width: max-content;
                background: var(--primary);
                color: var(--secondary);
                padding: 10px 12px;
                gap: 5px;

                img {
                    filter: invert(20%) sepia(9%) saturate(2959%) hue-rotate(106deg) brightness(61%) contrast(105%);
                }

                .text {
                    display: block;
                }
            }
        }

        .notification,
        .logout {
            cursor: pointer;

            &:hover {
                background: var(--primary);
                color: var(--secondary);
                img {
                    filter: invert(20%) sepia(9%) saturate(2959%) hue-rotate(106deg) brightness(61%) contrast(105%);
                }
            }
        }

        .user-info {
            position: relative;
            cursor: pointer;

            .arrow {
                width: 13px;
                height: 13px;
                flex-shrink: 0;
                transform: scale(1);
                transition: 0.3s all ease-in-out;
            }

            &.active {
                .arrow {
                    transform: scale(-1);
                }

                .dropdown {
                    visibility: visible;
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        }

        .dropdown {
            width: 250px;
            position: absolute;
            top: 60px;
            right: 0;
            background: var(--dark);
            padding: 12px;
            border: 1px solid var(--dark-100);
            border-radius: 12px;
            transform: translateY(10px);
            visibility: hidden;
            opacity: 0;
            transition: 0.3s all ease-in-out;

            .head {
                padding: 0 0 10px;
                border-bottom: 1px solid var(--dark-100);
                margin: 0 0 12px;

                a {
                    font-size: 14px;
                    line-height: 18px;
                }
            }

            .dropdown-item {
                padding: 10px 12px;
                border-radius: 8px;
                transition: 0.3s ease-in-out;

                &:not(:last-child) {
                    margin: 0 0 10px;
                }

                &.active,
                &:hover {
                    background: var(--dark-150);
                }
            }
        }
    }

    .menu-icon {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        left: 15px;
        display: block;

        @media (min-width: 768px) {
            display: none;
        }
    }

    .nav-links {
        width: 260px;
        height: 90vh;
        position: fixed;
        top: 60px;
        left: -100%;
        background: #eaffea;
        display: flex;
        flex-direction: column;
        padding: 30px 20px;
        border-radius: 0 20px 20px 0;
        transition: all 0.4s ease-in-out;
        color: var(--text-color);
        overflow: hidden;

        @media (min-width: 768px) {
            display: none;
        }

        ul,
        .logout {
            img {
                width: 20px;
                height: 20px;
                filter: invert(15%) sepia(8%) saturate(17%) hue-rotate(350deg) brightness(20%) contrast(88%);
            }
        }

        ul {
            flex-grow: 1;
            border-bottom: 1px solid #c5d6c5;
            margin: 0 0 15px;

            li {
                display: flex;
                align-items: center;
                gap: 10px;

                padding: 15px;
                border-radius: 10px;

                &:hover,
                &.active {
                    color: var(--secondary);
                    background: var(--white);
                    font-weight: 500;

                    img {
                        filter: invert(20%) sepia(9%) saturate(2959%) hue-rotate(106deg) brightness(50%) contrast(105%);
                    }
                }
            }
        }

        .head {
            margin: 0 0 20px;

            a {
                font-size: 14px;
                line-height: 18px;
            }
        }

        .logout {
            background: #fff7cc;
            padding: 13px 16px;
        }
    }

    .nav-active & {
        .nav-links {
            left: -12px;
        }
    }
`},7070:(e,t,i)=>{"use strict";i.a(e,async(e,a)=>{try{i.d(t,{A:()=>O});var r=i(8732),n=i(2015),s=i(7129),o=i(1501),l=i(190),d=i(5931),c=i(8761),h=i(1348),p=i(7036),u=i(624),x=i(1610),g=i(3933),m=i(7283),f=i(2225),b=i(1970),w=i(9965),v=i.n(w),y=i(1106),A=i.n(y),j=i(6424);i(95);var k=i(6715),E=i(1550),_=i(8271),C=i(1540),T=e([C]);C=(T.then?(await T)():T)[0];let N=[{icon:x.A,label:"Privacy Policy",href:"/privacy-policy"},{icon:g.A,label:"Terms & Conditions",href:"/terms-and-conditions"},{icon:m.A,label:"settings",href:"/settings"}],I=[{icon:l.A,label:"Dashboard",link:"/"},{icon:d.A,label:"My Wallet",link:"/my-wallet"},{icon:g.A,label:"Terms & Conditions",link:"/terms-and-conditions"},{icon:x.A,label:"Privacy Policy",link:"/privacy-policy"},{icon:c.A,label:"Notifications",link:"/notifications"},{icon:m.A,label:"Settings",link:"/settings"}],O=()=>{let e=(0,k.useRouter)(),t=(0,j.usePathname)(),i=(0,n.useRef)(null),[a,x]=(0,n.useState)(!1),[g,m]=(0,n.useState)(null);function w(){(0,E.o7)("intd_d"),e.push("/login")}return(0,n.useEffect)(()=>{},[i]),(0,n.useEffect)(()=>{},[e]),(0,n.useEffect)(()=>{(async()=>{try{let e=await _.A.fetchUserDetails();m(e),console.log(e)}catch(e){(0,C.A)({type:"error",message:g.message})}})()},[]),(0,r.jsxs)(s.h,{ref:i,children:[(0,r.jsx)("figure",{className:"menu-icon",onClick:function(){},children:(0,r.jsx)(v(),{src:f.A,alt:"menuIcon"})}),(0,r.jsx)("figure",{className:"logo-holder",onClick:()=>e.push("/"),children:(0,r.jsx)(v(),{src:o.A,alt:"IntD Logo"})}),(0,r.jsx)("figure",{className:"logo-sm",children:(0,r.jsx)(v(),{src:b.A,alt:"IntD Logo"})}),(0,r.jsxs)("div",{className:"pages-holder",children:[(0,r.jsxs)(A(),{href:"/",className:"/"===t?"page active":"page",children:[(0,r.jsx)(v(),{src:l.A,alt:"Dashboard Icon"}),(0,r.jsx)("span",{className:"text",children:"Dashboard"})]}),(0,r.jsxs)(A(),{href:"/my-wallet",className:"/my-wallet"===t?"page active":"page",children:[(0,r.jsx)(v(),{src:d.A,alt:"Wallet Icon"}),(0,r.jsx)("span",{className:"text",children:"My Wallet"})]}),(0,r.jsx)("div",{className:"notification",children:(0,r.jsx)(v(),{src:c.A,alt:"Notification Icon"})}),(0,r.jsx)("div",{className:"logout",onClick:()=>w(),children:(0,r.jsx)(v(),{src:h.A,alt:"Logout Icon"})}),(0,r.jsxs)("div",{className:a?"user-info active":"user-info",onClick:()=>x(!a),children:[(0,r.jsx)("figure",{className:"user-image",children:(0,r.jsx)(v(),{src:p.A,alt:"avatar",width:100,height:100})}),(0,r.jsxs)("span",{className:"user-name",children:[g?.user?.first_name," ",(0,r.jsx)("br",{})," ",g?.user?.last_name]}),(0,r.jsx)(v(),{src:u.A,alt:"downArrow",className:"arrow"}),(0,r.jsxs)("div",{className:"dropdown",children:[(0,r.jsxs)("div",{className:"head",children:[(0,r.jsx)("figure",{className:"user-image",children:(0,r.jsx)(v(),{src:p.A,alt:"avatar",width:100,height:100})}),(0,r.jsxs)("div",{children:[(0,r.jsxs)("span",{className:"user-name",children:[g?.user?.first_name," ",g?.user?.last_name]}),(0,r.jsx)(A(),{href:"mailto:Kylemachar@gmail.com",children:g?.user?.email})]})]}),N?.map((e,i)=>r.jsxs(A(),{href:e.href,className:`dropdown-item ${t===e.href?"active":""}`,children:[r.jsx(v(),{src:e.icon,alt:e.label}),r.jsx("span",{children:e.label})]},i))]})]})]}),(0,r.jsxs)("div",{className:"nav-links",children:[(0,r.jsxs)("div",{className:"head",children:[(0,r.jsx)("figure",{className:"user-image",children:(0,r.jsx)(v(),{src:p.A,alt:"avatar",width:100,height:100})}),(0,r.jsxs)("div",{children:[(0,r.jsx)("span",{className:"user-name",children:"Kyle Machar"}),(0,r.jsx)(A(),{href:"mailto:Kylemachar@gmail.com",children:"Kylemachar@gmail.com"})]})]}),(0,r.jsx)("ul",{children:I?.map((e,i)=>r.jsx(A(),{href:e?.link,children:r.jsxs("li",{className:t==e.link&&"active",children:[r.jsx(v(),{src:e.icon,alt:e.label}),r.jsx("span",{children:e.label})]})}))}),(0,r.jsxs)("button",{className:"logout",onClick:()=>w(),children:[(0,r.jsx)(v(),{src:h.A,alt:"Logout Icon"}),"Logout"]})]})]})};a()}catch(e){a(e)}})},4906:(e,t,i)=>{"use strict";i.a(e,async(e,a)=>{try{i.d(t,{A:()=>u});var r=i(8732),n=i(2015),s=i(7070),o=i(6424),l=i(8905),d=i(3200),c=i(9965),h=i.n(c),p=e([s,d]);[s,d]=p.then?(await p)():p;let u=({children:e})=>{let t=(0,o.usePathname)(),i=["/","/my-wallet","/buy-intd","/settings","/update-name","/update-password","/transfer-details","/donate-money","/privacy-policy","/terms-and-conditions","/initiate-investment","/get-help"].includes(t);return(0,n.useEffect)(()=>{let e=()=>{window.scrollY>50?document.body.classList.add("scrolled"):document.body.classList.remove("scrolled")};return window.addEventListener("scroll",e),()=>{window.removeEventListener("scroll",e)}},[]),(0,r.jsx)(d.StyledLayout,{children:i?(0,r.jsxs)("div",{id:"wrapper",children:[(0,r.jsx)("span",{className:"overlay"}),(0,r.jsx)(h(),{src:l.A,alt:"bg",className:"bg"}),(0,r.jsx)(s.A,{}),(0,r.jsx)("div",{children:e})]}):(0,r.jsx)("div",{children:e})})};a()}catch(e){a(e)}})},2288:(e,t,i)=>{"use strict";i.d(t,{A:()=>o});var a=i(8732);i(2015);var r=i(2770),n=i.n(r);let s=n().div`
  position: fixed;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.8);
  z-index: 9999;

  .loader {
    display: block;
    position: relative;
    width: 60px;
    height: 60px;
    background: #fff;
    border-radius: 50%;
    overflow: hidden;
  }
  .loader:after {
    content: "";
    position: absolute;
    inset: 8px;
    margin: auto;
    background: rgba(0, 0, 0, 1);
    border-radius: 50%;
  }
  .loader:before {
    content: "";
    position: absolute;
    inset: 0px;
    margin: auto;
    background: var(--primary);
    animation: crlMugLoader 2s linear infinite alternate;
  }
  @keyframes crlMugLoader {
    0%,
    10% {
      transform: translateY(64px);
    }
    90%,
    100% {
      transform: translateY(0px);
    }
  }
`,o=()=>(0,a.jsx)(s,{children:(0,a.jsx)("span",{class:"loader"})})},2461:(e,t,i)=>{"use strict";i.d(t,{A:()=>f});var a=i(8732),r=i(2015),n=i(2770),s=i.n(n);let o=s().div`
  height: 100vh;
  display: flex;
  align-items: center;
  text-align: center;
  padding: 0 20px;
  height: calc(100vh - 95px);

  @media (min-width: 768px) {
    height: calc(100vh - 105px);
  }

  .gif-holder {
    width: 90px;
    height: 90px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 247, 204, 0.1);
    border-radius: 100px;
    margin: 0 auto 15px;
    @media (min-width: 576px) {
      width: 120px;
      height: 120px;
      margin: 0 auto 25px;
    }
    @media (min-width: 768px) {
      width: 150px;
      height: 150px;
      margin: 0 auto 35px;
    }

    img {
      width: 70px;
      height: 70px;
      @media (min-width: 576px) {
        width: 90px;
        height: 90px;
      }
      @media (min-width: 768px) {
        width: 110px;
        height: 110px;
      }
    }
  }

  .heading {
    display: block;
    font-size: 28px;
    line-height: 34px;
    font-weight: 700;
    margin: 0 0 15px;
    @media (min-width: 768px) {
      font-size: 34px;
      line-height: 38px;
    }
  }

  .text {
    display: block;
    white-space: pre-line;
    margin: 0 0 20px;
    @media (min-width: 768px) {
      margin: 0 0 30px;
    }
  }

  .error {
    width: 100%;
    max-width: 280px;
    font-size: 12px;
    line-height: 16px;
    font-weight: 500;
    display: flex;
    align-items: center;
    background: var(--off-white);
    color: var(--text-color);
    gap: 5px;
    padding: 6px 16px;
    border-radius: 8px;
    margin: 0 auto 16px;
  }

  button {
    @media (max-width: 575px) {
      width: 100%;
    }
  }

  .btn-holder {
    margin: 0 0 16px;
  }

  .back-btn {
    button {
      color: var(--white);
    }
  }
`,l=s().div`
  content: "";
  width: 225px;
  height: 10px;
  background: var(--text-color);
  border-radius: 3px;
  margin: 0 auto;
  position: relative;

  &:before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    width: ${({$progress:e})=>e&&e};
    background: var(--primary);
    border-radius: 3px;
  }
`,d={src:"/_next/static/media/note-icon.a661424a.svg",height:18,width:18,blurWidth:0,blurHeight:0};var c=i(9965),h=i.n(c),p=i(95),u=i(9125),x=i(9499);let g={src:"/_next/static/media/error-gif.27e78fbe.gif",height:500,width:500,blurWidth:0,blurHeight:0};var m=i(9926);let f=({data:e})=>{let[t,i]=(0,r.useState)(0),{setProcess:n}=(0,r.useContext)(m.w);return(0,r.useEffect)(()=>{if(e?.inProcess){i(0);let e=setInterval(()=>{i(t=>t>=90?(clearInterval(e),t):t+10)},100);return()=>clearInterval(e)}i(100)},[e?.inProcess]),(0,a.jsx)(o,{children:(0,a.jsxs)("div",{className:"container",children:[(0,a.jsx)("div",{className:"gif-holder",children:e?.type==="success"?(0,a.jsx)(h(),{src:x.A,alt:"gif"}):e?.type==="error"?(0,a.jsx)(h(),{src:g,alt:"gif"}):(0,a.jsx)(h(),{src:u.A,alt:"gif"})}),(0,a.jsx)("span",{className:"heading",children:e?.heading}),(0,a.jsx)("span",{className:"text",children:e?.text}),e?.error&&(0,a.jsxs)("div",{className:"error",children:[(0,a.jsx)(h(),{src:d,alt:"noteIcon"}),(0,a.jsx)("span",{children:"Password reset request error (ERROR 404)"})]}),e?.inProcess?(0,a.jsx)(l,{$progress:`${t}%`}):(0,a.jsxs)(a.Fragment,{children:[e?.btnText&&(0,a.jsx)("div",{className:"btn-holder",children:(0,a.jsx)(p.A,{width:"350px",variant:e?.variant,onClick:()=>{var t;return t=e?.onClick,void(n(!1),t())},children:e?.btnText})}),e?.backBtn&&(0,a.jsx)("div",{className:"back-btn",onClick:e?.backBtn,children:(0,a.jsx)("button",{children:"Go Back!"})})]})]})})}},3834:(e,t,i)=>{"use strict";i.d(t,{A:()=>c});var a=i(8732);i(2015);var r=i(3563),n=i(2965),s=i(9292),o=i(2770),l=i.n(o);let d=l().span`
  font-size: 1.625rem;
  line-height: 1;
  margin-right: 1.125rem;
`,c=({$type:e})=>(0,a.jsx)(d,{$type:e,children:(0,a.jsx)("span",{className:"material-icons-outlined",children:(()=>{switch(e){case"error":return(0,a.jsx)(r.TCu,{});case"info":default:return(0,a.jsx)(n.Q9E,{});case"warning":return(0,a.jsx)(s.ZBh,{});case"success":return(0,a.jsx)(s.qxq,{})}})()})})},2207:(e,t,i)=>{"use strict";i.d(t,{Q:()=>s,c:()=>n});var a=i(2770),r=i.n(a);let n=r().div`
    width: 100%;
    border-radius: 8px;
    padding: 1rem;
    display: flex;
    align-items: center;
    font-size: var(--font-size-sm);
    line-height: calc(var(--font-size-sm) + 0.3125rem);
    @media (min-width: 768px) {
        padding: 1rem 3.9375rem 1rem 1rem;
    }

    ${({$type:e})=>"success"===e&&(0,a.css)`
            color: var(--secondary);
            background: #97fa93;
        `}

    ${({$type:e})=>"info"===e&&(0,a.css)`
            color: var(--info-text);
            background: var(--info);
        `}

    ${({$type:e})=>"error"===e&&(0,a.css)`
            color: var(--danger-100);
            background: #fef0f4;
        `}

    ${({$type:e})=>"warning"===e&&(0,a.css)`
            color: var(--warning);
            background: #fffaf2;
        `}
`,s=r().p`
    color: inherit;
    margin: 0;
`},1540:(e,t,i)=>{"use strict";i.a(e,async(e,a)=>{try{i.d(t,{A:()=>d});var r=i(8732);i(2015);var n=i(4391),s=i(2207),o=i(3834),l=e([n]);n=(l.then?(await l)():l)[0];let d=function({type:e,message:t,...i}){return(0,n.toast)((0,r.jsxs)(s.c,{$type:e,...i,children:[(0,r.jsx)(o.A,{$type:e}),(0,r.jsx)(s.Q,{$type:e,children:t})]}),{hideProgressBar:!0,autoClose:2e3,...i})};a()}catch(e){a(e)}})},120:(e,t,i)=>{"use strict";i.a(e,async(e,a)=>{try{i.d(t,{c:()=>h,h:()=>p});var r=i(8732),n=i(1540),s=i(1550),o=i(8271),l=i(6715),d=i(2015),c=e([n]);n=(c.then?(await c)():c)[0];let h=(0,d.createContext)(),p=({children:e})=>{let t=(0,l.useRouter)(),[i,a]=(0,d.useState)(!!(0,s.Ri)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE)),[c,p]=(0,d.useState)(!1),u=async e=>{try{p(!0);let t=await o.A.verifyEmail(e);if(t?.token)return(0,s.TV)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE,t?.token),(0,n.A)({type:"success",message:t.message}),p(!1),!0;throw Error(t?.message)}catch(e){p(!1),(0,n.A)({type:"error",message:e.message})}},x=async({email:e,password:i})=>{p(!0);try{let r=await o.A.login({email:e,password:i});if(!r?.token)throw Error(r?.message);a(!0),(0,s.TV)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE,r?.token),p(!1);let l=await o.A.fetchUserDetails();return l?.user?.status==="VERIFY_EMAIL"&&(t.push("/verify-email"),(0,n.A)({type:"info",message:"Pleader Verify Your Email"})),l?.user?.status==="KYC_VERIFICATION"&&(t.push("/kyc-verification"),(0,n.A)({type:"info",message:"Pleader Verify Your KYC"})),l?.user?.status==="KYC_VERIFICATION_INITIATED"&&t.push("/kyc-verification-pending"),l?.user?.status==="ACTIVE"&&(t.push("/"),(0,n.A)({type:"success",message:"Login Successfully"})),!0}catch({message:e}){return a(!1),(0,n.A)({type:"error",message:e}),!1}finally{p(!1)}};return(0,r.jsx)(h.Provider,{value:{loading:c,verifyEmail:u,onLogin:x,isLoggedIn:i},children:e})};a()}catch(e){a(e)}})},9926:(e,t,i)=>{"use strict";i.d(t,{N:()=>o,w:()=>s});var a=i(8732),r=i(2461),n=i(2015);let s=(0,n.createContext)(),o=({children:e})=>{let[t,i]=(0,n.useState)(!1),[o,l]=(0,n.useState)({});return(0,a.jsxs)(s.Provider,{value:{handleData:function(e){i(!0),l(e)},setProcess:i},children:[!1==t&&(0,a.jsx)(a.Fragment,{children:e}),t&&(0,a.jsx)(r.A,{data:o})]})}},8574:(e,t,i)=>{"use strict";i.d(t,{Y:()=>n,t:()=>s});var a=i(8732),r=i(2015);let n=(0,r.createContext)({}),s=({children:e})=>{let[t,i]=(0,r.useState)(!1);return(0,r.useEffect)(()=>{i(!1);let e=setTimeout(()=>{i(!1)},1e3);return()=>clearTimeout(e)},[]),(0,a.jsx)(n.Provider,{value:{loading:t},children:e})}},1550:(e,t,i)=>{"use strict";i.d(t,{Ri:()=>r,TV:()=>a,o7:()=>n,sg:()=>o,wR:()=>s}),i(8732),i(2770);let a=(e,t,i,a)=>{let r="";if(i){let e=new Date;e.setTime(e.getTime()+864e5*i),r=`; expires=${e.toUTCString()}`}let n=a?`; domain=${a}`:"";return document.cookie=`${e}=${t||""}${r}; path=/${n}`,!0},r=e=>{let t=`${e}=`,i="undefined"!=typeof document&&document.cookie.split(";");for(let e=0;e<i.length;e++){let a=i[e];for(;" "===a.charAt(0);)a=a.substring(1,a.length);if(0===a.indexOf(t))return a.substring(t.length,a.length)}return null},n=e=>("undefined"!=typeof document?document.cookie=`${e}=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;`:console.warn("clearCookie function called in a non-browser environment"),!0),s=e=>(function(e,t){let i=new Date(e.toLocaleString("en-US",{timeZone:t})),a=e.getTime()-i.getTime();return new Date(e.getTime()-a)})(new Date(e),"Canada/Eastern"),o=(e,t)=>{let i;return(...a)=>{i&&clearTimeout(i),i=setTimeout(()=>{e(...a)},t)}}},708:(e,t,i)=>{"use strict";let a;i.r(t),i.d(t,{Fetch:()=>l});var r=i(1550);let n=!1;function s(e,t){return a&&clearTimeout(a),new Promise(i=>{a=setTimeout(()=>{fetch(e,t).then(e=>{i(o(e))})},1e3)})}function o(e){return 401===e.status&&!n&&(0,r.Ri)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE)&&(n=!0,(0,r.o7)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE),window.location.reload()),e}let l={get:function(e,t=!1){let i={method:"GET",headers:{"X-path":window.location.pathname,"Content-Type":"application/json",authorization:`Bearer ${(0,r.Ri)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE)}`}};return t?s(e,i):fetch(e,i).then(e=>o(e))},post:function(e,t,i=!1,a=!1){let n={method:"POST",headers:{"X-path":window.location.pathname,"Content-Type":"application/json",authorization:a?"Bearer intd-secret-token":`Bearer ${(0,r.Ri)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE)}`},body:JSON.stringify(t)};return i?s(e,n):fetch(e,n).then(e=>o(e))},put:function(e,t,i=!1){let a={method:"PUT",headers:{"X-path":window.location.pathname,"Content-Type":"application/json",authorization:`Bearer ${(0,r.Ri)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE)}`},body:JSON.stringify(t)};return i?s(e,a):fetch(e,a).then(e=>o(e))},delete:function(e,t,i=!1){let a={method:"DELETE",headers:{"X-path":window.location.pathname,"Content-Type":"application/json",authorization:`Bearer ${(0,r.Ri)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE)}`},body:JSON.stringify(t)};return i?s(e,a):fetch(e,a).then(e=>o(e))},patch:function(e,t,i=!1){let a={method:"PATCH",headers:{"X-path":window.location.pathname,"Content-Type":"application/json",authorization:`Bearer ${(0,r.Ri)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE)}`},body:JSON.stringify(t)};return i?s(e,a):fetch(e,a).then(e=>o(e))},upload:function(e,t,i){return fetch(e,{method:"POST"===t?"POST":"PUT",headers:{authorization:`Bearer ${(0,r.Ri)(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE)}`},body:i}).then(e=>o(e))}}},3200:(e,t,i)=>{"use strict";i.a(e,async(e,a)=>{try{i.r(t),i.d(t,{GlobalStyle:()=>m,StyledLayout:()=>f,StyledUpdate:()=>b,default:()=>g});var r=i(8732),n=i(4391),s=i(2770);i(5082);var o=i(4906),l=i(120),d=i(8574),c=i(2015),h=i(6715),p=i(2288),u=i(9926),x=e([n,o,l]);[n,o,l]=x.then?(await x)():x;let m=(0,s.createGlobalStyle)`

  * {
    box-sizing: border-box;
    font-size: 100%;
    scroll-behavior: smooth;
    scroll-padding-top: 200px;
  }
  *:before,
  *:after,
  * {
    box-sizing: border-box;
  }

  body {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font: var(--font-size-base) / var(--line-height-base) var(--base-font-sans-serif);
    background: var(--black);
    color: var(--white);
    font-weight: 300;
    position: relative;
    min-width: 375px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;


    &.nav-active {
      overflow: hidden !important;

      .overlay {
        visibility: visible;
        opacity: 1;
      }
    }

    
  }
  
  .overlay {
  visibility: hidden;
  opacity: 0;
  transition: all ease-in-out 0.3s;
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 5;
}

  .container {
    max-width: 1380px;
    margin: 0 auto;
    padding: 0 15px;
     @media (min-width: 768px) {
         padding: 0 20px;

    }
  }
  
  #wrapper {
    width: 100%;
    padding: 65px 10px 10px;
    position: relative;
    overflow: hidden;
    @media (min-width: 768px){
      padding: 95px 10px 10px;

    }
  }


  img {
    display: block;
    max-width: 100%;
    height: auto;
  }

  ul {

    list-style: none;
    padding: 0;
    margin: 0;
  }

  textarea {
    resize: vertical;
    vertical-align: top;
  }

  button,
  input[type="button"],
  input[type="reset"],
  input[type="file"],
  input[type="submit"] {
    cursor: pointer;
    font-family: inherit;
  }

  form,
  fieldset {
    margin: 0;
    padding: 0;
    border-style: none;
  }
  a {
    text-decoration: none;
    color: var(--blue);
  }

  input[type="search"]::-webkit-search-decoration,
  input[type="search"]::-webkit-search-cancel-button,
  input[type="search"]::-webkit-search-results-button,
  input[type="search"]::-webkit-search-results-decoration {
    display: none;
  }

  button {
    transition: opacity var(--animation-speed) ease-in-out,
      background var(--animation-speed) ease-in-out,
      visibility var(--animation-speed) ease-in-out,
      border var(--animation-speed) ease-in-out,
      color var(--animation-speed) ease-in-out;
  }

  button {
    padding: 0;
    border: none;
    background: none;
    outline: none;
    font-family: var(--font-size-base);
  }
  .bold {
    font-size: 20px;
    line-height: 24px;
    font-weight: 400;
    @media (min-width: 767px) {
      font-size: 30px;
      line-height: 34px;
    }
  }

  table {
    width: 100%;
  }

  h1,
  .h1,
  h2,
  .h2,
  h3,
  .h3,
  h4,
  .h4,
  h5,
  .h5,
  h6,
  .h6 {
    margin: 0 0 10px;
    color: var(--body-text);
    font-weight: 500;
    @media (min-width: 576px) {
      margin: 0 0 15px;

    }
  }

  h1,
  .h1 {
    font-size: 24px;
    line-height: 30px;
    font-weight: 700;
    
    @media (min-width: 576px) {
      font-size: 40px;
      line-height: 44px;
      
    }
    @media (min-width: 768px) {
      font-size: 50px;
      line-height: 55px;
    }
  }

  h2,
  .h2 {
    font-size: 27px;
    line-height: 31px;
    font-weight: 700;
    
    @media (min-width: 576px) {
      font-size: 35px;
      line-height: 40px;

    }
    @media (min-width: 992px) {
      font-size: 48px;
      line-height: 49px;
    }
  }
  h3,
  .h3 {
    font-size: 28px;
    line-height: 32px;
  }
  h4,
  .h4 {
    font-size: 24px;
    line-height: 28px;
  }

.primary-heading{
      color: var(--primary);
}

.text-lg{
  @media (min-width: 768px){

    font-size: 18px;
    line-height: 22px;
  }
}
  p {
    margin: 0 0 15px;
    &:last-child {
      margin: 0;
    }
  }

  br {

    @media(max-width: 991px){
      display: none;
    }
  }

  ::-webkit-scrollbar {
    width: 8px;
    height: 20px;
  }

  /* Track */
  ::-webkit-scrollbar-track {
    border-radius: 15px;
    background: var(--gray-50);
  }

  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: var(--primary);
    border-radius: 10px;
  }

  /* Handle on hover */
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    appearance: none;
    margin: 0;
  }
   input:-webkit-autofill,
  textarea:-webkit-autofill {
    background-color: transparent !important;
    transition: background-color 5000s ease-in-out 0s;
  }

  input:-webkit-autofill:focus,
  textarea:-webkit-autofill:focus {
    background-color: transparent !important;
  }
  figure {
    margin: 0;
  }
  /* Firefox */
  input[type="number"] {
    appearance: textfield;
  }

  .gradientWrap {
    background: var(--gradient);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .react-loading-skeleton{
    --base-color:var(--primary);
  }

  `,f=s.styled.div`
    .bg {
        position: absolute;
        top: -800px;
        max-width: 1600px;
        left: 50%;
        transform: translateX(-50%);
        z-index: -1;
    }
`,b=s.styled.div`
    height: calc(100vh - 75px);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    h1 {
        font-size: 26px;
        line-height: 30px;
        text-align: center;

        @media (min-width: 576px) {
            font-size: 32px;
            line-height: 36px;
        }
    }

    p {
        text-align: center;
        margin: 0 0 26px;

        @media (max-width: 575px) {
            font-size: 14px;
            line-height: 18px;
        }
    }

    form {
        width: 100%;
        max-width: 550px;

        .input-wrapper {
            backdrop-filter: blur(10px);
            border: 1px solid var(--dark-100);
            border-radius: 16px;
            padding: 15px;
            margin: 0 0 26px;

            @media (min-width: 576px) {
                padding: 26px;
            }
        }

        .btn-holder {
            display: flex;
            justify-content: center;
            margin: 0 0 20px;

            &:last-child {
                margin: 0;
                button {
                    color: var(--white);
                }
            }
        }
    }

    @media (min-width: 768px) {
        height: calc(100vh - 105px);
    }
`,w=(0,s.styled)(n.ToastContainer)`
    z-index: 99999;

    .Toastify__toast {
        padding: 0;
        min-height: 0;
        border-radius: 8px;
        font-family: inherit;
    }
    .Toastify__toast--default {
        background: none;
    }
    .Toastify__toast-body {
        padding: 0;
    }
    .Toastify__close-button {
        position: absolute;
        top: 50%;
        right: 8px;
        transform: translateY(-50%);
    }
`;function g({Component:e,pageProps:t}){let[i,a]=(0,c.useState)(!1);return(0,h.useRouter)(),(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(m,{}),(0,r.jsx)(w,{}),(0,r.jsx)(l.h,{children:(0,r.jsxs)(d.t,{children:[i&&(0,r.jsx)(p.A,{}),(0,r.jsx)(o.A,{children:(0,r.jsx)(u.N,{children:(0,r.jsx)(e,{...t})})})]})})]})}a()}catch(e){a(e)}})},8271:(e,t,i)=>{"use strict";i.d(t,{A:()=>r});let{Fetch:a}=i(708),r={_url:`${process.env.NEXT_PUBLIC_USER_API}`,async login(e){let t=await a.post(`${this._url}/login`,e,!1,!0);if(t.status>=200&&t.status<300)return await t.json();let{message:i}=await t.json();throw Error(i??"Something went wrong")},async fetchUserDetails(){let e=await a.get(`${this._url}/get-user-details`);if(e.status>=200&&e.status<300)return await e.json();let{message:t}=await e.json();throw Error(t??"Something went wrong")},async signUp(e){let t=await a.post(`${this._url}/register`,e,!1,!0);if(t.status>=200&&t.status<300)return await t.json();let{message:i}=await t.json();throw Error(i??"Something went wrong")},async verifyEmail(e){let t=await a.post(`${this._url}/verify-email`,e,!1,!0);if(t.status>=200&&t.status<300)return await t.json();let{message:i}=await t.json();throw Error(i??"Something went wrong")},async verifyKyc(e){let t=await a.upload(`${this._url}/get-kyc-verified`,"POST",e);if(t.status>=200&&t.status<300)return await t.json();let{message:i}=await t.json();throw Error(i??"Something went wrong")},async forgotPassword(e){let t=await a.post(`${this._url}/send-verification-email`,e,!1,!0);if(t.status>=200&&t.status<300)return await t.json();let{message:i}=await t.json();throw Error(i??"Something went wrong")},async resetPassword(e){let t=await a.post(`${this._url}/set-password`,e,!1,!1);if(t.status>=200&&t.status<300)return await t.json();let{message:i}=await t.json();throw Error(i??"Something went wrong")}}},5082:()=>{}};