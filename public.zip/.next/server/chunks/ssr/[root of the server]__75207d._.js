module.exports = {

"[externals]/next/dist/compiled/next-server/pages.runtime.dev.js [external] (next/dist/compiled/next-server/pages.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/next-server/pages.runtime.dev.js", () => require("next/dist/compiled/next-server/pages.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("react/jsx-dev-runtime", () => require("react/jsx-dev-runtime"));

module.exports = mod;
}}),
"[externals]/react/jsx-runtime [external] (react/jsx-runtime, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("react/jsx-runtime", () => require("react/jsx-runtime"));

module.exports = mod;
}}),
"[externals]/react [external] (react, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("react", () => require("react"));

module.exports = mod;
}}),
"[externals]/path [external] (path, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("path", () => require("path"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/styled-components [external] (styled-components, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("styled-components", () => require("styled-components"));

module.exports = mod;
}}),
"[project]/src/pages/_document.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable react/no-unknown-property */ __turbopack_esm__({
    "default": (()=>MyDocument)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/document.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
;
;
class MyDocument extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"] {
    static async getInitialProps(ctx) {
        const sheet = new __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["ServerStyleSheet"]();
        const originalRenderPage = ctx.renderPage;
        try {
            ctx.renderPage = ()=>originalRenderPage({
                    enhanceApp: (App)=>(props)=>sheet.collectStyles(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(App, {
                                ...props
                            }, void 0, false, {
                                fileName: "[project]/src/pages/_document.js",
                                lineNumber: 14,
                                columnNumber: 33
                            }, this))
                });
            const initialProps = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].getInitialProps(ctx);
            return {
                ...initialProps,
                styles: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                    children: [
                        initialProps.styles,
                        sheet.getStyleElement()
                    ]
                }, void 0, true)
            };
        } finally{
            sheet.seal();
        }
    }
    render() {
        const { locale } = this.props.__NEXT_DATA__;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Html"], {
            lang: locale,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Head"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("link", {
                            rel: "preconnect",
                            href: "https://fonts.googleapis.com"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/_document.js",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("link", {
                            rel: "preconnect",
                            href: "https://fonts.gstatic.com",
                            crossorigin: true
                        }, void 0, false, {
                            fileName: "[project]/src/pages/_document.js",
                            lineNumber: 39,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("link", {
                            href: "https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap",
                            rel: "stylesheet"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/_document.js",
                            lineNumber: 40,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("link", {
                            href: "https://fonts.googleapis.com/css2?family=Vina+Sans&display=swap",
                            rel: "stylesheet"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/_document.js",
                            lineNumber: 44,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/_document.js",
                    lineNumber: 37,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("body", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Main"], {}, void 0, false, {
                            fileName: "[project]/src/pages/_document.js",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["NextScript"], {}, void 0, false, {
                            fileName: "[project]/src/pages/_document.js",
                            lineNumber: 50,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            id: "modal-root"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/_document.js",
                            lineNumber: 51,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/_document.js",
                    lineNumber: 48,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/pages/_document.js",
            lineNumber: 36,
            columnNumber: 7
        }, this);
    }
}
}}),
"[externals]/react-toastify [external] (react-toastify, esm_import)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
const mod = await __turbopack_external_import__("react-toastify");

__turbopack_export_namespace__(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/src/components/Header/Header.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledHeader": (()=>StyledHeader)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledHeader = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].header`
    display: flex;
    align-items: center;
    justify-content: flex-end;
    position: fixed;
    top: 10px;
    left: 10px;
    right: 10px;
    padding: 10px 15px;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 16px;
    backdrop-filter: blur(200px);
    z-index: 99;
    transition: 0.3s;

    @media (min-width: 768px) {
        justify-content: space-between;
        padding: 17px;
    }

    .scrolled & {
        top: 0;
        left: 0;
        right: 0;
        border-radius: 0;
        border-top: 0;
        border-left: 0;
        border-right: 0;
    }

    .logo-holder {
        width: 100%;
        max-width: 230px;
        display: none;
        cursor: pointer;
        @media (min-width: 768px) {
            display: block;
        }

        img {
            display: block;
            width: 100%;
            height: auto;
        }
    }

    .logo-sm {
        width: 30px;
        height: 30px;
        display: block;

        @media (min-width: 768px) {
            display: none;
        }

        img {
            width: 100%;
            height: auto;
            object-fit: cover;
        }
    }

    .user-info,
    .head,
    .dropdown-item,
    .logout {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .user-image {
        width: 50px;
        height: 50px;
        flex-shrink: 0;
        border-radius: 50%;
        background: var(--primary);
        overflow: hidden;

        img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    }

    .user-name {
        display: block;
        font-weight: 600;
    }

    .pages-holder {
        display: none;

        @media (min-width: 768px) {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page,
        .notification,
        .logout {
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--dark);
            border-radius: 10px;
            width: 40px;
            height: 40px;
            overflow: hidden;
            transition: 0.4s;

            .text {
                display: none;
                font-weight: 500;
            }

            &.active {
                width: max-content;
                background: var(--primary);
                color: var(--secondary);
                padding: 10px 12px;
                gap: 5px;

                img {
                    filter: invert(20%) sepia(9%) saturate(2959%) hue-rotate(106deg) brightness(61%) contrast(105%);
                }

                .text {
                    display: block;
                }
            }
        }

        .notification,
        .logout {
            cursor: pointer;

            &:hover {
                background: var(--primary);
                color: var(--secondary);
                img {
                    filter: invert(20%) sepia(9%) saturate(2959%) hue-rotate(106deg) brightness(61%) contrast(105%);
                }
            }
        }

        .user-info {
            position: relative;
            cursor: pointer;

            .arrow {
                width: 13px;
                height: 13px;
                flex-shrink: 0;
                transform: scale(1);
                transition: 0.3s all ease-in-out;
            }

            &.active {
                .arrow {
                    transform: scale(-1);
                }

                .dropdown {
                    visibility: visible;
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        }

        .dropdown {
            width: 250px;
            position: absolute;
            top: 60px;
            right: 0;
            background: var(--dark);
            padding: 12px;
            border: 1px solid var(--dark-100);
            border-radius: 12px;
            transform: translateY(10px);
            visibility: hidden;
            opacity: 0;
            transition: 0.3s all ease-in-out;

            .head {
                padding: 0 0 10px;
                border-bottom: 1px solid var(--dark-100);
                margin: 0 0 12px;

                a {
                    font-size: 14px;
                    line-height: 18px;
                }
            }

            .dropdown-item {
                padding: 10px 12px;
                border-radius: 8px;
                transition: 0.3s ease-in-out;

                &:not(:last-child) {
                    margin: 0 0 10px;
                }

                &.active,
                &:hover {
                    background: var(--dark-150);
                }
            }
        }
    }

    .menu-icon {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        left: 15px;
        display: block;

        @media (min-width: 768px) {
            display: none;
        }
    }

    .nav-links {
        width: 260px;
        height: 90vh;
        position: fixed;
        top: 60px;
        left: -100%;
        background: #eaffea;
        display: flex;
        flex-direction: column;
        padding: 30px 20px;
        border-radius: 0 20px 20px 0;
        transition: all 0.4s ease-in-out;
        color: var(--text-color);
        overflow: hidden;

        @media (min-width: 768px) {
            display: none;
        }

        ul,
        .logout {
            img {
                width: 20px;
                height: 20px;
                filter: invert(15%) sepia(8%) saturate(17%) hue-rotate(350deg) brightness(20%) contrast(88%);
            }
        }

        ul {
            flex-grow: 1;
            border-bottom: 1px solid #c5d6c5;
            margin: 0 0 15px;

            li {
                display: flex;
                align-items: center;
                gap: 10px;

                padding: 15px;
                border-radius: 10px;

                &:hover,
                &.active {
                    color: var(--secondary);
                    background: var(--white);
                    font-weight: 500;

                    img {
                        filter: invert(20%) sepia(9%) saturate(2959%) hue-rotate(106deg) brightness(50%) contrast(105%);
                    }
                }
            }
        }

        .head {
            margin: 0 0 20px;

            a {
                font-size: 14px;
                line-height: 18px;
            }
        }

        .logout {
            background: #fff7cc;
            padding: 13px 16px;
        }
    }

    .nav-active & {
        .nav-links {
            left: -12px;
        }
    }
`;
}}),
"[project]/src/assets/images/logo.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/logo.29630a6b.svg");}}),
"[project]/src/assets/images/logo.svg.mjs { IMAGE => \"[project]/src/assets/images/logo.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/logo.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 232,
    height: 27,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/dashboard-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/dashboard-icon.cdd28cf4.svg");}}),
"[project]/src/assets/images/dashboard-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/dashboard-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$dashboard$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/dashboard-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$dashboard$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 18,
    height: 18,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/wallet-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/wallet-icon.94a1fd73.svg");}}),
"[project]/src/assets/images/wallet-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/wallet-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$wallet$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/wallet-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$wallet$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 18,
    height: 19,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/notification-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/notification-icon.e38f7e31.svg");}}),
"[project]/src/assets/images/notification-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/notification-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$notification$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/notification-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$notification$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 18,
    height: 19,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/logout-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/logout-icon.f67e70b4.svg");}}),
"[project]/src/assets/images/logout-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/logout-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logout$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/logout-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logout$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 18,
    height: 19,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/avatar.png [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/avatar.cdeb9568.png");}}),
"[project]/src/assets/images/avatar.png.mjs { IMAGE => \"[project]/src/assets/images/avatar.png [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/avatar.png [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 500,
    height: 500,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA0ElEQVR42m2OOwtBYRyH38v/nCOXQ5QUMbgcl1NEGQyKshoURYnIYCNiMbEpk0RZ5BuIycBKWY1GpXwHL9M5kmd8fs/wQ0gFU0pFADBjjAD9QPQ6bVoO+PZyQDqZjGL146iyAqW2TCJ6WY7arFsvsJgsXTkApxJoNUKwVc4+jusJO6zGrJJN3XkO/Epgt5rD00HzuV2M2G4+ZP1a7vIJLEog8Jw3GY/ceo0i69Tyr2QsNKOEqEcxxoJo0JdCkufsdjk2PM/F0R8IALURQgzf8g1IhCrco+WDdgAAAABJRU5ErkJggg==",
    blurWidth: 8,
    blurHeight: 8
};
}}),
"[project]/src/assets/images/down-arrow.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/down-arrow.7fc9bf93.svg");}}),
"[project]/src/assets/images/down-arrow.svg.mjs { IMAGE => \"[project]/src/assets/images/down-arrow.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$down$2d$arrow$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/down-arrow.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$down$2d$arrow$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 10,
    height: 5,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/privacy-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/privacy-icon.f125b6d7.svg");}}),
"[project]/src/assets/images/privacy-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/privacy-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$privacy$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/privacy-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$privacy$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 16,
    height: 16,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/terms-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/terms-icon.f76697d5.svg");}}),
"[project]/src/assets/images/terms-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/terms-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$terms$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/terms-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$terms$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 16,
    height: 16,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/settings-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/settings-icon.1420e7f9.svg");}}),
"[project]/src/assets/images/settings-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/settings-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$settings$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/settings-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$settings$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 16,
    height: 16,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/menu-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/menu-icon.c77bf66e.svg");}}),
"[project]/src/assets/images/menu-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/menu-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$menu$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/menu-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$menu$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 26,
    height: 26,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/logo-sm.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/logo-sm.b041f748.svg");}}),
"[project]/src/assets/images/logo-sm.svg.mjs { IMAGE => \"[project]/src/assets/images/logo-sm.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2d$sm$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/logo-sm.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2d$sm$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 28,
    height: 27,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[externals]/react-dom [external] (react-dom, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("react-dom", () => require("react-dom"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/components/Button/Button.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledButton": (()=>StyledButton)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledButton = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].button`
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: ${({ $gap })=>$gap ? $gap : "5px"};
  padding: 12px 15px;
  border-radius: ${({ $rounded })=>$rounded ? "60px" : "8px"};
  font-size: 14px;
  line-height: 18px;
  font-weight: 400;
  width: ${({ $width })=>$width ? $width : "140px"};
  min-width: 140px;
  background: var(--off-white);
  color: var(--secondary);
  transition: 0.5s all ease-in-out;
  box-shadow: 0px 4px 3px 0px #ffffff45 inset, 0px -3px 5px 0px #ffffff40 inset;
  overflow: hidden;
  z-index: 1;

  @media (min-width: 768px) {
    font-size: 15px;
    line-height: 19px;
  }

  ${({ $loader, disabled })=>$loader || disabled && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
        cursor: not-allowed;
      `}

  ${({ $lg })=>$lg && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      width: ${({ $width })=>$width ? $width : "200px"};
      padding: 15px;
    `}

  @media screen and (max-width:786px) {
    padding: 8px 15px;
  }
  /***** Background-Variants-Start *****/

  ${({ $variant })=>$variant == "secondary" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
        background: var(--primary);
        color: var(--secondary);
      ` || $variant == "outline" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
        background: var(--white);
        border: 1px solid var(--primary);
        color: var(--primary);
      ` || $variant == "danger" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
        background: var(--danger);
        color: var(--text-color);
      `}

  /*****************Background Variants End*********************/


  /*****************Border Variants Start*********************/

  ${({ $outline })=>$outline && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      border: 1px solid var(--blue);
      background: transparent;
      color: var(--blue);
    `}
  /*****************Border Variants End*********************/

    .loader {
    width: 17px;
    height: 17px;
    border-radius: 50%;
    display: inline-block;
    border-top: 3px solid var(--secondary);
    border-right: 3px solid transparent;
    box-sizing: border-box;
    animation: rotation 1s linear infinite;
  }

  @keyframes rotation {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }

  &:before,
  &:after {
    content: "";
    position: absolute;
    height: 1px;
    width: 1px;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    border-radius: 50%;
    z-index: -1;
  }

  &:before {
    display: none;
    background: var(--secondary);
    transition: 0.6s ease-in;
    transition-delay: 0.1s;
  }

  &:after {
    background: var(--primary);
    transition: 0.8s ease;
    transition-delay: 0.4s;

    ${({ $variant })=>$variant == "secondary" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
        background: var(--white);
      `}

    ${({ $variant })=>$variant == "danger" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
        background: #dc4320;
      `}
  }

  &:hover {
    &:before,
    &:after {
      transform: translate(-50%, -50%) scale(1000);
      z-index: -1;
    }
  }
`;
}}),
"[project]/src/components/Button/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$Button$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Button/Button.styles.js [ssr] (ecmascript)");
;
;
;
const Button = ({ children, gap, lg, outline, variant, width, loader, disabled, rounded, delayAnimation, ...rest })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$Button$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledButton"], {
        $lg: lg,
        $outline: outline,
        $variant: variant,
        $gap: gap,
        $width: width,
        $delayAnimation: delayAnimation,
        $rounded: rounded,
        disabled: loader || disabled,
        ...rest,
        children: loader ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
            className: "loader"
        }, void 0, false, {
            fileName: "[project]/src/components/Button/index.jsx",
            lineNumber: 29,
            columnNumber: 17
        }, this) : children
    }, void 0, false, {
        fileName: "[project]/src/components/Button/index.jsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = Button;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[project]/src/helpers/common.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable react/jsx-filename-extension */ /* eslint-disable no-unused-vars */ /* eslint-disable react/react-in-jsx-scope */ /* eslint-disable no-plusplus */ __turbopack_esm__({
    "GeoCode": (()=>GeoCode),
    "bas64toFile": (()=>bas64toFile),
    "calculateTotalNights": (()=>calculateTotalNights),
    "capitalize": (()=>capitalize),
    "checkAge": (()=>checkAge),
    "checkInValidImage": (()=>checkInValidImage),
    "clearCookie": (()=>clearCookie),
    "convertDateToISO": (()=>convertDateToISO),
    "convertPdfBase64": (()=>convertPdfBase64),
    "convertReadable": (()=>convertReadable),
    "convertToBase64": (()=>convertToBase64),
    "convertToCurrencyFormat": (()=>convertToCurrencyFormat),
    "convertToFormData": (()=>convertToFormData),
    "daysLeft": (()=>daysLeft),
    "debounce": (()=>debounce),
    "formatDate": (()=>formatDate),
    "formatDateWithSuffix": (()=>formatDateWithSuffix),
    "formatNumber": (()=>formatNumber),
    "generatePsscode": (()=>generatePsscode),
    "getCookie": (()=>getCookie),
    "getDateObject": (()=>getDateObject),
    "getOfferDetailsAppView": (()=>getOfferDetailsAppView),
    "getStatusIconClass": (()=>getStatusIconClass),
    "getVisitNo": (()=>getVisitNo),
    "removeSpaces": (()=>removeSpaces),
    "setCookie": (()=>setCookie),
    "shortenString": (()=>shortenString)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/date-fns/format.js [ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarDays$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/differenceInCalendarDays.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$setHours$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/setHours.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isBefore$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/isBefore.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInDays$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/differenceInDays.js [ssr] (ecmascript)");
;
;
;
const setCookie = (name, value, days, domain)=>{
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        expires = `; expires=${date.toUTCString()}`;
    }
    const domainString = domain ? `; domain=${domain}` : "";
    document.cookie = `${name}=${value || ""}${expires}; path=/${domainString}`;
    return true;
};
const getCookie = (name)=>{
    const nameEQ = `${name}=`;
    const ca = typeof document !== "undefined" && document.cookie.split(";");
    for(let i = 0; i < ca.length; i++){
        let c = ca[i];
        while(c.charAt(0) === " ")c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
};
const clearCookie = (name)=>{
    if (typeof document !== "undefined") {
        document.cookie = `${name}=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;`;
    } else {
        console.warn("clearCookie function called in a non-browser environment");
    }
    return true;
};
const formatNumber = (number)=>{
    return new Intl.NumberFormat().format(number);
};
const convertPdfBase64 = (file)=>new Promise((resolve)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = ()=>{
            resolve(reader.result);
        };
    });
const capitalize = (str = "")=>{
    const arr = str.toLowerCase().split(" ");
    for(let i = 0; i < arr.length; i++){
        arr[i] = arr[i].charAt(0).toUpperCase() + arr[i].slice(1);
    }
    const str2 = arr.join(" ");
    return str2;
};
const getStatusIconClass = (status = "")=>{
    switch(status.trim().toLowerCase()){
        case "pending":
            return "icon-clock";
        case "processing":
            return "icon-clock";
        case "approved":
            return "icon-check-circle";
        case "rejected":
            return "icon-error-circle";
        case "cancelled":
            return "icon-times-circle";
        default:
            return "icon-warning";
    }
};
function changeTimezone(date, ianatz) {
    // suppose the date is 12:00 UTC
    const invdate = new Date(date.toLocaleString("en-US", {
        timeZone: ianatz
    }));
    // then invdate will be 07:00 in Toronto
    // and the diff is 5 hours
    const diff = date.getTime() - invdate.getTime();
    // so 12:00 in Toronto is 17:00 UTC
    return new Date(date.getTime() - diff); // needs to substract
}
const getDateObject = (e)=>changeTimezone(new Date(e), "Canada/Eastern");
const convertToCurrencyFormat = (amount = "0")=>`$${Number(amount).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
const shortenString = (str, len = 10)=>{
    if (!str) return null;
    if (str.length > len) {
        return `${str.substring(0, len)}...`;
    }
    return str;
};
const convertReadable = (amount = 0)=>`${Math.abs(amount) > 999 ? `${Math.sign(amount) * (Math.abs(amount) / 1000).toFixed(1)}K` : Math.sign(amount) * Math.abs(amount)}`;
const convertToBase64 = (file)=>new Promise((resolve)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = ()=>{
            resolve(reader.result);
        };
    });
const getVisitNo = (visit)=>{
    switch(visit){
        case 1:
            return `${String(visit)}st`;
        case 2:
            return `${String(visit)}nd`;
        case 3:
            return `${String(visit)}rd`;
        default:
            return `${String(visit)}th`;
    }
};
const generatePsscode = (length)=>{
    let zero = "";
    for(let index = 1; index < length; index++){
        zero += "0";
    }
    const firstVal = 1 + zero;
    const secondVal = 9 + zero;
    return Math.floor(Number(firstVal) + Math.random() * Number(secondVal));
};
const getOfferDetailsAppView = ({ offer_type, // eslint-disable-next-line no-unused-vars
offer_details: { minimum_amount, minimum_visit, maximum_amount, plastk_points_value, plastk_points, initial_offer, every_day_offer }, stores, duration: { startDate, endDate } })=>{
    if (!stores.length || !offer_type || !plastk_points_value || !startDate || !endDate) return "";
    try {
        switch(offer_type){
            case "dollarBased":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: [
                                "Spend at least ",
                                convertToCurrencyFormat(minimum_amount, 0),
                                " and receive",
                                " ",
                                plastk_points_value,
                                " plastk points. Offer valid between",
                                " ",
                                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(startDate).toString()), "MMM do yyyy hh:mm a")} To ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(endDate).toString()), "MMM do yyyy hh:mm a")}`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 190,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 198,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
            case "repeatVisit":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: [
                                "Visit ",
                                minimum_visit,
                                " times and receive ",
                                plastk_points_value,
                                " plastk points on the",
                                " ",
                                (()=>{
                                    switch(+String(minimum_visit).split("")[String(minimum_visit).split("").length - 1]){
                                        case 1:
                                            return `${String(minimum_visit)}st`;
                                        case 2:
                                            return `${String(minimum_visit)}nd`;
                                        case 3:
                                            return `${String(minimum_visit)}rd`;
                                        default:
                                            return `${String(minimum_visit)}th`;
                                    }
                                })(),
                                " ",
                                "visit. Offer valid between",
                                " ",
                                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(startDate).toString()), "MMM do yyyy hh:mm a")} to ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(endDate).toString()), "MMM do yyyy hh:mm a")}`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 205,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 225,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
            case "percentBased":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: [
                                "Spend $",
                                minimum_amount,
                                " or more and receive ",
                                plastk_points,
                                "% in plastk points, up to a maximum of",
                                " ",
                                plastk_points_value % 1 !== 0 ? convertToCurrencyFormat(plastk_points_value, 2, false) : convertToCurrencyFormat(plastk_points_value, 0, false),
                                "points. Offer valid between",
                                " ",
                                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(startDate).toString()), "MMM do yyyy hh:mm a")} to ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(endDate).toString()), "MMM do yyyy hh:mm a")}`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 232,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 244,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
            case "initialOffer":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: [
                                "Visit ",
                                minimum_visit,
                                " times and receive ",
                                plastk_points_value,
                                " plastk points on the  ",
                                (()=>{
                                    switch(+String(minimum_visit).split("")[String(minimum_visit).split("").length - 1]){
                                        case 1:
                                            return `${String(minimum_visit)}st`;
                                        case 2:
                                            return `${String(minimum_visit)}nd`;
                                        case 3:
                                            return `${String(minimum_visit)}rd`;
                                        default:
                                            return `${String(minimum_visit)}th`;
                                    }
                                })(),
                                " ",
                                "visit. Offer valid between",
                                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(startDate).toString()), "MMM do yyyy hh:mm a")} to ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(endDate).toString()), "MMM do yyyy hh:mm a")}`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 250,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 270,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
            default:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: "Wrong Offer Type ...."
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 289,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: "Offer valid between ---- ----"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 290,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 291,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
        }
    } catch (e) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                    children: e.message
                }, void 0, false, {
                    fileName: "[project]/src/helpers/common.js",
                    lineNumber: 298,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                    children: "Offer valid between ---- ----"
                }, void 0, false, {
                    fileName: "[project]/src/helpers/common.js",
                    lineNumber: 299,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                    children: "*Terms And Conditions Apply"
                }, void 0, false, {
                    fileName: "[project]/src/helpers/common.js",
                    lineNumber: 300,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true);
    }
};
const validateImage = (url)=>new Promise((resolve, reject)=>{
        const img = new Image(url);
        // eslint-disable-next-line no-multi-assign
        img.onerror = img.onabort = async function() {
            reject();
        };
        img.onload = function() {
            resolve();
        };
        img.src = url;
    });
const checkValidImageProtocol = (url)=>{
    if (/(http(s?)):\/\//i.test(url)) {
        return true;
    }
    return false;
};
const checkValidImageExtension = (url)=>{
    if ([
        "png",
        "PNG",
        "jpg",
        "JPG",
        "jpeg",
        "JPEG"
    ].includes(url.split(/[#?]/)[0].split(".").pop().trim())) {
        return true;
    }
    return false;
};
const checkInValidImage = async (url)=>{
    try {
        await validateImage(url);
        return !(checkValidImageExtension(url) && checkValidImageProtocol(url));
    } catch (ex) {
        return true;
    }
};
const convertToFormData = (obj)=>{
    const formData = new FormData();
    Object.keys(obj).forEach((key)=>{
        if (key === "bankInfo" || key === "inheritanceInfo" && typeof obj[key] === "object") {
            formData.append(key, JSON.stringify(obj[key]));
        } else {
            formData.append(key, obj[key]);
        }
    });
    return formData;
};
const convertDateToISO = (dateStr)=>{
    const [day, month, year] = dateStr.split("/");
    return `${year}-${month}-${day}`;
};
// Format the date
const getOrdinalSuffix = (day)=>{
    if (day > 3 && day < 21) return "th";
    switch(day % 10){
        case 1:
            return "st";
        case 2:
            return "nd";
        case 3:
            return "rd";
        default:
            return "th";
    }
};
const formatDateWithSuffix = (dateObj)=>{
    const date = new Date(dateObj);
    const day = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, "d"); // get the day without leading zeros
    const monthYear = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, "MMMM, yyyy"); // get the month and year
    const ordinalSuffix = getOrdinalSuffix(parseInt(day)); // get the ordinal suffix
    return `${day}${ordinalSuffix} ${monthYear}`;
};
const daysLeft = (dateObj)=>{
    const date = new Date(dateObj);
    const daysLeft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarDays$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["differenceInCalendarDays"])(date, new Date());
    return daysLeft < 10 ? `0${daysLeft} days` : `${daysLeft.toString()} days`;
// return formatDistanceToNow(date, {addSuffix: false});
};
const bas64toFile = async (dataUrl, fileName)=>{
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return new File([
        blob
    ], fileName, {
        type: "image/jpg"
    });
};
const checkAge = (birthdate)=>{
    let birthDate = new Date(birthdate);
    if (isNaN(birthDate)) {
        return "Invalid date format. Please enter a valid date.";
    }
    let today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    let monthDifference = today.getMonth() - birthDate.getMonth();
    let dayDifference = today.getDate() - birthDate.getDate();
    if (monthDifference < 0 || monthDifference === 0 && dayDifference < 0) {
        age--;
    }
    // Check if age is at least 18
    if (age >= 18) {
        return true;
    } else {
        return false;
    }
};
const removeSpaces = (str = "")=>{
    return str.replace(/ /g, "");
};
const debounce = (func, delay)=>{
    let timeoutId;
    return (...args)=>{
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
        timeoutId = setTimeout(()=>{
            func(...args);
        }, delay);
    };
};
const GeoCode = async (value)=>{
    try {
        const { results } = "undefined" !== "undefined" && await new window.google.maps.Geocoder().geocode(value);
        if (!results) {
            throw Error("Unable to load maps");
        }
        const { address_components, geometry, place_id, formatted_address, types } = results[0];
        const address = {};
        // eslint-disable-next-line no-shadow
        address_components?.forEach(({ short_name, types })=>{
            if (types.includes("administrative_area_level_1")) {
                address.state = short_name;
            } else if (types.includes("administrative_area_level_2")) {
                address.county = short_name;
            } else if (types.includes("locality")) {
                address.city = short_name;
            } else address[types[0]] = short_name;
        });
        return {
            ...address,
            types,
            place_id,
            latlng: {
                lat: geometry?.location?.lat(),
                lng: geometry?.location?.lng()
            },
            formatted_address
        };
    } catch (err) {
        throw Error(err?.message ?? "Unable to load maps");
    }
};
const formatDate = (date)=>{
    const offset = date.getTimezoneOffset();
    const localDate = new Date(date.getTime() - offset * 60 * 1000);
    return localDate.toISOString().split("T")[0];
};
const calculateTotalNights = (startDate, endDate)=>{
    // Parse the start and end dates into Date objects
    const start = new Date(startDate);
    const end = new Date(endDate);
    // Ensure the provided dates are valid
    if (isNaN(start) || isNaN(end)) {
        return "Invalid date format. Please provide valid dates.";
    }
    // Adjust check-in time to 3 PM (15:00) on the start date
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$setHours$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["setHours"])(start, 15, 0, 0, 0); // Set check-in to 3 PM on the start date
    // Adjust check-out time to 11 AM (11:00) on the next day of the end date
    end.setDate(end.getDate()); // Move the checkout date to the next day
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$setHours$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["setHours"])(end, 11, 0, 0, 0); // Set the checkout time to 11 AM on the next day
    // Ensure the check-out time is after the check-in time
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isBefore$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["isBefore"])(end, start)) {
        return "Check-out time should be after check-in time.";
    }
    // Calculate the difference in days (inclusive of both dates)
    const totalNights = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInDays$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["differenceInDays"])(end, start);
    return totalNights;
};
}}),
"[project]/src/helpers/fetchWrapper.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Fetch": (()=>Fetch)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/helpers/common.js [ssr] (ecmascript)");
;
let trigger = false;
const debounceInterval = 1000;
let debounceTimeout;
function debounceFetch(url, requestOptions) {
    if (debounceTimeout) {
        clearTimeout(debounceTimeout);
    }
    return new Promise((resolve)=>{
        debounceTimeout = setTimeout(()=>{
            fetch(url, requestOptions).then((res)=>{
                resolve(handleResponse(res));
            });
        }, debounceInterval);
    });
}
function handleResponse(response) {
    if (response.status === 401 && !trigger && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))) {
        trigger = true;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["clearCookie"])(("TURBOPACK compile-time value", "intd_d"));
        // clearCookie(process.env.REACT_APP_ALLOWED_PAGES_COOKIE);
        window.location.reload();
    }
    return response;
}
function get(url, debounce = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "GET",
        headers
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function post(url, body, debounce = false, signUp = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: signUp ? "Bearer intd-secret-token" : `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "POST",
        headers,
        body: JSON.stringify(body)
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function upload(url, method, body) {
    const headers = {
        // 'Content-Type': 'multipart/form-data',
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: method === "POST" ? "POST" : "PUT",
        headers,
        body
    };
    return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function put(url, body, debounce = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "PUT",
        headers,
        body: JSON.stringify(body)
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function _delete(url, body, debounce = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "DELETE",
        headers,
        body: JSON.stringify(body)
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function patch(url, body, debounce = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "PATCH",
        headers,
        body: JSON.stringify(body)
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
const Fetch = {
    get,
    post,
    put,
    delete: _delete,
    patch,
    upload
};
}}),
"[project]/src/services/authService.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
const { Fetch } = __turbopack_require__("[project]/src/helpers/fetchWrapper.js [ssr] (ecmascript)");
const authService = {
    _url: `${("TURBOPACK compile-time value", "https://internationaldigitaldollar.com/user")}`,
    async login (payload) {
        let res = await Fetch.post(`${this._url}/login`, payload, false, true);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async fetchUserDetails () {
        let res = await Fetch.get(`${this._url}/get-user-details`);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async signUp (payload) {
        let res = await Fetch.post(`${this._url}/register`, payload, false, true);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async verifyEmail (payload) {
        let res = await Fetch.post(`${this._url}/verify-email`, payload, false, true);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async verifyKyc (formData) {
        let res = await Fetch.upload(`${this._url}/get-kyc-verified`, "POST", formData);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async forgotPassword (payload) {
        let res = await Fetch.post(`${this._url}/send-verification-email`, payload, false, true);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async resetPassword (payload) {
        let res = await Fetch.post(`${this._url}/set-password`, payload, false, false);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    }
};
const __TURBOPACK__default__export__ = authService;
}}),
"[project]/src/components/molecules/Toast/Toast.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Message": (()=>Message),
    "StyledAlert": (()=>StyledAlert)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledAlert = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
    width: 100%;
    border-radius: 8px;
    padding: 1rem;
    display: flex;
    align-items: center;
    font-size: var(--font-size-sm);
    line-height: calc(var(--font-size-sm) + 0.3125rem);
    @media (min-width: 768px) {
        padding: 1rem 3.9375rem 1rem 1rem;
    }

    ${({ $type })=>$type === "success" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
            color: var(--secondary);
            background: #97fa93;
        `}

    ${({ $type })=>$type === "info" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
            color: var(--info-text);
            background: var(--info);
        `}

    ${({ $type })=>$type === "error" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
            color: var(--danger-100);
            background: #fef0f4;
        `}

    ${({ $type })=>$type === "warning" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
            color: var(--warning);
            background: #fffaf2;
        `}
`;
const Message = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].p`
    color: inherit;
    margin: 0;
`;
}}),
"[project]/src/components/molecules/AlertIcon/AlertIcon.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledIcon": (()=>StyledIcon)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledIcon = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  font-size: 1.625rem;
  line-height: 1;
  margin-right: 1.125rem;
`;
}}),
"[project]/src/components/molecules/AlertIcon/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$AlertIcon$2f$AlertIcon$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/AlertIcon/AlertIcon.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$rx$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/rx/index.mjs [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/io/index.mjs [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/io5/index.mjs [ssr] (ecmascript)");
;
;
;
;
;
;
const AlertIcon = ({ $type })=>{
    const iconType = ()=>{
        switch($type){
            case "error":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$rx$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["RxCrossCircled"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 11,
                    columnNumber: 16
                }, this);
            case "info":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["IoMdInformationCircleOutline"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 13,
                    columnNumber: 16
                }, this);
            case "warning":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["IoWarningOutline"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 15,
                    columnNumber: 16
                }, this);
            case "success":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["IoCheckmarkSharp"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 17,
                    columnNumber: 16
                }, this);
            default:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["IoMdInformationCircleOutline"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 19,
                    columnNumber: 16
                }, this);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$AlertIcon$2f$AlertIcon$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledIcon"], {
        $type: $type,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
            className: "material-icons-outlined",
            children: iconType()
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
            lineNumber: 24,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = AlertIcon;
}}),
"[project]/src/components/molecules/Toast/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__ = __turbopack_import__("[externals]/react-toastify [external] (react-toastify, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$Toast$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Toast/Toast.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$AlertIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/AlertIcon/index.jsx [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
function Toast({ type, message, ...props }) {
    return (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__["toast"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$Toast$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledAlert"], {
        $type: type,
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$AlertIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                $type: type
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Toast/index.jsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$Toast$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Message"], {
                $type: type,
                children: message
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Toast/index.jsx",
                lineNumber: 10,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/Toast/index.jsx",
        lineNumber: 8,
        columnNumber: 5
    }, this), {
        hideProgressBar: true,
        autoClose: 2000,
        ...props
    });
}
const __TURBOPACK__default__export__ = Toast;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/components/Header/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Header$2f$Header$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Header/Header.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/logo.svg.mjs { IMAGE => "[project]/src/assets/images/logo.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$dashboard$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$dashboard$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/dashboard-icon.svg.mjs { IMAGE => "[project]/src/assets/images/dashboard-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$wallet$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$wallet$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/wallet-icon.svg.mjs { IMAGE => "[project]/src/assets/images/wallet-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$notification$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$notification$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/notification-icon.svg.mjs { IMAGE => "[project]/src/assets/images/notification-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logout$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logout$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/logout-icon.svg.mjs { IMAGE => "[project]/src/assets/images/logout-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/avatar.png.mjs { IMAGE => "[project]/src/assets/images/avatar.png [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$down$2d$arrow$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$down$2d$arrow$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/down-arrow.svg.mjs { IMAGE => "[project]/src/assets/images/down-arrow.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$privacy$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$privacy$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/privacy-icon.svg.mjs { IMAGE => "[project]/src/assets/images/privacy-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$terms$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$terms$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/terms-icon.svg.mjs { IMAGE => "[project]/src/assets/images/terms-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$settings$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$settings$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/settings-icon.svg.mjs { IMAGE => "[project]/src/assets/images/settings-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$menu$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$menu$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/menu-icon.svg.mjs { IMAGE => "[project]/src/assets/images/menu-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2d$sm$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logo$2d$sm$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/logo-sm.svg.mjs { IMAGE => "[project]/src/assets/images/logo-sm.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Button/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/router.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/helpers/common.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/authService.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Toast/index.jsx [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const pages = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$privacy$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$privacy$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "Privacy Policy",
        href: "/privacy-policy"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$terms$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$terms$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "Terms & Conditions",
        href: "/terms-and-conditions"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$settings$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$settings$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "settings",
        href: "/settings"
    }
];
const navData = [
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$dashboard$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$dashboard$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "Dashboard",
        link: "/"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$wallet$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$wallet$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "My Wallet",
        link: "/my-wallet"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$terms$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$terms$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "Terms & Conditions",
        link: "/terms-and-conditions"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$privacy$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$privacy$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "Privacy Policy",
        link: "/privacy-policy"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$notification$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$notification$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "Notifications",
        link: "/notifications"
    },
    {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$settings$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$settings$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        label: "Settings",
        link: "/settings"
    }
];
const Header = ()=>{
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const navRef = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useRef"])(null);
    const [userDropDown, setUserDropDown] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const [userDetails, setUserDetails] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(null);
    function handleLogout() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["clearCookie"])("intd_d");
        router.push("/login");
    }
    function handleMenu() {
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        }
    }
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time truthy", 1) return;
        "TURBOPACK unreachable";
        function handleClickOutside(event) {
            if (navRef.current && !navRef.current.contains(event.target)) {
                document.body.classList.remove("nav-active");
            }
        }
    }, [
        navRef
    ]);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time truthy", 1) return;
        "TURBOPACK unreachable";
        const handleRouteChangeStart = undefined;
        const handleRouteChangeComplete = undefined;
    }, [
        router
    ]);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        const fetchUserDetails = async ()=>{
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].fetchUserDetails();
                setUserDetails(res);
                console.log(res);
            } catch (err) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                    type: "error",
                    message: userDetails.message
                });
            }
        };
        fetchUserDetails();
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Header$2f$Header$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledHeader"], {
        ref: navRef,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("figure", {
                className: "menu-icon",
                onClick: handleMenu,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$menu$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$menu$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                    alt: "menuIcon"
                }, void 0, false, {
                    fileName: "[project]/src/components/Header/index.jsx",
                    lineNumber: 142,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Header/index.jsx",
                lineNumber: 141,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("figure", {
                className: "logo-holder",
                onClick: ()=>router.push("/"),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                    alt: "IntD Logo"
                }, void 0, false, {
                    fileName: "[project]/src/components/Header/index.jsx",
                    lineNumber: 145,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Header/index.jsx",
                lineNumber: 144,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("figure", {
                className: "logo-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2d$sm$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logo$2d$sm$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                    alt: "IntD Logo"
                }, void 0, false, {
                    fileName: "[project]/src/components/Header/index.jsx",
                    lineNumber: 148,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Header/index.jsx",
                lineNumber: 147,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "pages-holder",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: pathname === "/" ? "page active" : "page",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$dashboard$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$dashboard$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                alt: "Dashboard Icon"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 152,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                className: "text",
                                children: "Dashboard"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 153,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Header/index.jsx",
                        lineNumber: 151,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/my-wallet",
                        className: pathname === "/my-wallet" ? "page active" : "page",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$wallet$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$wallet$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                alt: "Wallet Icon"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 156,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                className: "text",
                                children: "My Wallet"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 157,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Header/index.jsx",
                        lineNumber: 155,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "notification",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$notification$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$notification$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                            alt: "Notification Icon"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Header/index.jsx",
                            lineNumber: 160,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Header/index.jsx",
                        lineNumber: 159,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "logout",
                        onClick: ()=>handleLogout(),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logout$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logout$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                            alt: "Logout Icon"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Header/index.jsx",
                            lineNumber: 163,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Header/index.jsx",
                        lineNumber: 162,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: userDropDown ? "user-info active" : "user-info",
                        onClick: ()=>setUserDropDown(!userDropDown),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("figure", {
                                className: "user-image",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                    alt: "avatar",
                                    width: 100,
                                    height: 100
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Header/index.jsx",
                                    lineNumber: 169,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 168,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                className: "user-name",
                                children: [
                                    userDetails?.user?.first_name,
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("br", {}, void 0, false, {
                                        fileName: "[project]/src/components/Header/index.jsx",
                                        lineNumber: 172,
                                        columnNumber: 57
                                    }, this),
                                    " ",
                                    userDetails?.user?.last_name
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 171,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$down$2d$arrow$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$down$2d$arrow$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                alt: "downArrow",
                                className: "arrow"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 174,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "dropdown",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        className: "head",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("figure", {
                                                className: "user-image",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                    alt: "avatar",
                                                    width: 100,
                                                    height: 100
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Header/index.jsx",
                                                    lineNumber: 178,
                                                    columnNumber: 33
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Header/index.jsx",
                                                lineNumber: 177,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                        className: "user-name",
                                                        children: [
                                                            userDetails?.user?.first_name,
                                                            " ",
                                                            userDetails?.user?.last_name
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/Header/index.jsx",
                                                        lineNumber: 181,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: "mailto:Kylemachar@gmail.com",
                                                        children: userDetails?.user?.email
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Header/index.jsx",
                                                        lineNumber: 184,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Header/index.jsx",
                                                lineNumber: 180,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Header/index.jsx",
                                        lineNumber: 176,
                                        columnNumber: 25
                                    }, this),
                                    pages?.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            href: item.href,
                                            className: `dropdown-item ${pathname === item.href ? "active" : ""}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    src: item.icon,
                                                    alt: item.label
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Header/index.jsx",
                                                    lineNumber: 192,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                    children: item.label
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/Header/index.jsx",
                                                    lineNumber: 193,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, index, true, {
                                            fileName: "[project]/src/components/Header/index.jsx",
                                            lineNumber: 188,
                                            columnNumber: 29
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 175,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Header/index.jsx",
                        lineNumber: 165,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Header/index.jsx",
                lineNumber: 150,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "nav-links",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "head",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("figure", {
                                className: "user-image",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$avatar$2e$png__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                    alt: "avatar",
                                    width: 100,
                                    height: 100
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Header/index.jsx",
                                    lineNumber: 202,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 201,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "user-name",
                                        children: "Kyle Machar"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Header/index.jsx",
                                        lineNumber: 205,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: "mailto:Kylemachar@gmail.com",
                                        children: "Kylemachar@gmail.com"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Header/index.jsx",
                                        lineNumber: 206,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 204,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Header/index.jsx",
                        lineNumber: 200,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("ul", {
                        children: navData?.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: item?.link,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("li", {
                                    className: pathname == item.link && "active",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            src: item.icon,
                                            alt: item.label
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Header/index.jsx",
                                            lineNumber: 213,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                            children: item.label
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Header/index.jsx",
                                            lineNumber: 214,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Header/index.jsx",
                                    lineNumber: 212,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 211,
                                columnNumber: 25
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/Header/index.jsx",
                        lineNumber: 209,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                        className: "logout",
                        onClick: ()=>handleLogout(),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logout$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logout$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                alt: "Logout Icon"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Header/index.jsx",
                                lineNumber: 220,
                                columnNumber: 21
                            }, this),
                            "Logout"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Header/index.jsx",
                        lineNumber: 219,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Header/index.jsx",
                lineNumber: 199,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Header/index.jsx",
        lineNumber: 140,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Header;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/assets/images/body-img.png [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/body-img.cdbcb711.png");}}),
"[project]/src/assets/images/body-img.png.mjs { IMAGE => \"[project]/src/assets/images/body-img.png [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$body$2d$img$2e$png__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/body-img.png [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$body$2d$img$2e$png__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 1929,
    height: 1929,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA0UlEQVR42lWQOw6CQBCGZ3cpfISSI3gFi4VDGF+VkSXxBJJAgBoKSt4dRI+AtkbuItdYZAyNxZdM5vX/MzBbzIDvOLFqi9qtza7tlZ3rMzX2Bpkv5wDrzZpEfaSkMlWLodAQjOM+VnAQLs2FJjJRy6FcjegjBsaFLFSzMSl4D4/lQ65hoRoqMYFNWtAFDPynz3Dt1GBNGJjzOo+BaATNZPaTwMI0vUIf5m2U4HtO4k+s5DL/Mxn2oaIfdQJ4Ct9ycmpO1H27zHk5TNwF5QdO8AVfjvVxXiuwxm8AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
}}),
"[project]/src/context/AuthContext.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "AuthContext": (()=>AuthContext),
    "AuthContextProvider": (()=>AuthContextProvider)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Toast/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/helpers/common.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/authService.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/router.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["createContext"])();
const AuthContextProvider = ({ children })=>{
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isLoggedIn, setIsLoggedIn] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(!!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d")));
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const verifyEmail = async (payload)=>{
        try {
            setLoading(true);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].verifyEmail(payload);
            if (!res?.token) {
                throw new Error(res?.message);
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["setCookie"])(("TURBOPACK compile-time value", "intd_d"), res?.token);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                    type: "success",
                    message: res.message
                });
                setLoading(false);
                return true;
            }
        } catch (err) {
            setLoading(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                type: "error",
                message: err.message
            });
        }
    };
    const onLogin = async ({ email, password })=>{
        setLoading(true);
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].login({
                email,
                password
            });
            if (!res?.token) {
                throw new Error(res?.message);
            }
            setIsLoggedIn(true);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["setCookie"])(("TURBOPACK compile-time value", "intd_d"), res?.token);
            setLoading(false);
            const userDetails = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].fetchUserDetails();
            if (userDetails?.user?.status === "VERIFY_EMAIL") {
                router.push("/verify-email");
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                    type: "info",
                    message: "Pleader Verify Your Email"
                });
            }
            if (userDetails?.user?.status === "KYC_VERIFICATION") {
                router.push("/kyc-verification");
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                    type: "info",
                    message: "Pleader Verify Your KYC"
                });
            }
            if (userDetails?.user?.status === "KYC_VERIFICATION_INITIATED") {
                router.push("/kyc-verification-pending");
            }
            if (userDetails?.user?.status === "ACTIVE") {
                router.push("/");
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                    type: "success",
                    message: "Login Successfully"
                });
            }
            return true;
        } catch ({ message }) {
            setIsLoggedIn(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                type: "error",
                message
            });
            return false;
        } finally{
            setLoading(false);
        }
    };
    const contextValue = {
        loading,
        verifyEmail,
        onLogin,
        isLoggedIn
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(AuthContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/AuthContext.js",
        lineNumber: 80,
        columnNumber: 12
    }, this);
};
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/context/loadingContext.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "LoadingContext": (()=>LoadingContext),
    "LoadingContextProvider": (()=>LoadingContextProvider)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
;
;
const context = {};
const LoadingContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["createContext"])(context);
const LoadingContextProvider = ({ children })=>{
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        setLoading(false);
        const timer = setTimeout(()=>{
            setLoading(false);
        }, 1000);
        // Cancel the timer while unmounting
        return ()=>clearTimeout(timer);
    }, []);
    const contextValues = {
        loading
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(LoadingContext.Provider, {
        value: contextValues,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/loadingContext.jsx",
        lineNumber: 23,
        columnNumber: 12
    }, this);
};
}}),
"[project]/src/components/Loader/Loader.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledLoader": (()=>StyledLoader)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledLoader = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  position: fixed;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.8);
  z-index: 9999;

  .loader {
    display: block;
    position: relative;
    width: 60px;
    height: 60px;
    background: #fff;
    border-radius: 50%;
    overflow: hidden;
  }
  .loader:after {
    content: "";
    position: absolute;
    inset: 8px;
    margin: auto;
    background: rgba(0, 0, 0, 1);
    border-radius: 50%;
  }
  .loader:before {
    content: "";
    position: absolute;
    inset: 0px;
    margin: auto;
    background: var(--primary);
    animation: crlMugLoader 2s linear infinite alternate;
  }
  @keyframes crlMugLoader {
    0%,
    10% {
      transform: translateY(64px);
    }
    90%,
    100% {
      transform: translateY(0px);
    }
  }
`;
}}),
"[project]/src/components/Loader/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Loader$2f$Loader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Loader/Loader.styles.js [ssr] (ecmascript)");
;
;
;
const Loader = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Loader$2f$Loader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledLoader"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
            class: "loader"
        }, void 0, false, {
            fileName: "[project]/src/components/Loader/index.jsx",
            lineNumber: 7,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Loader/index.jsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = Loader;
}}),
"[project]/src/components/Process/Process.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledProcess": (()=>StyledProcess),
    "StyledProgressBar": (()=>StyledProgressBar)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledProcess = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  height: 100vh;
  display: flex;
  align-items: center;
  text-align: center;
  padding: 0 20px;
  height: calc(100vh - 95px);

  @media (min-width: 768px) {
    height: calc(100vh - 105px);
  }

  .gif-holder {
    width: 90px;
    height: 90px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 247, 204, 0.1);
    border-radius: 100px;
    margin: 0 auto 15px;
    @media (min-width: 576px) {
      width: 120px;
      height: 120px;
      margin: 0 auto 25px;
    }
    @media (min-width: 768px) {
      width: 150px;
      height: 150px;
      margin: 0 auto 35px;
    }

    img {
      width: 70px;
      height: 70px;
      @media (min-width: 576px) {
        width: 90px;
        height: 90px;
      }
      @media (min-width: 768px) {
        width: 110px;
        height: 110px;
      }
    }
  }

  .heading {
    display: block;
    font-size: 28px;
    line-height: 34px;
    font-weight: 700;
    margin: 0 0 15px;
    @media (min-width: 768px) {
      font-size: 34px;
      line-height: 38px;
    }
  }

  .text {
    display: block;
    white-space: pre-line;
    margin: 0 0 20px;
    @media (min-width: 768px) {
      margin: 0 0 30px;
    }
  }

  .error {
    width: 100%;
    max-width: 280px;
    font-size: 12px;
    line-height: 16px;
    font-weight: 500;
    display: flex;
    align-items: center;
    background: var(--off-white);
    color: var(--text-color);
    gap: 5px;
    padding: 6px 16px;
    border-radius: 8px;
    margin: 0 auto 16px;
  }

  button {
    @media (max-width: 575px) {
      width: 100%;
    }
  }

  .btn-holder {
    margin: 0 0 16px;
  }

  .back-btn {
    button {
      color: var(--white);
    }
  }
`;
const StyledProgressBar = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  content: "";
  width: 225px;
  height: 10px;
  background: var(--text-color);
  border-radius: 3px;
  margin: 0 auto;
  position: relative;

  &:before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    width: ${({ $progress })=>$progress && $progress};
    background: var(--primary);
    border-radius: 3px;
  }
`;
}}),
"[project]/src/assets/images/note-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/note-icon.5a1f0e6d.svg");}}),
"[project]/src/assets/images/note-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/note-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$note$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/note-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$note$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 18,
    height: 18,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/inProcess-gif.gif [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/inProcess-gif.d96967f6.gif");}}),
"[project]/src/assets/images/inProcess-gif.gif.mjs { IMAGE => \"[project]/src/assets/images/inProcess-gif.gif [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$inProcess$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/inProcess-gif.gif [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$inProcess$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 500,
    height: 500,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/request-successful-gif.gif [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/request-successful-gif.def1b855.gif");}}),
"[project]/src/assets/images/request-successful-gif.gif.mjs { IMAGE => \"[project]/src/assets/images/request-successful-gif.gif [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$request$2d$successful$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/request-successful-gif.gif [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$request$2d$successful$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 500,
    height: 505,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/error-gif.gif [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/error-gif.c750513e.gif");}}),
"[project]/src/assets/images/error-gif.gif.mjs { IMAGE => \"[project]/src/assets/images/error-gif.gif [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$error$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/error-gif.gif [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$error$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 500,
    height: 500,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/components/Process/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Process$2f$Process$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Process/Process.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$note$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$note$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/note-icon.svg.mjs { IMAGE => "[project]/src/assets/images/note-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Button/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$inProcess$2d$gif$2e$gif$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$inProcess$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/inProcess-gif.gif.mjs { IMAGE => "[project]/src/assets/images/inProcess-gif.gif [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$request$2d$successful$2d$gif$2e$gif$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$request$2d$successful$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/request-successful-gif.gif.mjs { IMAGE => "[project]/src/assets/images/request-successful-gif.gif [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$error$2d$gif$2e$gif$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$error$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/error-gif.gif.mjs { IMAGE => "[project]/src/assets/images/error-gif.gif [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$SubmitContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/context/SubmitContext.js [ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
const Process = ({ data })=>{
    const [progress, setProgress] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(0);
    const { setProcess } = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$SubmitContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["SubmitContext"]);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        if (data?.inProcess) {
            setProgress(0); // Reset progress
            const interval = setInterval(()=>{
                setProgress((prev)=>{
                    if (prev >= 90) {
                        clearInterval(interval);
                        return prev;
                    }
                    return prev + 10; // Increment progress
                });
            }, 100);
            return ()=>clearInterval(interval); // Cleanup on unmount
        } else {
            setProgress(100); // Complete progress when request is done
        }
    }, [
        data?.inProcess
    ]);
    function handleBtnClick(onClick) {
        setProcess(false);
        onClick();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Process$2f$Process$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledProcess"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "gif-holder",
                    children: data?.type === "success" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$request$2d$successful$2d$gif$2e$gif$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$request$2d$successful$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "gif"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Process/index.jsx",
                        lineNumber: 45,
                        columnNumber: 25
                    }, this) : data?.type === "error" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$error$2d$gif$2e$gif$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$error$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "gif"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Process/index.jsx",
                        lineNumber: 47,
                        columnNumber: 25
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$inProcess$2d$gif$2e$gif$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$inProcess$2d$gif$2e$gif__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "gif"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Process/index.jsx",
                        lineNumber: 49,
                        columnNumber: 25
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Process/index.jsx",
                    lineNumber: 43,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                    className: "heading",
                    children: data?.heading
                }, void 0, false, {
                    fileName: "[project]/src/components/Process/index.jsx",
                    lineNumber: 52,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                    className: "text",
                    children: data?.text
                }, void 0, false, {
                    fileName: "[project]/src/components/Process/index.jsx",
                    lineNumber: 53,
                    columnNumber: 17
                }, this),
                data?.error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "error",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$note$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$note$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                            alt: "noteIcon"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Process/index.jsx",
                            lineNumber: 56,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                            children: "Password reset request error (ERROR 404)"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Process/index.jsx",
                            lineNumber: 57,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Process/index.jsx",
                    lineNumber: 55,
                    columnNumber: 21
                }, this),
                data?.inProcess ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Process$2f$Process$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledProgressBar"], {
                    $progress: `${progress}%`
                }, void 0, false, {
                    fileName: "[project]/src/components/Process/index.jsx",
                    lineNumber: 61,
                    columnNumber: 21
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                    children: [
                        data?.btnText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "btn-holder",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                width: "350px",
                                variant: data?.variant,
                                onClick: ()=>handleBtnClick(data?.onClick),
                                children: data?.btnText
                            }, void 0, false, {
                                fileName: "[project]/src/components/Process/index.jsx",
                                lineNumber: 66,
                                columnNumber: 33
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Process/index.jsx",
                            lineNumber: 65,
                            columnNumber: 29
                        }, this),
                        data?.backBtn && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "back-btn",
                            onClick: data?.backBtn,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                children: "Go Back!"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Process/index.jsx",
                                lineNumber: 76,
                                columnNumber: 33
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Process/index.jsx",
                            lineNumber: 75,
                            columnNumber: 29
                        }, this)
                    ]
                }, void 0, true)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Process/index.jsx",
            lineNumber: 42,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Process/index.jsx",
        lineNumber: 41,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Process;
}}),
"[project]/src/context/SubmitContext.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "SubmitContext": (()=>SubmitContext),
    "SubmitContextProvider": (()=>SubmitContextProvider)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Process$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Process/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
;
;
;
const SubmitContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["createContext"])();
const SubmitContextProvider = ({ children })=>{
    const [process, setProcess] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])({});
    function handleData(e) {
        setProcess(true);
        setData(e);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(SubmitContext.Provider, {
        value: {
            handleData,
            setProcess
        },
        children: [
            process == false && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                children: children
            }, void 0, false),
            process && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Process$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                data: data
            }, void 0, false, {
                fileName: "[project]/src/context/SubmitContext.js",
                lineNumber: 16,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/context/SubmitContext.js",
        lineNumber: 14,
        columnNumber: 9
    }, this);
};
}}),
"[project]/src/pages/_app.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "GlobalStyle": (()=>GlobalStyle),
    "StyledLayout": (()=>StyledLayout),
    "StyledUpdate": (()=>StyledUpdate),
    "default": (()=>App)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__ = __turbopack_import__("[externals]/react-toastify [external] (react-toastify, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Layout.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/context/AuthContext.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$loadingContext$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/context/loadingContext.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/router.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Loader$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Loader/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$SubmitContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/context/SubmitContext.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
;
;
;
;
;
const GlobalStyle = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["createGlobalStyle"]`

  * {
    box-sizing: border-box;
    font-size: 100%;
    scroll-behavior: smooth;
    scroll-padding-top: 200px;
  }
  *:before,
  *:after,
  * {
    box-sizing: border-box;
  }

  body {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font: var(--font-size-base) / var(--line-height-base) var(--base-font-sans-serif);
    background: var(--black);
    color: var(--white);
    font-weight: 300;
    position: relative;
    min-width: 375px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;


    &.nav-active {
      overflow: hidden !important;

      .overlay {
        visibility: visible;
        opacity: 1;
      }
    }

    
  }
  
  .overlay {
  visibility: hidden;
  opacity: 0;
  transition: all ease-in-out 0.3s;
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 5;
}

  .container {
    max-width: 1380px;
    margin: 0 auto;
    padding: 0 15px;
     @media (min-width: 768px) {
         padding: 0 20px;

    }
  }
  
  #wrapper {
    width: 100%;
    padding: 65px 10px 10px;
    position: relative;
    overflow: hidden;
    @media (min-width: 768px){
      padding: 95px 10px 10px;

    }
  }


  img {
    display: block;
    max-width: 100%;
    height: auto;
  }

  ul {

    list-style: none;
    padding: 0;
    margin: 0;
  }

  textarea {
    resize: vertical;
    vertical-align: top;
  }

  button,
  input[type="button"],
  input[type="reset"],
  input[type="file"],
  input[type="submit"] {
    cursor: pointer;
    font-family: inherit;
  }

  form,
  fieldset {
    margin: 0;
    padding: 0;
    border-style: none;
  }
  a {
    text-decoration: none;
    color: var(--blue);
  }

  input[type="search"]::-webkit-search-decoration,
  input[type="search"]::-webkit-search-cancel-button,
  input[type="search"]::-webkit-search-results-button,
  input[type="search"]::-webkit-search-results-decoration {
    display: none;
  }

  button {
    transition: opacity var(--animation-speed) ease-in-out,
      background var(--animation-speed) ease-in-out,
      visibility var(--animation-speed) ease-in-out,
      border var(--animation-speed) ease-in-out,
      color var(--animation-speed) ease-in-out;
  }

  button {
    padding: 0;
    border: none;
    background: none;
    outline: none;
    font-family: var(--font-size-base);
  }
  .bold {
    font-size: 20px;
    line-height: 24px;
    font-weight: 400;
    @media (min-width: 767px) {
      font-size: 30px;
      line-height: 34px;
    }
  }

  table {
    width: 100%;
  }

  h1,
  .h1,
  h2,
  .h2,
  h3,
  .h3,
  h4,
  .h4,
  h5,
  .h5,
  h6,
  .h6 {
    margin: 0 0 10px;
    color: var(--body-text);
    font-weight: 500;
    @media (min-width: 576px) {
      margin: 0 0 15px;

    }
  }

  h1,
  .h1 {
    font-size: 24px;
    line-height: 30px;
    font-weight: 700;
    
    @media (min-width: 576px) {
      font-size: 40px;
      line-height: 44px;
      
    }
    @media (min-width: 768px) {
      font-size: 50px;
      line-height: 55px;
    }
  }

  h2,
  .h2 {
    font-size: 27px;
    line-height: 31px;
    font-weight: 700;
    
    @media (min-width: 576px) {
      font-size: 35px;
      line-height: 40px;

    }
    @media (min-width: 992px) {
      font-size: 48px;
      line-height: 49px;
    }
  }
  h3,
  .h3 {
    font-size: 28px;
    line-height: 32px;
  }
  h4,
  .h4 {
    font-size: 24px;
    line-height: 28px;
  }

.primary-heading{
      color: var(--primary);
}

.text-lg{
  @media (min-width: 768px){

    font-size: 18px;
    line-height: 22px;
  }
}
  p {
    margin: 0 0 15px;
    &:last-child {
      margin: 0;
    }
  }

  br {

    @media(max-width: 991px){
      display: none;
    }
  }

  ::-webkit-scrollbar {
    width: 8px;
    height: 20px;
  }

  /* Track */
  ::-webkit-scrollbar-track {
    border-radius: 15px;
    background: var(--gray-50);
  }

  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: var(--primary);
    border-radius: 10px;
  }

  /* Handle on hover */
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    appearance: none;
    margin: 0;
  }
   input:-webkit-autofill,
  textarea:-webkit-autofill {
    background-color: transparent !important;
    transition: background-color 5000s ease-in-out 0s;
  }

  input:-webkit-autofill:focus,
  textarea:-webkit-autofill:focus {
    background-color: transparent !important;
  }
  figure {
    margin: 0;
  }
  /* Firefox */
  input[type="number"] {
    appearance: textfield;
  }

  .gradientWrap {
    background: var(--gradient);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .react-loading-skeleton{
    --base-color:var(--primary);
  }

  `;
const StyledLayout = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["styled"].div`
    .bg {
        position: absolute;
        top: -800px;
        max-width: 1600px;
        left: 50%;
        transform: translateX(-50%);
        z-index: -1;
    }
`;
const StyledUpdate = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["styled"].div`
    height: calc(100vh - 75px);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    h1 {
        font-size: 26px;
        line-height: 30px;
        text-align: center;

        @media (min-width: 576px) {
            font-size: 32px;
            line-height: 36px;
        }
    }

    p {
        text-align: center;
        margin: 0 0 26px;

        @media (max-width: 575px) {
            font-size: 14px;
            line-height: 18px;
        }
    }

    form {
        width: 100%;
        max-width: 550px;

        .input-wrapper {
            backdrop-filter: blur(10px);
            border: 1px solid var(--dark-100);
            border-radius: 16px;
            padding: 15px;
            margin: 0 0 26px;

            @media (min-width: 576px) {
                padding: 26px;
            }
        }

        .btn-holder {
            display: flex;
            justify-content: center;
            margin: 0 0 20px;

            &:last-child {
                margin: 0;
                button {
                    color: var(--white);
                }
            }
        }
    }

    @media (min-width: 768px) {
        height: calc(100vh - 105px);
    }
`;
const StyledToastContainer = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["styled"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__["ToastContainer"])`
    z-index: 99999;

    .Toastify__toast {
        padding: 0;
        min-height: 0;
        border-radius: 8px;
        font-family: inherit;
    }
    .Toastify__toast--default {
        background: none;
    }
    .Toastify__toast-body {
        padding: 0;
    }
    .Toastify__close-button {
        position: absolute;
        top: 50%;
        right: 8px;
        transform: translateY(-50%);
    }
`;
function App({ Component, pageProps }) {
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        const handleRouteChangeStart = ()=>{
            setIsLoading(true);
            disableScroll();
        };
        const handleRouteChangeComplete = ()=>{
            setIsLoading(false);
            enableScroll();
        };
        const disableScroll = ()=>{
            document.body.style.overflow = "hidden";
            document.documentElement.style.overflow = "hidden";
            document.documentElement.style.height = "100%";
        };
        const enableScroll = ()=>{
            document.body.style.overflow = "";
            document.documentElement.style.overflow = "";
            document.documentElement.style.height = "";
        };
        router.events.on("routeChangeStart", handleRouteChangeStart);
        router.events.on("routeChangeComplete", handleRouteChangeComplete);
        window.onload = ()=>{
            setIsLoading(false);
        };
        return ()=>{
            router.events.off("routeChangeStart", handleRouteChangeStart);
            router.events.off("routeChangeComplete", handleRouteChangeComplete);
            window.onload = null;
        };
    }, [
        router
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(GlobalStyle, {}, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 438,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(StyledToastContainer, {}, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 439,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["AuthContextProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$loadingContext$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["LoadingContextProvider"], {
                    children: [
                        isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Loader$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/pages/_app.js",
                            lineNumber: 442,
                            columnNumber: 35
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$SubmitContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["SubmitContextProvider"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(Component, {
                                    ...pageProps
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/_app.js",
                                    lineNumber: 445,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/pages/_app.js",
                                lineNumber: 444,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/pages/_app.js",
                            lineNumber: 443,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/_app.js",
                    lineNumber: 441,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 440,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/components/Layout.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Header$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Header/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$body$2d$img$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$body$2d$img$2e$png__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/body-img.png.mjs { IMAGE => "[project]/src/assets/images/body-img.png [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$_app$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/pages/_app.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Header$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$_app$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Header$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$_app$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
;
const Layout = ({ children })=>{
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const layout = [
        "/",
        "/my-wallet",
        "/buy-intd",
        "/settings",
        "/update-name",
        "/update-password",
        "/transfer-details",
        "/donate-money",
        "/privacy-policy",
        "/terms-and-conditions",
        "/initiate-investment",
        "/get-help"
    ];
    const showLayout = layout.includes(pathname);
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        const handleScroll = ()=>{
            if (window.scrollY > 50) {
                document.body.classList.add("scrolled");
            } else {
                document.body.classList.remove("scrolled");
            }
        };
        window.addEventListener("scroll", handleScroll);
        // Cleanup on component unmount
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$_app$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledLayout"], {
        children: showLayout ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            id: "wrapper",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                    className: "overlay"
                }, void 0, false, {
                    fileName: "[project]/src/components/Layout.jsx",
                    lineNumber: 46,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$body$2d$img$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$body$2d$img$2e$png__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                    alt: "bg",
                    className: "bg"
                }, void 0, false, {
                    fileName: "[project]/src/components/Layout.jsx",
                    lineNumber: 47,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Header$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/Layout.jsx",
                    lineNumber: 48,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/components/Layout.jsx",
                    lineNumber: 49,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Layout.jsx",
            lineNumber: 45,
            columnNumber: 17
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/Layout.jsx",
            lineNumber: 52,
            columnNumber: 17
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Layout.jsx",
        lineNumber: 43,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Layout;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/pages/_app.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "GlobalStyle": (()=>GlobalStyle),
    "StyledLayout": (()=>StyledLayout),
    "StyledUpdate": (()=>StyledUpdate),
    "default": (()=>App)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__ = __turbopack_import__("[externals]/react-toastify [external] (react-toastify, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Layout.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/context/AuthContext.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$loadingContext$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/context/loadingContext.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/router.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Loader$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Loader/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$SubmitContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/context/SubmitContext.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
;
;
;
;
;
const GlobalStyle = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["createGlobalStyle"]`

  * {
    box-sizing: border-box;
    font-size: 100%;
    scroll-behavior: smooth;
    scroll-padding-top: 200px;
  }
  *:before,
  *:after,
  * {
    box-sizing: border-box;
  }

  body {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font: var(--font-size-base) / var(--line-height-base) var(--base-font-sans-serif);
    background: var(--black);
    color: var(--white);
    font-weight: 300;
    position: relative;
    min-width: 375px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;


    &.nav-active {
      overflow: hidden !important;

      .overlay {
        visibility: visible;
        opacity: 1;
      }
    }

    
  }
  
  .overlay {
  visibility: hidden;
  opacity: 0;
  transition: all ease-in-out 0.3s;
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 5;
}

  .container {
    max-width: 1380px;
    margin: 0 auto;
    padding: 0 15px;
     @media (min-width: 768px) {
         padding: 0 20px;

    }
  }
  
  #wrapper {
    width: 100%;
    padding: 65px 10px 10px;
    position: relative;
    overflow: hidden;
    @media (min-width: 768px){
      padding: 95px 10px 10px;

    }
  }


  img {
    display: block;
    max-width: 100%;
    height: auto;
  }

  ul {

    list-style: none;
    padding: 0;
    margin: 0;
  }

  textarea {
    resize: vertical;
    vertical-align: top;
  }

  button,
  input[type="button"],
  input[type="reset"],
  input[type="file"],
  input[type="submit"] {
    cursor: pointer;
    font-family: inherit;
  }

  form,
  fieldset {
    margin: 0;
    padding: 0;
    border-style: none;
  }
  a {
    text-decoration: none;
    color: var(--blue);
  }

  input[type="search"]::-webkit-search-decoration,
  input[type="search"]::-webkit-search-cancel-button,
  input[type="search"]::-webkit-search-results-button,
  input[type="search"]::-webkit-search-results-decoration {
    display: none;
  }

  button {
    transition: opacity var(--animation-speed) ease-in-out,
      background var(--animation-speed) ease-in-out,
      visibility var(--animation-speed) ease-in-out,
      border var(--animation-speed) ease-in-out,
      color var(--animation-speed) ease-in-out;
  }

  button {
    padding: 0;
    border: none;
    background: none;
    outline: none;
    font-family: var(--font-size-base);
  }
  .bold {
    font-size: 20px;
    line-height: 24px;
    font-weight: 400;
    @media (min-width: 767px) {
      font-size: 30px;
      line-height: 34px;
    }
  }

  table {
    width: 100%;
  }

  h1,
  .h1,
  h2,
  .h2,
  h3,
  .h3,
  h4,
  .h4,
  h5,
  .h5,
  h6,
  .h6 {
    margin: 0 0 10px;
    color: var(--body-text);
    font-weight: 500;
    @media (min-width: 576px) {
      margin: 0 0 15px;

    }
  }

  h1,
  .h1 {
    font-size: 24px;
    line-height: 30px;
    font-weight: 700;
    
    @media (min-width: 576px) {
      font-size: 40px;
      line-height: 44px;
      
    }
    @media (min-width: 768px) {
      font-size: 50px;
      line-height: 55px;
    }
  }

  h2,
  .h2 {
    font-size: 27px;
    line-height: 31px;
    font-weight: 700;
    
    @media (min-width: 576px) {
      font-size: 35px;
      line-height: 40px;

    }
    @media (min-width: 992px) {
      font-size: 48px;
      line-height: 49px;
    }
  }
  h3,
  .h3 {
    font-size: 28px;
    line-height: 32px;
  }
  h4,
  .h4 {
    font-size: 24px;
    line-height: 28px;
  }

.primary-heading{
      color: var(--primary);
}

.text-lg{
  @media (min-width: 768px){

    font-size: 18px;
    line-height: 22px;
  }
}
  p {
    margin: 0 0 15px;
    &:last-child {
      margin: 0;
    }
  }

  br {

    @media(max-width: 991px){
      display: none;
    }
  }

  ::-webkit-scrollbar {
    width: 8px;
    height: 20px;
  }

  /* Track */
  ::-webkit-scrollbar-track {
    border-radius: 15px;
    background: var(--gray-50);
  }

  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: var(--primary);
    border-radius: 10px;
  }

  /* Handle on hover */
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    appearance: none;
    margin: 0;
  }
   input:-webkit-autofill,
  textarea:-webkit-autofill {
    background-color: transparent !important;
    transition: background-color 5000s ease-in-out 0s;
  }

  input:-webkit-autofill:focus,
  textarea:-webkit-autofill:focus {
    background-color: transparent !important;
  }
  figure {
    margin: 0;
  }
  /* Firefox */
  input[type="number"] {
    appearance: textfield;
  }

  .gradientWrap {
    background: var(--gradient);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .react-loading-skeleton{
    --base-color:var(--primary);
  }

  `;
const StyledLayout = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["styled"].div`
    .bg {
        position: absolute;
        top: -800px;
        max-width: 1600px;
        left: 50%;
        transform: translateX(-50%);
        z-index: -1;
    }
`;
const StyledUpdate = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["styled"].div`
    height: calc(100vh - 75px);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    h1 {
        font-size: 26px;
        line-height: 30px;
        text-align: center;

        @media (min-width: 576px) {
            font-size: 32px;
            line-height: 36px;
        }
    }

    p {
        text-align: center;
        margin: 0 0 26px;

        @media (max-width: 575px) {
            font-size: 14px;
            line-height: 18px;
        }
    }

    form {
        width: 100%;
        max-width: 550px;

        .input-wrapper {
            backdrop-filter: blur(10px);
            border: 1px solid var(--dark-100);
            border-radius: 16px;
            padding: 15px;
            margin: 0 0 26px;

            @media (min-width: 576px) {
                padding: 26px;
            }
        }

        .btn-holder {
            display: flex;
            justify-content: center;
            margin: 0 0 20px;

            &:last-child {
                margin: 0;
                button {
                    color: var(--white);
                }
            }
        }
    }

    @media (min-width: 768px) {
        height: calc(100vh - 105px);
    }
`;
const StyledToastContainer = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["styled"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$toastify__$5b$external$5d$__$28$react$2d$toastify$2c$__esm_import$29$__["ToastContainer"])`
    z-index: 99999;

    .Toastify__toast {
        padding: 0;
        min-height: 0;
        border-radius: 8px;
        font-family: inherit;
    }
    .Toastify__toast--default {
        background: none;
    }
    .Toastify__toast-body {
        padding: 0;
    }
    .Toastify__close-button {
        position: absolute;
        top: 50%;
        right: 8px;
        transform: translateY(-50%);
    }
`;
function App({ Component, pageProps }) {
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        const handleRouteChangeStart = ()=>{
            setIsLoading(true);
            disableScroll();
        };
        const handleRouteChangeComplete = ()=>{
            setIsLoading(false);
            enableScroll();
        };
        const disableScroll = ()=>{
            document.body.style.overflow = "hidden";
            document.documentElement.style.overflow = "hidden";
            document.documentElement.style.height = "100%";
        };
        const enableScroll = ()=>{
            document.body.style.overflow = "";
            document.documentElement.style.overflow = "";
            document.documentElement.style.height = "";
        };
        router.events.on("routeChangeStart", handleRouteChangeStart);
        router.events.on("routeChangeComplete", handleRouteChangeComplete);
        window.onload = ()=>{
            setIsLoading(false);
        };
        return ()=>{
            router.events.off("routeChangeStart", handleRouteChangeStart);
            router.events.off("routeChangeComplete", handleRouteChangeComplete);
            window.onload = null;
        };
    }, [
        router
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(GlobalStyle, {}, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 438,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(StyledToastContainer, {}, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 439,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["AuthContextProvider"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$loadingContext$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["LoadingContextProvider"], {
                    children: [
                        isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Loader$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/pages/_app.js",
                            lineNumber: 442,
                            columnNumber: 35
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Layout$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$SubmitContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["SubmitContextProvider"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(Component, {
                                    ...pageProps
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/_app.js",
                                    lineNumber: 445,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/pages/_app.js",
                                lineNumber: 444,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/pages/_app.js",
                            lineNumber: 443,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/_app.js",
                    lineNumber: 441,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 440,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/assets/images/email-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/email-icon.5cc1a9bf.svg");}}),
"[project]/src/assets/images/email-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/email-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$email$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/email-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$email$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 18,
    height: 18,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/assets/images/password-icon.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/password-icon.84bb9bc5.svg");}}),
"[project]/src/assets/images/password-icon.svg.mjs { IMAGE => \"[project]/src/assets/images/password-icon.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$password$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/password-icon.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$password$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 18,
    height: 18,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/components/LoginTemplate/LoginTemplate.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledLoginTemplate": (()=>StyledLoginTemplate)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledLoginTemplate = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  display: flex;
  gap: 10px;
  padding: 15px;
  min-height: 100vh;

  .form-section {
    width: 100%;
    display: flex;
    align-items: center;
    @media (min-width: 992px) {
      width: 50%;
    }

    .form-holder {
      width: 100%;
      max-width: 400px;
      margin: 0 auto;

      .heading {
        display: block;
        font-size: 28px;
        line-height: 32px;
        font-weight: 700;
        text-align: center;
        margin: 0 0 16px;
      }

      .logo-holder {
        width: 100%;
        max-width: 260px;
        margin: 0 auto 16px;

        img {
          display: block;
          width: 100%;
          height: auto;
        }
      }

      p {
        text-align: center;
        margin: 0 0 25px;
      }
    }
  }

  .img-holder {
    width: 50%;
    border-radius: 30px;
    background: linear-gradient(to bottom, #2b4731 0%, #49724f 100%);
    position: relative;
    overflow: hidden;
    user-select: none;
    display: none;

    @media (min-width: 992px) {
      display: block;
    }

    img {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      display: block;
      max-width: 100%;
      height: auto;
    }
  }

  .login-form-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 0 0 25px;

    a {
      flex-shrink: 0;
      color: var(--golden);
    }
  }

  .btn {
    margin: 10px 0 20px;
  }

  .create-account {
    display: block;
    text-align: center;

    a {
      font-weight: 600;
      color: var(--primary);
      text-decoration: underline;
    }
  }

  .sign-up-head {
    display: flex;
    gap: 16px;
  }
`;
}}),
"[project]/src/assets/images/login-img.png [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/login-img.11fd156a.png");}}),
"[project]/src/assets/images/login-img.png.mjs { IMAGE => \"[project]/src/assets/images/login-img.png [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/login-img.png [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 1068,
    height: 1140,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA5klEQVR42iWOu4rCQBiFx4wmM242l8k9QXedyCa4ypqFBVltRcFLaWOholhYWYuNiLVvYG3nY2jpA/gs4ox+8Dcfh/8cABjCCyhi6V2z9HyKwT2AEKYN18yZvlXUXRK5n14JZZEMeAC9ISUjZXC5Xh53pu0TTcLRR1xIvirxDyh8h7VKLe4utpPr/ri+92etixGYCXsfADvvRC71qpPV4Lw7LO+9efOm2GqVOFoRiEhEqqkF9JfOG8P/M/0LN8yplq9HvDclYUnWbZIjnlHCStbBMpbZcvRczBOWZ/sKUYkAhTQ7yPUDF6keu86jYM0AAAAASUVORK5CYII=",
    blurWidth: 7,
    blurHeight: 8
};
}}),
"[project]/src/components/LoginTemplate/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginTemplate$2f$LoginTemplate$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/LoginTemplate/LoginTemplate.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/login-img.png.mjs { IMAGE => "[project]/src/assets/images/login-img.png [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/logo.svg.mjs { IMAGE => "[project]/src/assets/images/logo.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [ssr] (ecmascript)");
;
;
;
;
;
;
const LoginTemplate = ({ children })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginTemplate$2f$LoginTemplate$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledLoginTemplate"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "form-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "form-holder",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("figure", {
                            className: "logo-holder",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                alt: "logo"
                            }, void 0, false, {
                                fileName: "[project]/src/components/LoginTemplate/index.jsx",
                                lineNumber: 13,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/LoginTemplate/index.jsx",
                            lineNumber: 12,
                            columnNumber: 11
                        }, this),
                        children
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/LoginTemplate/index.jsx",
                    lineNumber: 11,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/LoginTemplate/index.jsx",
                lineNumber: 10,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("figure", {
                className: "img-holder",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                    alt: "loginImg"
                }, void 0, false, {
                    fileName: "[project]/src/components/LoginTemplate/index.jsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/LoginTemplate/index.jsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/LoginTemplate/index.jsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = LoginTemplate;
}}),
"[project]/src/components/molecules/Label/Label.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RequiredAsterisk": (()=>RequiredAsterisk),
    "StyledLabel": (()=>StyledLabel)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledLabel = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].label`
  font-size: 15px;
  line-height: 20px;
  color: var(--white);
  font-weight: 400;
  margin-bottom: ${({ $noLabelMargin })=>$noLabelMargin ? "0" : " 0.625rem"};
  display: block;
  pointer-events: ${({ $onlyRead })=>$onlyRead && "none"};
  ${({ labelIcon })=>labelIcon && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      display: flex;
      align-items: center;
    `}
  ${({ $labelReverse })=>$labelReverse && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      position: relative;
      .label {
        flex-direction: row-reverse;
      }
    `};
  .label {
    display: flex;
    align-items: center;
  }
`;
const RequiredAsterisk = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  color: var(--danger);
  font-size: 14px;
`;
}}),
"[project]/src/components/molecules/Label/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable jsx-a11y/no-static-element-interactions */ /* eslint-disable jsx-a11y/click-events-have-key-events */ __turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
// eslint-disable-next-line no-unused-vars
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Label$2f$Label$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Label/Label.styles.js [ssr] (ecmascript)");
;
;
;
function Label({ children, onlyRead, required, labelIcon, clear, labelReverse, noLabelMargin, onClear = ()=>{}, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Label$2f$Label$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledLabel"], {
            $onlyRead: onlyRead,
            labelIcon: labelIcon,
            $labelReverse: labelReverse,
            $noLabelMargin: noLabelMargin,
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    css: "display: flex; justify-content: space-between;",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            css: "display: flex; align-items: center;",
                            className: "label",
                            children: [
                                children,
                                required ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Label$2f$Label$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["RequiredAsterisk"], {
                                    children: "*"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/molecules/Label/index.jsx",
                                    lineNumber: 30,
                                    columnNumber: 25
                                }, this) : ""
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/molecules/Label/index.jsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        clear && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                            css: "color: var(--danger); cursor: pointer;",
                            onClick: onClear,
                            children: "Clear"
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/Label/index.jsx",
                            lineNumber: 33,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/molecules/Label/index.jsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this),
                labelIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                    css: "margin-left: 5px;",
                    children: labelIcon
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/Label/index.jsx",
                    lineNumber: 40,
                    columnNumber: 23
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/molecules/Label/index.jsx",
            lineNumber: 21,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
const __TURBOPACK__default__export__ = Label;
}}),
"[project]/src/components/molecules/FakeInput/index.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const FakeInput = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  display: block;
  position: relative;
  width: 18px;
  height: 18px;
  border: 1px solid ${({ $radioBorder })=>$radioBorder ?? "var(--white)"};
  margin-right: 8px;
  border-radius: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  line-height: 1px;

  ${({ $labelReverse })=>$labelReverse && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      position: absolute;
      right: 0;
      margin: 0 0 0 10px;
    `}

  .icon {
    color: transparent;
  }
`;
const __TURBOPACK__default__export__ = FakeInput;
}}),
"[project]/src/components/molecules/Input/Input.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledInput": (()=>StyledInput),
    "StyledTextarea": (()=>StyledTextarea),
    "styles": (()=>styles)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeInput$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/FakeInput/index.js [ssr] (ecmascript)");
;
;
const styles = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
  border: 1px solid
    ${({ $invalid })=>$invalid ? "var(--danger)" : "transparent"};
  outline: none;
  height: ${({ lg })=>lg ? "56px" : "45px"};
  padding: ${({ lg })=>lg ? "19px 30px" : "13px 15px"};
  width: 100%;
  transition: border var(--animation-speed) ease-in-out;
  font-family: inherit;
  color: var(--white);
  background: rgba(255, 255, 255, 0.16);
  font-size: 14px;
  line-height: 18px;
  font-weight: 400;
  border-radius: ${({ $rounded })=>$rounded ? "60px" : "10px"};
  padding-left: ${({ $prefix })=>$prefix && "2.5rem"};
  padding-right: ${({ $suffix, $button })=>{
    if ($suffix) return "2.5rem";
    if ($button) return "3.6rem";
    return "";
}};

  ${({ type })=>type === "search" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      transition: all var(--animation-speed) ease-in-out;

      ${({ responsive })=>responsive && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
          @media (max-width: 767px) {
            position: absolute;
            top: -22px;
            right: 7px;
            z-index: 9;
            box-shadow: 0px 23px 44px rgba(176, 183, 195, 0.3);
            background: var(--white);
            border: 1px solid var(--light);
            opacity: 0;
            visibility: hidden;
            transform: translateX(10px);
            width: 0;
          }
          @media (max-width: 575px) {
            top: 100%;
            left: 0;
            right: 0;
            width: 100%;
          }
        `}

      ${({ openSearch })=>openSearch && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
          @media (max-width: 767px) {
            opacity: 1;
            visibility: visible;
            transform: translateX(0);
            width: 350px;
          }
          @media (max-width: 575px) {
            transform: translateY(0);
            width: 100%;
          }
        `}
    `}

  ${({ disabled })=>disabled && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      background: var(--light);
      cursor: not-allowed;
      color: var(--light-gray);
    `}


  ::-webkit-input-placeholder {
    /* Chrome/Opera/Safari */
    color: var(--white);
    opacity: 0.6;
  }
  &::placeholder {
    color: var(--white);
  }
  ::-moz-placeholder {
    /* Firefox 19+ */
    color: var(--white);
    opacity: 0.6;
  }
  :-ms-input-placeholder {
    /* IE 10+ */
    color: var(--white);
    opacity: 0.6;
  }
  :-moz-placeholder {
    /* Firefox 18- */
    color: var(--white);
    opacity: 0.6;
  }

  &[type="radio"] {
    + ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeInput$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]} {
      border-radius: 100%;
      &:before {
        content: "";
        background: linear-gradient(116.03deg, #355b85 5.04%, #1b2e44 86.56%);
        border: 2px solid white;
        border-radius: 100%;
        width: 15px;
        height: 15px;
      }
    }
  }

  + ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeInput$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]} {
    transition: background var(--animation-speed) ease-in-out;
    &:before,
    .icon-check {
      position: absolute;
      top: 50%;
      left: 50%;
      opacity: 0;
      transform: translate(-50%, -50%);
      transition: opacity var(--animation-speed) ease-in-out;
    }
  }

  &[type="checkbox"] {
    + ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeInput$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]} {
      .icon-check {
        color: var(--white);
        font-size: var(--font-size-xs);
      }
    }
  }

  &[type="checkbox"],
  &[type="radio"] {
    display: none;
    &:checked {
      + ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeInput$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]} {
        background: var(--primary);
        border: 1px solid var(--secondary);

        .icon {
          color: var(--secondary);
        }

        .icon-check,
        &:before {
          opacity: 1;
        }
      }
    }
    &:disabled {
      ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeInput$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]} {
        opacity: 0.5;
      }
    }
  }
  &:disabled {
    opacity: 0.5;
  }
  &:-webkit-autofill {
    -webkit-text-fill-color: var(--white);
  }
`;
const StyledTextarea = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].textarea`
  ${styles}
  resize: vertical;
  min-height: 9.375rem;
  border-radius: 12px;
`;
const StyledInput = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].input`
  ${styles}
`;
}}),
"[project]/src/components/molecules/Input/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable react/display-name */ __turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$Input$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Input/Input.styles.js [ssr] (ecmascript)");
;
;
;
const Input = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["forwardRef"])(({ ...props }, ref)=>{
    const { type } = props;
    if (type === 'textarea') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$Input$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledTextarea"], {
            ...props,
            ref: ref
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/Input/index.jsx",
            lineNumber: 9,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$Input$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledInput"], {
        ...props,
        ref: ref
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/Input/index.jsx",
        lineNumber: 11,
        columnNumber: 10
    }, this);
});
const __TURBOPACK__default__export__ = Input;
}}),
"[project]/src/components/molecules/InputIcon/InputIcon.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledInputIcon": (()=>StyledInputIcon)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledInputIcon = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: ${({ $prefix })=>$prefix && "10px"};
  right: ${({ $suffix })=>$suffix && "10px"};
  color: ${({ $invalid })=>$invalid ? "var(--danger)" : "var(--white)"};
  font-size: 16px;
  line-height: 1px;
  background: none;
  border: none;
  padding: 0;
  z-index: 1;
  ${({ disabled })=>disabled && "opacity: 0.5"};
  i {
    display: block;
  }
`;
}}),
"[project]/src/components/molecules/InputIcon/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$InputIcon$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/InputIcon/InputIcon.styles.js [ssr] (ecmascript)");
;
;
;
function InputIcon({ prefix, invalid, suffix, children, disabled, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$InputIcon$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledInputIcon"], {
            $prefix: prefix,
            $invalid: invalid,
            $suffix: suffix,
            disabled: disabled,
            ...props,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                className: "pref-suf",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/InputIcon/index.jsx",
                lineNumber: 14,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/InputIcon/index.jsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
const __TURBOPACK__default__export__ = InputIcon;
}}),
"[project]/src/components/molecules/FakeLabel/FakeLabel.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "RequiredAsterisk": (()=>RequiredAsterisk),
    "StyledFakeLabel": (()=>StyledFakeLabel)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledFakeLabel = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  display: block;
  font-size: 16px;
  line-height: 20px;
  font-weight: 400;
  line-height: 1;
  color: ${({ $labelColor })=>$labelColor || "var(--white)"};
  /* color: var(--black); */
`;
const RequiredAsterisk = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  color: var(--danger);
  margin-left: 3px;
`;
}}),
"[project]/src/components/molecules/FakeLabel/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeLabel$2f$FakeLabel$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/FakeLabel/FakeLabel.styles.js [ssr] (ecmascript)");
;
;
;
function FakeLabel({ children, required, labelIcon, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeLabel$2f$FakeLabel$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledFakeLabel"], {
            ...props,
            children: [
                required ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeLabel$2f$FakeLabel$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["RequiredAsterisk"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/FakeLabel/index.jsx",
                    lineNumber: 9,
                    columnNumber: 21
                }, this) : "",
                children,
                labelIcon ?? null
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/molecules/FakeLabel/index.jsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
const __TURBOPACK__default__export__ = FakeLabel;
}}),
"[project]/src/styles/helpers.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ActionBtnHolder": (()=>ActionBtnHolder),
    "ActionsWrapper": (()=>ActionsWrapper),
    "Centered": (()=>Centered),
    "Flex": (()=>Flex),
    "InputHolder": (()=>InputHolder),
    "StyledFormGroup": (()=>StyledFormGroup),
    "Wrapper": (()=>Wrapper)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const Flex = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  display: flex;
  flex-wrap: ${(props)=>!props.nowrap && "wrap"};

  ${(props)=>props.direction === "column" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      flex-direction: column;
    `}

  ${(props)=>props.direction === "columnReverse" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      flex-direction: column;
    `}

  ${(props)=>props.justify === "center" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      justify-content: center;
    `}

  ${(props)=>props.justify === "space-between" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      justify-content: space-between;
    `}

  ${(props)=>props.justify === "end" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      justify-content: flex-end;
    `}

  ${(props)=>props.align === "top" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      align-items: flex-start;
    `}

  ${(props)=>props.align === "middle" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      align-items: center;
    `}

    ${(props)=>props.align === "bottom" && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      align-items: flex-end;
    `}
`;
const Centered = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
  display: flex;
  align-items: center;
  justify-content: center;
`;
const StyledFormGroup = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  width: 100%;
  min-width: ${({ $width })=>$width ? $width : ""};
  margin-bottom: ${({ $invalid, $noMargin })=>$invalid || $noMargin ? "0px" : "15px"};
  /* position: relative; */

  /* &:nth-last-child(1) {
    margin-bottom: 0;
  } */
  @media (min-width: 768px) {
    margin-bottom: ${({ $invalid, $noMargin })=>$invalid || $noMargin ? "0px" : "15px"};
  }
`;
const InputHolder = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  position: relative;
`;
const ActionBtnHolder = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  display: grid;
  grid-template-columns: repeat(
    ${({ numOfBtns })=>numOfBtns === 4 ? 4 : 3},
    minmax(20px, 20px)
  );
  align-items: center;
  justify-content: center;
  position: absolute;
  top: 5px;
  right: 17px;
  gap: 20px;
  margin: 0 auto;
  .tooltip-holder {
    display: flex;
    align-items: center;
    justify-content: center;

    &.red_dot {
      .detail-btn {
        position: relative;

        &:before {
          content: "";
          position: absolute;
          top: 0;
          right: 0;
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: var(--danger);
        }
      }
    }
  }
  .tooltip-holder:only-child {
    /* justify-content: flex-end;
    @media (min-width: 992px) {
      justify-content: center;
    } */
    @media (max-width: 992px) {
      grid-column: ${({ numOfBtns })=>numOfBtns === 4 ? `span 4 / span 4` : `span 3 / span 3`};
    }
  }
  @media (min-width: 992px) {
    position: static;
  }
  button {
    font-size: var(--font-size-xl);
    line-height: calc(var(--font-size-xl) + 0.3125rem);
    display: flex;
    align-items: center;
  }

  .delete-btn {
    color: var(--danger);
  }

  .detail-btn {
    color: var(--primary);
  }
`;
const Wrapper = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  padding: 0 15px;
  width: 100%;
  @media (min-width: 1500px) {
    padding: 0 50px;
  }
`;
const ActionsWrapper = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  .actions {
    @media (max-width: 650px) {
      flex-direction: column;
      gap: 15px !important;
    }
    @media (max-width: 576px) {
      width: 100%;
    }
    button {
      padding: 13px 15px;
      max-width: 100%;
    }
    .Search {
      @media (max-width: 576px) {
        width: 100% !important;
      }
    }
  }
`;
}}),
"[project]/src/components/molecules/Field/Field.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Error": (()=>Error),
    "InputHolder": (()=>InputHolder)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const Error = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  text-align: left;
  display: block;
  color: var(--danger);
  min-height: 26px;
  height: auto;
  opacity: 1;
  font-size: 12px;
  line-height: 16px;
  padding-top: 3px;
  /* margin-bottom: 10px; */
  &:first-letter {
    text-transform: uppercase;
  }
`;
const InputHolder = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  @media (min-width: 576px) {
    position: relative;
  }
  @media (max-width: 575px) {
    position: ${({ $searchField })=>!$searchField && 'relative'};
  }
`;
}}),
"[externals]/lodash/range.js [external] (lodash/range.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("lodash/range.js", () => require("lodash/range.js"));

module.exports = mod;
}}),
"[project]/src/components/molecules/DatePickerHeader/DatePickerHeader.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Arrows": (()=>Arrows),
    "HeadHolder": (()=>HeadHolder),
    "Select": (()=>Select),
    "SelectHolder": (()=>SelectHolder)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const HeadHolder = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10px 15px;
`;
const Arrows = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].button`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  line-height: 1;
  width: 25px;
  height: 25px;
`;
const Select = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].select`
  border: none;
  background: none;
  outline: none;
  font-weight: 400;
  font-size: 16px;
  line-height: 1;
  text-align: center;
  font-family: var(--base-font-sans-serif);
  option {
    font-size: 12px;
  }
`;
const SelectHolder = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  display: flex;
  align-items: center;
  select {
    margin: 0 10px;
  }
`;
}}),
"[project]/src/components/molecules/DatePickerHeader/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable jsx-a11y/no-onchange */ __turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
// eslint-disable-next-line no-unused-vars
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/helpers/common.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$lodash$2f$range$2e$js__$5b$external$5d$__$28$lodash$2f$range$2e$js$2c$__cjs$29$__ = __turbopack_import__("[externals]/lodash/range.js [external] (lodash/range.js, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$DatePickerHeader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/DatePickerHeader/DatePickerHeader.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$getYear$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/getYear.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/md/index.mjs [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$getMonth$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/getMonth.js [ssr] (ecmascript)");
;
;
;
;
;
;
;
;
function DatePickerHeader({ date, changeYear, changeMonth, decreaseMonth, increaseMonth, prevMonthButtonDisabled, nextMonthButtonDisabled }) {
    const years = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$lodash$2f$range$2e$js__$5b$external$5d$__$28$lodash$2f$range$2e$js$2c$__cjs$29$__["default"])(1920, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$getYear$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getYear"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getDateObject"])(new Date())) + 9, 1);
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$DatePickerHeader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["HeadHolder"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$DatePickerHeader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Arrows"], {
                type: "button",
                onClick: decreaseMonth,
                disabled: prevMonthButtonDisabled,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["MdKeyboardArrowLeft"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$DatePickerHeader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["SelectHolder"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$DatePickerHeader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Select"], {
                        value: months[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$getMonth$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getMonth"])(date)],
                        onChange: ({ target: { value } })=>changeMonth(months.indexOf(value)),
                        children: months.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("option", {
                                value: option,
                                children: option
                            }, option, false, {
                                fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                                lineNumber: 61,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$DatePickerHeader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Select"], {
                        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$getYear$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getYear"])(date),
                        onChange: ({ target: { value } })=>changeYear(value),
                        children: years.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("option", {
                                value: option,
                                children: option
                            }, option, false, {
                                fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                                lineNumber: 71,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                        lineNumber: 66,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$DatePickerHeader$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Arrows"], {
                type: "button",
                onClick: increaseMonth,
                disabled: nextMonthButtonDisabled,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["MdOutlineKeyboardArrowRight"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                    lineNumber: 82,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
                lineNumber: 77,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/DatePickerHeader/index.jsx",
        lineNumber: 45,
        columnNumber: 5
    }, this);
}
const __TURBOPACK__default__export__ = DatePickerHeader;
}}),
"[externals]/react-datepicker [external] (react-datepicker, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("react-datepicker", () => require("react-datepicker"));

module.exports = mod;
}}),
"[project]/src/components/molecules/DatePicker/DatePicker.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ButtonHolder": (()=>ButtonHolder),
    "StyledDateRange": (()=>StyledDateRange)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$datepicker__$5b$external$5d$__$28$react$2d$datepicker$2c$__cjs$29$__ = __turbopack_import__("[externals]/react-datepicker [external] (react-datepicker, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$Input$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Input/Input.styles.js [ssr] (ecmascript)");
;
;
;
;
const StyledDateRange = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$datepicker__$5b$external$5d$__$28$react$2d$datepicker$2c$__cjs$29$__["default"])`
  ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$Input$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["styles"]}
  padding-left: ${({ prefix })=>prefix && "2.5rem"};
  padding-right: ${({ $suffix })=>{
    if ($suffix) return "2.5rem";
    return "2rem";
}};
`;
const ButtonHolder = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 12px;
`;
}}),
"[project]/src/components/molecules/DatePicker/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable jsx-a11y/no-onchange */ __turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
// eslint-disable-next-line no-unused-vars
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/DatePickerHeader/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePicker$2f$DatePicker$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/DatePicker/DatePicker.styles.js [ssr] (ecmascript)");
;
;
;
;
function ReactDateRange({ prefix, suffix, disabled, excludeDateIntervals, invalid, error, onChange, timeOnly, excludeTimes, startTime, endTime, ...props }) {
    const today = new Date();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
        children: timeOnly ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePicker$2f$DatePicker$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledDateRange"], {
                    disabled: disabled,
                    prefix: prefix,
                    suffix: suffix,
                    invalid: invalid || error,
                    showTimeSelectOnly: true,
                    showTimeSelect: true,
                    selected: startTime,
                    startDate: startTime,
                    onChange: (_)=>{
                        onChange({
                            target: {
                                value: _,
                                name: "startTime"
                            }
                        });
                    },
                    timeIntervals: 30,
                    timeCaption: "Time",
                    dateFormat: "HH:mm",
                    placeholderText: "Select Start Time",
                    ...props
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/DatePicker/index.jsx",
                    lineNumber: 27,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePicker$2f$DatePicker$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledDateRange"], {
                    disabled: disabled,
                    prefix: prefix,
                    suffix: suffix,
                    invalid: invalid || error,
                    showTimeSelectOnly: true,
                    showTimeSelect: true,
                    selected: endTime,
                    endDate: endTime,
                    onChange: (_)=>{
                        onChange({
                            target: {
                                value: _,
                                name: "endTime"
                            }
                        });
                    },
                    timeIntervals: 30,
                    timeCaption: "Time",
                    dateFormat: "HH:mm",
                    placeholderText: "Select End Time",
                    ...props
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/DatePicker/index.jsx",
                    lineNumber: 45,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePicker$2f$DatePicker$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledDateRange"], {
            disabled: disabled,
            excludeDateIntervals: excludeDateIntervals,
            prefix: prefix,
            suffix: suffix,
            invalid: invalid || error,
            renderCustomHeader: ({ date, changeYear, changeMonth, decreaseMonth, increaseMonth, prevMonthButtonDisabled, nextMonthButtonDisabled })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePickerHeader$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    date: date,
                    changeYear: changeYear,
                    changeMonth: changeMonth,
                    decreaseMonth: decreaseMonth,
                    increaseMonth: increaseMonth,
                    prevMonthButtonDisabled: prevMonthButtonDisabled,
                    nextMonthButtonDisabled: nextMonthButtonDisabled
                }, void 0, false, {
                    fileName: "[project]/src/components/molecules/DatePicker/index.jsx",
                    lineNumber: 80,
                    columnNumber: 25
                }, void 0),
            minDate: today,
            ...props,
            onChange: (_)=>{
                onChange({
                    target: {
                        value: _,
                        name: props.name
                    }
                });
            }
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/DatePicker/index.jsx",
            lineNumber: 65,
            columnNumber: 17
        }, this)
    }, void 0, false);
}
const __TURBOPACK__default__export__ = ReactDateRange;
}}),
"[externals]/react-phone-number-input [external] (react-phone-number-input, esm_import)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
const mod = await __turbopack_external_import__("react-phone-number-input");

__turbopack_export_namespace__(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/src/components/molecules/PhoneNumberInput/PhoneNumberInput.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "PhoneWrapper": (()=>PhoneWrapper)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const PhoneWrapper = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["styled"].div`
  position: relative;
  font-size: 18px;
  line-height: 22px;
  font-weight: 400;
  font-family: var(--base-font-sans-serif);
  color: var(--white);
  label {
    display: block;
    margin-bottom: 10px;
  }
  .PhoneInput {
    /* background: #f1f1f1; */
    border: ${({ $invalid })=>$invalid ? "1px solid var(--danger)" : "1px solid transparent"};
    border-radius: 8px;
    /* background: rgba(255, 255, 255, 0.1); */
    color: var(--white);
  }
  .PhoneInput--focus {
    box-shadow: none;
  }
  .PhoneInputCountrySelect:focus + .PhoneInputCountryIcon--border {
    box-shadow: none;
  }
  .PhoneInputCountry {
    border-radius: 10px;
    width: 55px;
    display: flex;
    justify-content: flex-end;
    background: rgba(255, 255, 255, 0.2);
    margin-right: 10px;
    flex-shrink: 0;

    .PhoneInputCountryIcon {
      box-shadow: none;
      overflow: hidden;
      width: 22px;
      height: 22px;
      border-radius: 100px;
      &:focus {
        box-shadow: none;
      }
      img {
        width: 100%;
        object-fit: cover;
      }
    }
  }
  .PhoneInputCountrySelect {
    font-family: inherit;
    background: rgba(255, 255, 255, 0.1);
    font-size: 14px;
    line-height: 18px;
  }
  .PhoneInputCountrySelect > option:hover {
    background: rgba(255, 255, 255, 0.1);
    font-size: 14px;
    line-height: 18px;
  }
  .PhoneInputCountrySelectArrow {
    width: 0;
    height: 0;
    border-radius: 2px;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 5px solid #313131;
    border-bottom: none;
    opacity: 1;
    transform: none;
    visibility: hidden;
  }
  input {
    height: 45px;
    border-radius: 10px;
    border: none;
    padding: 0 0 0 10px;
    font-size: 14px;
    line-height: 18px;
    outline: none;
    margin: 0 !important;
    background: rgba(255, 255, 255, 0.2);
    font-weight: 400;
    color: var(--white);
    font-family: inherit;
    &::placeholder {
      color: var(--white);
    }
  }
  .error {
    font-size: 12px;
    line-height: 14px;
    font-weight: 400;
    position: absolute;
    left: 5px;
    bottom: -15px;
    color: var(--danger);
    p {
      margin: 0;
    }
  }
`;
}}),
"[project]/src/components/molecules/PhoneNumberInput/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$phone$2d$number$2d$input__$5b$external$5d$__$28$react$2d$phone$2d$number$2d$input$2c$__esm_import$29$__ = __turbopack_import__("[externals]/react-phone-number-input [external] (react-phone-number-input, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PhoneNumberInput$2f$PhoneNumberInput$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/PhoneNumberInput/PhoneNumberInput.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$helpers$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/styles/helpers.styles.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$phone$2d$number$2d$input__$5b$external$5d$__$28$react$2d$phone$2d$number$2d$input$2c$__esm_import$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$phone$2d$number$2d$input__$5b$external$5d$__$28$react$2d$phone$2d$number$2d$input$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
const PhoneNumberInput = ({ onChange, value, placeholder, country, defaultCountry = "US", bgWhite, noFlagWidth, error, invalid, prefix, suffix, noMargin, rounded, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$helpers$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledFormGroup"], {
        $noMargin: noMargin,
        $rounded: rounded,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PhoneNumberInput$2f$PhoneNumberInput$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["PhoneWrapper"], {
            ...props,
            $bgWhite: bgWhite,
            $noFlagWidth: noFlagWidth,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$phone$2d$number$2d$input__$5b$external$5d$__$28$react$2d$phone$2d$number$2d$input$2c$__esm_import$29$__["default"], {
                placeholder: placeholder,
                value: value,
                onChange: onChange,
                country: country,
                defaultCountry: defaultCountry,
                maxLength: 16,
                international: true,
                invalid: invalid || error,
                ...props
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/PhoneNumberInput/index.jsx",
                lineNumber: 26,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/PhoneNumberInput/index.jsx",
            lineNumber: 25,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/PhoneNumberInput/index.jsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = PhoneNumberInput;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[externals]/react-select [external] (react-select, esm_import)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
const mod = await __turbopack_external_import__("react-select");

__turbopack_export_namespace__(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/lodash/debounce.js [external] (lodash/debounce.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("lodash/debounce.js", () => require("lodash/debounce.js"));

module.exports = mod;
}}),
"[externals]/react-select/async [external] (react-select/async, esm_import)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
const mod = await __turbopack_external_import__("react-select/async");

__turbopack_export_namespace__(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/src/components/molecules/Select/Select.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "StyledSelect": (()=>StyledSelect),
    "StyledSelectAsync": (()=>StyledSelectAsync)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__ = __turbopack_import__("[externals]/react-select [external] (react-select, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select$2f$async__$5b$external$5d$__$28$react$2d$select$2f$async$2c$__esm_import$29$__ = __turbopack_import__("[externals]/react-select/async [external] (react-select/async, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$Input$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Input/Input.styles.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select$2f$async__$5b$external$5d$__$28$react$2d$select$2f$async$2c$__esm_import$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select$2f$async__$5b$external$5d$__$28$react$2d$select$2f$async$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
const Styles = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
  .react-select__control {
    ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$Input$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["styles"]}
    color: var(--white);
    min-height: inherit;
    padding-top: 0;
    padding-bottom: 0;
    padding-left: 20px;
    padding-right: 20px;
    font-size: 14px;
    border-color: ${({ error })=>error && "var(--danger) !important"};
    box-shadow: none;
    ${({ $gray })=>$gray && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
        background: var(--gray-4);
        /* border-color: var(--light-secondary); */
      `}
    &:hover {
      border-color: transparent;
    }
    &.react-select__control--is-focused,
    &.react-select__control--menu-is-open {
      /* border-color: var(--primary); */
      font-size: 14px;
    }
  }
  .react-select__placeholder {
    color: var(--light-gray);
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    max-width: calc(100% - 8px);
    /* font-size: 12px; */
  }
  .react-select__value-container {
    padding-left: 0;
    padding-right: 0;
  }
  .react-select__menu {
    background: rgba(0, 0, 0, 1);
    box-shadow: 3px 18px 44px rgba(176, 183, 195, 0.28);
    border-radius: 8px;
    border: 1px solid var(--light);
    z-index: 9;
  }
  .react-select__option {
    font-size: 12px;
    cursor: pointer;
    &:active {
      color: black;
      background: var(--primary);
    }
  }
  .react-select__single-value {
    color: var(--white);
  }
  .react-select__input-container {
    color: var(--white);
  }
  .react-select__option--is-focused {
    color: black;
    background: var(--primary);
  }
  .react-select__option--is-selected {
    color: black;
    background: var(--primary);
  }
  .react-select__indicator,
  .react-select__dropdown-indicator,
  .css-1xc3v61-indicatorContainer {
    color: var(--white) !important;

    svg {
      width: 16px;
    }
  }
  ${({ isMulti })=>isMulti && __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["css"]`
      .react-select__control {
        height: auto;
        min-height: 45px;
        font-size: 14px;
      }
      .react-select__option {
        position: relative;
        /* font-size: 14px; */
        padding-left: 42px;
        padding-top: 15px;
        padding-bottom: 15px;
        font-size: 14px;
        text-transform: uppercase;

        &:before,
        &:after {
          content: "";
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          border: 1px solid var(--primary);
          border-radius: 5px;
          width: 16px;
          height: 16px;
        }
        &:hover {
          &:before,
          &:after {
            border: 1px solid var(--white);
          }
        }
        &:after {
          content: "\\e876";
          font-family: "Material Icons Round";
          background: var(--primary);
          opacity: 0;
          visibility: hidden;
          transition: 0.3s linear;
          color: var(--white);
          /* font-size: 10px; */
          line-height: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        &.react-select__option--is-selected {
          background: none;
          color: #0f2546;
          &:after {
            opacity: 1;
            visibility: visible;
          }
          &.react-select__option--is-focused {
            background: var(--light-secondary);
          }
        }
      }
      .react-select__multi-value {
        background: rgba(53, 91, 133, 0.1);
        /* font-size: 12px; */
        line-height: 12px;
        border-radius: 60px;
        color: var(--primary);
      }
      .react-select__multi-value__label {
        color: var(--primary);
      }
    `}
`;
const StyledSelect = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__["default"])`
  ${Styles}
`;
const StyledSelectAsync = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select$2f$async__$5b$external$5d$__$28$react$2d$select$2f$async$2c$__esm_import$29$__["default"])`
  ${Styles}
`;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/components/molecules/Select/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
// eslint-disable-next-line no-unused-vars
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__ = __turbopack_import__("[externals]/react-select [external] (react-select, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$lodash$2f$debounce$2e$js__$5b$external$5d$__$28$lodash$2f$debounce$2e$js$2c$__cjs$29$__ = __turbopack_import__("[externals]/lodash/debounce.js [external] (lodash/debounce.js, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$helpers$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/styles/helpers.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$Select$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Select/Select.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/InputIcon/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Label$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Label/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$Field$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Field/Field.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/io/index.mjs [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$Select$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$Select$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
;
;
;
;
;
const DropdownIndicator = (props)=>__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__["components"].DropdownIndicator && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$select__$5b$external$5d$__$28$react$2d$select$2c$__esm_import$29$__["components"].DropdownIndicator, {
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
            $suffix: true,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["IoIosArrowDown"], {
                size: 20
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Select/index.jsx",
                lineNumber: 18,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/Select/index.jsx",
            lineNumber: 17,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/Select/index.jsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
function Select({ prefix, suffix, disabled, invalid, options, label, noMargin, error, rules, clear, async, labelIcon, width, placeholder, noPlaceholder, ...props }) {
    const debouncedRef = __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["default"].useRef(0);
    const loadOptions = async (__)=>{
        const _options = await new Promise((resolve)=>{
            (0, __TURBOPACK__imported__module__$5b$externals$5d2f$lodash$2f$debounce$2e$js__$5b$external$5d$__$28$lodash$2f$debounce$2e$js$2c$__cjs$29$__["default"])((value)=>{
                debouncedRef.current += 1;
                const LocalRef = debouncedRef.current;
                setTimeout(()=>{
                    if (LocalRef === debouncedRef.current) {
                        props.loadOptions(value).then((response)=>{
                            resolve(response);
                        });
                    }
                }, 300);
            }, 300)(__);
        });
        return _options;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$helpers$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledFormGroup"], {
        $width: width,
        $invalid: invalid || error,
        $noMargin: noMargin,
        dir: "ltr",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Label$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                labelIcon: labelIcon,
                onClear: ()=>{
                    props?.onChange?.({
                        target: {
                            value: options && options[0],
                            name: props.name ?? ""
                        }
                    });
                },
                required: rules?.filter(({ required })=>required).length,
                clear: clear,
                children: label
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Select/index.jsx",
                lineNumber: 65,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$Field$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["InputHolder"], {
                children: [
                    prefix && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        disabled: disabled,
                        prefix: prefix,
                        prefixFont: prefixFont,
                        invalid: invalid || error,
                        children: prefix
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/Select/index.jsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this),
                    async ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$Select$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledSelectAsync"], {
                        ...props,
                        $prefix: prefix,
                        $suffix: suffix,
                        options: options,
                        disabled: disabled,
                        classNamePrefix: "react-select",
                        loadOptions: loadOptions,
                        error: error,
                        components: {
                            DropdownIndicator,
                            IndicatorSeparator: ()=>null
                        },
                        onChange: (value)=>{
                            props?.onChange?.({
                                target: {
                                    value,
                                    name: props.name
                                }
                            });
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/Select/index.jsx",
                        lineNumber: 91,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$Select$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledSelect"], {
                        ...props,
                        $prefix: prefix,
                        $suffix: suffix,
                        options: options,
                        classNamePrefix: "react-select",
                        placeholder: noPlaceholder ? "" : placeholder ? placeholder : "Select...",
                        error: error,
                        components: {
                            DropdownIndicator,
                            IndicatorSeparator: ()=>null
                        },
                        onChange: (value)=>{
                            props?.onChange?.({
                                target: {
                                    value,
                                    name: props.name
                                }
                            });
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/Select/index.jsx",
                        lineNumber: 111,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/molecules/Select/index.jsx",
                lineNumber: 80,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$Field$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Error"], {
                id: `${props.name}Error`,
                role: "alert",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Select/index.jsx",
                lineNumber: 135,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/Select/index.jsx",
        lineNumber: 59,
        columnNumber: 5
    }, this);
}
const __TURBOPACK__default__export__ = Select;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[externals]/react-papaparse [external] (react-papaparse, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("react-papaparse", () => require("react-papaparse"));

module.exports = mod;
}}),
"[project]/src/components/molecules/UploadFile/UploadFile.styles.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "FileInfo": (()=>FileInfo),
    "FileName": (()=>FileName),
    "FileSize": (()=>FileSize),
    "FileUploadBox": (()=>FileUploadBox),
    "ProgressBarHolder": (()=>ProgressBarHolder),
    "RemoveBtn": (()=>RemoveBtn),
    "StyledBtn": (()=>StyledBtn),
    "StyledUploadFile": (()=>StyledUploadFile)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
;
const StyledUploadFile = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  width: 100%;

  .label-text {
    display: block;
    font-size: 20px;
    line-height: 24px;
    color: var(--matte-black);
    margin-bottom: ${({ $noLabelMargin })=>$noLabelMargin ? "0" : "8px"};
  }
  .labelButton {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 200px;
    overflow: hidden;
    cursor: pointer;
    padding: 5px;
    background: ${({ $bg })=>$bg ? "var(--white)" : "#2f2f2f"};
    border-radius: 16px;
    border: 1px dashed #666666;

    .upload-text {
      display: block;
      text-align: center;
      font-size: 12px;
      line-height: 16px;
      font-weight: 300;
      color: var(--matte-black);

      .icon-img {
        display: block;
        width: 50px;
        height: auto;
        margin: 0 auto 15px;
      }

      .text-lg {
        display: block;
        font-size: 16px;
        line-height: 20px;
        font-weight: 400;
        margin: 0 0 8px;
      }

      .text {
        display: block;
        max-width: 220px;
        margin: 0 auto;
      }
    }
  }

  input {
    display: none;
  }

  img {
    display: block;
    max-width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .uploaded-file-name {
    font-weight: 600;
  }
`;
const StyledBtn = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].label``;
const FileUploadBox = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  background: var(--bg-primary);
  border-radius: 20px;
  display: flex;
  position: relative;
  z-index: 10;
  height: 120px;
  width: 120px;
  flex-direction: column;
  justify-content: center;
`;
const FileInfo = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  align-items: center;
  display: flex;
  flex-direction: column;
  padding-left: 10px;
  padding-right: 10px;
`;
const FileSize = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  border-radius: 3px;
  margin-bottom: 0.5em;
  justify-content: center;
  display: flex;
`;
const FileName = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].span`
  border-radius: 3px;
  font-size: 12px;
  margin-bottom: 0.5em;
`;
const ProgressBarHolder = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  bottom: 14px;
  position: absolute;
  width: 100%;
  padding-left: 10px;
  padding-right: 10px;
`;
const RemoveBtn = __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__["default"].div`
  height: 23px;
  position: absolute;
  right: 6px;
  top: 6px;
  width: 23px;
  svg {
    fill: var(--danger);
  }
  &:hover {
    opacity: 0.8;
  }
`;
}}),
"[project]/src/assets/images/upload-img.svg [ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/upload-img.c1c1b2ec.svg");}}),
"[project]/src/assets/images/upload-img.svg.mjs { IMAGE => \"[project]/src/assets/images/upload-img.svg [ssr] (static)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg__$5b$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/upload-img.svg [ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg__$5b$ssr$5d$__$28$static$29$__["default"],
    width: 41,
    height: 40,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
}}),
"[project]/src/components/molecules/UploadFile/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$papaparse__$5b$external$5d$__$28$react$2d$papaparse$2c$__cjs$29$__ = __turbopack_import__("[externals]/react-papaparse [external] (react-papaparse, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/UploadFile/UploadFile.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/upload-img.svg.mjs { IMAGE => "[project]/src/assets/images/upload-img.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Toast/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
;
const UploadFile = ({ bgWhite, onChange, disc = "File size must be less than 5MB in PDF, JPG, or PNG format.", title, uploadTitle = "Upload Image", label = true, fileSize = 2, accept = "image/jpeg, image/jpg, image/png", type = "img", csv, icon, img = "", id = "upload", noLabelMargin, ...props })=>{
    const { CSVReader } = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$papaparse__$5b$external$5d$__$28$react$2d$papaparse$2c$__cjs$29$__["useCSVReader"])();
    const [uploaded, setUploaded] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])("");
    function handelChange(e) {
        const file = e.target.files[0];
        if (!file) return;
        const acceptableExtensions = accept.split(",").map((ext)=>ext.trim());
        if (!acceptableExtensions?.includes(file?.type)) {
            const extensions = acceptableExtensions.map((ext)=>ext.split("/")[1].toUpperCase()).join(", ").replace(/,(?=[^,]*$)/, " and");
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                type: "error",
                message: `File Must be in ${extensions} format!`
            });
            return;
        }
        if (file) {
            const fileLength = file.size / (1024 * 1024);
            if (fileLength <= fileSize) {
                setUploaded(e.target.files[0]);
                onChange(e.target.files[0]);
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                    type: "error",
                    message: "File Size Exceeded!"
                });
            }
        }
    }
    const getFileExtension = ()=>{
        if (uploaded) {
            const fileNameParts = uploaded.name.split(".");
            if (fileNameParts.length > 1) {
                return fileNameParts[fileNameParts.length - 1];
            }
        }
        return "";
    };
    const getFileName = ()=>{
        if (uploaded) {
            const fileNameParts = uploaded.name.split(".");
            let fileName = fileNameParts.length > 1 ? fileNameParts.slice(0, -1).join(".") : uploaded.name;
            // Truncate the file name if it's greater than 10 characters
            if (fileName.length > 20) {
                fileName = `${fileName.slice(0, 20)}...`;
            }
            return fileName;
        }
        return "";
    };
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        if (img) {
            setUploaded(img);
        } else {
            setUploaded("");
        }
    }, [
        img
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledUploadFile"], {
        $bg: bgWhite,
        $noLabelMargin: noLabelMargin,
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                className: "label-text",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                lineNumber: 102,
                columnNumber: 17
            }, this),
            type === "img" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("label", {
                htmlFor: id,
                className: "labelButton",
                children: [
                    !uploaded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                        className: "upload-text",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                className: "icon-img",
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                alt: "icon"
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                lineNumber: 107,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                className: "text-lg",
                                children: uploadTitle
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                lineNumber: 108,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                className: "text",
                                children: disc
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                lineNumber: 109,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                        lineNumber: 106,
                        columnNumber: 13
                    }, this),
                    uploaded && typeof uploaded === "string" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("img", {
                        src: uploaded,
                        alt: "img",
                        width: 250,
                        height: 300
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                        lineNumber: 113,
                        columnNumber: 13
                    }, this) : uploaded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("img", {
                        src: URL.createObjectURL(uploaded),
                        alt: "img",
                        width: 250,
                        height: 300
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                        lineNumber: 116,
                        columnNumber: 15
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                lineNumber: 104,
                columnNumber: 9
            }, this),
            type === "file" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("label", {
                htmlFor: id,
                className: "labelButton",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                    className: "upload-text",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            className: "icon-img",
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                            alt: "icon"
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                            lineNumber: 129,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                            className: "text-lg",
                            children: uploadTitle
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                            lineNumber: 130,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                            className: "text",
                            children: disc
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                            lineNumber: 131,
                            columnNumber: 13
                        }, this),
                        uploaded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                            className: "uploaded-file-name",
                            children: [
                                getFileName(),
                                ".",
                                getFileExtension()
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                            lineNumber: 133,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                    lineNumber: 128,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                lineNumber: 127,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                type: "file",
                id: id,
                accept: accept,
                onChange: (e)=>handelChange(e)
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                lineNumber: 140,
                columnNumber: 7
            }, this),
            type === "csv" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(CSVReader, {
                onDragOver: (event)=>{
                    event.preventDefault();
                },
                onDragLeave: (event)=>{
                    event.preventDefault();
                },
                ...props,
                children: ({ getRootProps, acceptedFile, ProgressBar, getRemoveFileProps, Remove })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledBtn"], {
                        as: "div",
                        ...getRootProps(),
                        css: `
                padding: 38px;
              `,
                        className: "labelButton",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            children: acceptedFile ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["FileUploadBox"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["FileInfo"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["FileSize"], {
                                                children: (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$papaparse__$5b$external$5d$__$28$react$2d$papaparse$2c$__cjs$29$__["formatFileSize"])(acceptedFile.size)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                                lineNumber: 173,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["FileName"], {
                                                children: acceptedFile.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                                lineNumber: 174,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                        lineNumber: 172,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["ProgressBarHolder"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(ProgressBar, {}, void 0, false, {
                                            fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                            lineNumber: 177,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                        lineNumber: 176,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$UploadFile$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["RemoveBtn"], {
                                        ...getRemoveFileProps(),
                                        onMouseOver: (event)=>{
                                            event.preventDefault();
                                        },
                                        onMouseOut: (event)=>{
                                            event.preventDefault();
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(Remove, {}, void 0, false, {
                                            fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                            lineNumber: 187,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                        lineNumber: 179,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                lineNumber: 171,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "upload-text",
                                children: [
                                    icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("img", {
                                        className: "icon-img",
                                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$upload$2d$img$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                        alt: "icon"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                        lineNumber: 193,
                                        columnNumber: 23
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "text-lg",
                                        children: uploadTitle
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                        lineNumber: 195,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: "text",
                                        children: disc
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                        lineNumber: 196,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                                lineNumber: 191,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                            lineNumber: 169,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                        lineNumber: 162,
                        columnNumber: 13
                    }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
                lineNumber: 147,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/UploadFile/index.jsx",
        lineNumber: 101,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = UploadFile;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/components/molecules/Field/index.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Label$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Label/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Input/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/InputIcon/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeLabel$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/FakeLabel/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeInput$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/FakeInput/index.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$helpers$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/styles/helpers.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$Field$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Field/Field.styles.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePicker$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/DatePicker/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PhoneNumberInput$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/PhoneNumberInput/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Select/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/UploadFile/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$tb$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/tb/index.mjs [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/fa/index.mjs [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PhoneNumberInput$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PhoneNumberInput$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const defaultProps = {
    type: "text"
};
const Field = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["forwardRef"])(({ rules, error, name, invalid, label, type, prefix, suffix, rounded, noMargin, margin, button, searchField, onlyRead, labelIcon, disabled, datePicker, clear, labelReverse, radioBorder, labelColor, onAutoPasscodeGenerate, country, ...props }, ref)=>{
    const [isRevealPwd, setIsRevealPwd] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const passcodeRef = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useRef"])(null);
    const inputProps = {
        id: props.id ?? name,
        name,
        type,
        invalid,
        "aria-describedby": `${name}Error`,
        ...props
    };
    const renderInputFirst = type === "checkbox" || type === "radio";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$helpers$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["StyledFormGroup"], {
        $invalid: invalid || error,
        $noMargin: noMargin,
        css: `
          margin-bottom: ${margin};
        `,
        children: [
            renderInputFirst && label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Label$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                htmlFor: inputProps.id,
                labelIcon: labelIcon,
                onlyRead: onlyRead,
                clear: clear,
                labelReverse: labelReverse,
                noLabelMargin: true,
                css: "display: flex !important; align-items:center; margin-bottom:0 !important;",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        ...inputProps,
                        ref: ref,
                        disabled: disabled,
                        $invalid: invalid || error,
                        checked: inputProps?.value,
                        // eslint-disable-next-line no-shadow
                        onChange: ({ target: { name, checked } })=>inputProps?.onChange?.({
                                target: {
                                    name,
                                    value: checked
                                }
                            })
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                        lineNumber: 78,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeInput$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        $radioBorder: radioBorder,
                        $labelReverse: labelReverse,
                        children: type === "checkbox" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$tb$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["TbCheck"], {
                            className: "icon"
                        }, void 0, false, {
                            fileName: "[project]/src/components/molecules/Field/index.jsx",
                            lineNumber: 90,
                            columnNumber: 39
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                        lineNumber: 89,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$FakeLabel$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        $labelColor: labelColor,
                        required: rules?.filter(({ required })=>required).length,
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                        lineNumber: 92,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/molecules/Field/index.jsx",
                lineNumber: 70,
                columnNumber: 11
            }, this),
            renderInputFirst || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                children: [
                    label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Label$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        onClear: ()=>inputProps?.onChange?.({
                                target: {
                                    name,
                                    value: type === "datepicker" ? [
                                        null,
                                        null
                                    ] : ""
                                }
                            }),
                        clear: clear,
                        labelIcon: labelIcon,
                        htmlFor: inputProps.id,
                        required: rules?.filter(({ required })=>required).length,
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                        lineNumber: 103,
                        columnNumber: 15
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$Field$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["InputHolder"], {
                        $searchField: searchField,
                        children: [
                            prefix && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                disabled: disabled,
                                // as={type === 'search' && 'button'}
                                // type={type === 'search' ? 'button' : undefined}
                                prefix: prefix,
                                invalid: invalid || error,
                                css: type === "search" && "color: var(--primary); font-size: 25px; left: 11px;",
                                children: prefix
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/Field/index.jsx",
                                lineNumber: 122,
                                columnNumber: 17
                            }, this),
                            suffix && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                suffix: suffix,
                                disabled: disabled,
                                invalid: invalid || error,
                                children: suffix
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/Field/index.jsx",
                                lineNumber: 136,
                                columnNumber: 17
                            }, this),
                            type === "password" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        ref: ref,
                                        ...inputProps,
                                        $prefix: prefix,
                                        $suffix: suffix,
                                        $invalid: invalid || error,
                                        type: isRevealPwd ? "text" : "password",
                                        $rounded: rounded,
                                        disabled: disabled,
                                        $button: button && true,
                                        // autoComplete="off"
                                        autoComplete: "new-password"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                                        lineNumber: 147,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        disabled: disabled,
                                        suffix: true,
                                        css: "cursor: pointer",
                                        onClick: ()=>setIsRevealPwd((prevState)=>!prevState),
                                        children: isRevealPwd ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["FaEye"], {}, void 0, false, {
                                            fileName: "[project]/src/components/molecules/Field/index.jsx",
                                            lineNumber: 165,
                                            columnNumber: 36
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["FaEyeSlash"], {}, void 0, false, {
                                            fileName: "[project]/src/components/molecules/Field/index.jsx",
                                            lineNumber: 165,
                                            columnNumber: 48
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                                        lineNumber: 160,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true) : type === "datepicker" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$DatePicker$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                ...inputProps,
                                prefix: prefix,
                                $invalid: invalid || error
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/Field/index.jsx",
                                lineNumber: 169,
                                columnNumber: 17
                            }, this) : type === "img" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$UploadFile$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                type: "img",
                                ...inputProps,
                                $invalid: invalid || error
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/Field/index.jsx",
                                lineNumber: 175,
                                columnNumber: 17
                            }, this) : type === "select" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Select$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                ...inputProps,
                                $invalid: invalid || error,
                                noMargin: true
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/Field/index.jsx",
                                lineNumber: 181,
                                columnNumber: 17
                            }, this) : type === "phone" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$PhoneNumberInput$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                ...inputProps,
                                defaultCountry: country,
                                prefix: prefix,
                                disabled: disabled,
                                $invalid: invalid || error,
                                noMargin: true,
                                rounded: rounded
                            }, void 0, false, {
                                fileName: "[project]/src/components/molecules/Field/index.jsx",
                                lineNumber: 183,
                                columnNumber: 17
                            }, this) : type === "passcode" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        ref: ref || passcodeRef,
                                        ...inputProps,
                                        $prefix: prefix,
                                        $suffix: suffix,
                                        $invalid: invalid || error,
                                        $rounded: rounded,
                                        disabled: disabled
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                                        lineNumber: 194,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        suffix: true,
                                        style: {
                                            cursor: "pointer"
                                        },
                                        onClick: onAutoPasscodeGenerate,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                            className: "material-icons-outlined",
                                            children: "sync"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/molecules/Field/index.jsx",
                                            lineNumber: 207,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                                        lineNumber: 203,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Input$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        ref: ref,
                                        ...inputProps,
                                        $prefix: prefix,
                                        disabled: disabled,
                                        $suffix: suffix,
                                        $invalid: invalid || error,
                                        $rounded: rounded,
                                        $button: button && true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                                        lineNumber: 213,
                                        columnNumber: 19
                                    }, this),
                                    suffix && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$InputIcon$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        suffix: suffix,
                                        disabled: disabled,
                                        invalid: invalid || error,
                                        children: suffix
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                                        lineNumber: 225,
                                        columnNumber: 21
                                    }, this),
                                    button && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                        css: `
                        position: absolute;
                        top: 50%;
                        transform: translateY(-50%);
                        right: 10px;
                      `,
                                        children: button
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                                        lineNumber: 233,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/molecules/Field/index.jsx",
                        lineNumber: 119,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true),
            invalid || error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$Field$2e$styles$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Error"], {
                id: `${name}Error`,
                role: "alert",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Field/index.jsx",
                lineNumber: 250,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/Field/index.jsx",
        lineNumber: 63,
        columnNumber: 7
    }, this);
});
Field.defaultProps = defaultProps;
const __TURBOPACK__default__export__ = Field;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[externals]/rc-util/lib/utils/get.js [external] (rc-util/lib/utils/get.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("rc-util/lib/utils/get.js", () => require("rc-util/lib/utils/get.js"));

module.exports = mod;
}}),
"[externals]/rc-util/lib/utils/set.js [external] (rc-util/lib/utils/set.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("rc-util/lib/utils/set.js", () => require("rc-util/lib/utils/set.js"));

module.exports = mod;
}}),
"[project]/src/components/molecules/Form/utils/typeUtil.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "toArray": (()=>toArray)
});
function toArray(value) {
    if (value === undefined || value === null) {
        return [];
    }
    return Array.isArray(value) ? value : [
        value
    ];
}
}}),
"[project]/src/components/molecules/Form/utils/valueUtil.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable no-use-before-define */ __turbopack_esm__({
    "cloneByNamePathList": (()=>cloneByNamePathList),
    "containsNamePath": (()=>containsNamePath),
    "defaultGetValueFromEvent": (()=>defaultGetValueFromEvent),
    "getNamePath": (()=>getNamePath),
    "getValue": (()=>getValue),
    "isSimilar": (()=>isSimilar),
    "matchNamePath": (()=>matchNamePath),
    "move": (()=>move),
    "setValue": (()=>setValue),
    "setValues": (()=>setValues)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$rc$2d$util$2f$lib$2f$utils$2f$get$2e$js__$5b$external$5d$__$28$rc$2d$util$2f$lib$2f$utils$2f$get$2e$js$2c$__cjs$29$__ = __turbopack_import__("[externals]/rc-util/lib/utils/get.js [external] (rc-util/lib/utils/get.js, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$rc$2d$util$2f$lib$2f$utils$2f$set$2e$js__$5b$external$5d$__$28$rc$2d$util$2f$lib$2f$utils$2f$set$2e$js$2c$__cjs$29$__ = __turbopack_import__("[externals]/rc-util/lib/utils/set.js [external] (rc-util/lib/utils/set.js, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$utils$2f$typeUtil$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/utils/typeUtil.js [ssr] (ecmascript)");
;
;
;
function getNamePath(path) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$utils$2f$typeUtil$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["toArray"])(path);
}
function getValue(store, namePath) {
    const value = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$rc$2d$util$2f$lib$2f$utils$2f$get$2e$js__$5b$external$5d$__$28$rc$2d$util$2f$lib$2f$utils$2f$get$2e$js$2c$__cjs$29$__["default"])(store, namePath);
    return value;
}
function setValue(store, namePath, value) {
    const newStore = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$rc$2d$util$2f$lib$2f$utils$2f$set$2e$js__$5b$external$5d$__$28$rc$2d$util$2f$lib$2f$utils$2f$set$2e$js$2c$__cjs$29$__["default"])(store, namePath, value);
    return newStore;
}
function cloneByNamePathList(store, namePathList) {
    let newStore = {};
    namePathList.forEach((namePath)=>{
        const value = getValue(store, namePath);
        newStore = setValue(newStore, namePath, value);
    });
    return newStore;
}
function containsNamePath(namePathList, namePath) {
    return namePathList && namePathList.some((path)=>matchNamePath(path, namePath));
}
function isObject(obj) {
    return typeof obj === 'object' && obj !== null && Object.getPrototypeOf(obj) === Object.prototype;
}
function internalSetValues(store, values) {
    const newStore = Array.isArray(store) ? [
        ...store
    ] : {
        ...store
    };
    if (!values) {
        return newStore;
    }
    Object.keys(values).forEach((key)=>{
        const prevValue = newStore[key];
        const value = values[key];
        const recursive = isObject(prevValue) && isObject(value);
        newStore[key] = recursive ? internalSetValues(prevValue, value || {}) : value;
    });
    return newStore;
}
function setValues(store, ...restValues) {
    return restValues?.reduce((current, newStore)=>internalSetValues(current, newStore), store);
}
function matchNamePath(namePath, changedNamePath) {
    if (!namePath || !changedNamePath || namePath.length !== changedNamePath.length) {
        return false;
    }
    return namePath.every((nameUnit, i)=>changedNamePath[i] === nameUnit);
}
function isSimilar(source, target) {
    if (source === target) {
        return true;
    }
    if (!source && target || source && !target) {
        return false;
    }
    if (!source || !target || typeof source !== 'object' || typeof target !== 'object') {
        return false;
    }
    const sourceKeys = Object.keys(source);
    const targetKeys = Object.keys(target);
    const keys = new Set([
        ...sourceKeys,
        ...targetKeys
    ]);
    return [
        ...keys
    ].every((key)=>{
        const sourceValue = source[key];
        const targetValue = target[key];
        if (typeof sourceValue === 'function' && typeof targetValue === 'function') {
            return true;
        }
        return sourceValue === targetValue;
    });
}
function defaultGetValueFromEvent(valuePropName, ...args) {
    const event = args[0];
    if (event && event.target && valuePropName in event.target) {
        return event.target[valuePropName];
    }
    return event;
}
function move(array, moveIndex, toIndex) {
    const { length } = array;
    if (moveIndex < 0 || moveIndex >= length || toIndex < 0 || toIndex >= length) {
        return array;
    }
    const item = array[moveIndex];
    const diff = moveIndex - toIndex;
    if (diff > 0) {
        // move left
        return [
            ...array.slice(0, toIndex),
            item,
            ...array.slice(toIndex, moveIndex),
            ...array.slice(moveIndex + 1, length)
        ];
    }
    if (diff < 0) {
        // move right
        return [
            ...array.slice(0, moveIndex),
            ...array.slice(moveIndex + 1, toIndex + 1),
            item,
            ...array.slice(toIndex + 1, length)
        ];
    }
    return array;
}
}}),
"[project]/src/components/molecules/Form/useForm.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable no-plusplus */ /* eslint-disable no-param-reassign */ __turbopack_esm__({
    "default": (()=>useForm)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
// eslint-disable-next-line no-unused-vars
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$utils$2f$valueUtil$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/utils/valueUtil.js [ssr] (ecmascript)");
;
;
;
class FormStore {
    store = {};
    errors = {};
    rules = {};
    fieldEntities = [];
    initialValues = {};
    callbacks = {};
    getFieldValue = (name)=>this.store[name];
    getFieldsValue = ()=>this.store;
    getFieldRules = (name)=>this.rules[name] ?? [];
    getFieldsErrors = ()=>this.errors;
    getFieldError = (name)=>this.errors?.[name]?.message || "";
    getFieldEntities = ()=>this.fieldEntities;
    validateFields = ()=>{
        if (this.store) {
            Object.entries(this.store).forEach(([key, value])=>{
                this.validateField(key, value);
            });
            this.store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$utils$2f$valueUtil$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["setValues"])(this.store, this.store);
        }
        this.notifyObservers(this.store);
        return this.errors;
    };
    validateField = (_, __)=>{
        const rules = this.getFieldRules(_);
        let value = __;
        const name = _;
        if (typeof value === "object") {
            if (!Object?.hasOwn(value, "place_id")) {
                value = value?.value ? value.value : value;
            }
        } else if (typeof value === "boolean") {
            value = value || false;
        } else value = typeof value === "string" ? String(value)?.trim() : value;
        let errors = [];
        rules.forEach((rule)=>{
            const error = {};
            switch(Object.keys(rule).filter((___)=>___ !== "message")[0]){
                case "required":
                    if (rule.required) {
                        error.hasError = !value;
                        // error.message = error.hasError ? rule.message ?? `${name} is required` : '';
                        error.message = error.hasError ? rule.message ?? rule.message ?? " " : "";
                    }
                    break;
                case "min":
                    if (!Number.isNaN(value)) error.hasError = value.length < rule.min;
                    else error.hasError = value < rule.min;
                    error.message = error.hasError ? rule.message ?? `value must be grater then ${rule.min}` : "";
                    break;
                case "max":
                    if (!Number.isNaN(value)) {
                        error.hasError = value.length > rule.max;
                    } else {
                        error.hasError = value > rule.max;
                    }
                    error.message = error.hasError ? rule.message ?? `value must be less then ${rule.max}` : "";
                    break;
                case "email":
                    if (rule.email) {
                        error.hasError = !/^[A-Z0-9_+.-]+@[A-Z0-9][A-Z0-9-]*\.[A-Z]{2,}$/i.test(value);
                        error.message = error.hasError ? rule.message ?? `Enter a valid email.` : "";
                    }
                    break;
                case "password":
                    if (rule.password) {
                        error.hasError = !(/(?=.*[a-z])/.test(value) && /(?=.*[A-Z])/.test(value) && value?.length >= 8 && /(?=.*\d)/.test(value));
                        error.message = error.hasError ? rule.message ?? `8-64 chars, include, uppercase, lowercase, number, & symbol.` : "";
                    }
                    break;
                case "pattern":
                    error.hasError = !rule.pattern.test(value);
                    error.message = error.hasError ? rule.message ?? `Enter a valid email` : "";
                    break;
                case "transform":
                    error.hasError = rule.transform(value);
                    error.message = error.hasError ? rule.message ?? `this value does not satisfy the transform condition` : "";
                    break;
                default:
                    break;
            }
            errors.push(error);
        });
        [errors] = errors.filter(({ hasError })=>hasError);
        if (value === "" || value === null || value === undefined) {
            const [isRequired] = rules.filter((r)=>r?.required);
            if (!isRequired) {
                errors = undefined;
            }
        }
        this.setFieldsError({
            [name]: errors
        });
        return errors;
    };
    transformField = (_, __)=>{
        const rules = this.getFieldRules(_);
        const value = __;
        const [regex] = rules.filter((r)=>r?.changeRegex);
        if (typeof value !== "string" && typeof value !== "number" || !regex) {
            return value;
        }
        const formatedVaue = (___, type)=>{
            if (type === "phone_number") {
                const cleanNum = ___.toString().replace(/\D/g, "");
                const match = cleanNum?.substr(0, 10)?.match(/^(\d{3})(\d{0,3})(\d{0,4})$/);
                if (match) {
                    return `${match[1].trim().length === 3 && match[2].trim() ? `(${match[1].trim()}) ` : `${match[1].trim()}`}${match[2].trim() && match[3].trim() ? `${match[2].trim()}-` : match[2].trim()}${match[3].trim()}`;
                }
                return cleanNum;
            }
            if (type === "sin") {
                const cleanNum = ___.toString().replace(/\D/g, "");
                const match = cleanNum?.substr(0, 9)?.match(/^(\d{3})(\d{0,3})(\d{0,3})$/);
                if (match) {
                    return `${match[1].trim() && match[2].trim() ? `${match[1].trim()}-` : `${match[1].trim()}`}${match[2].trim() && match[3].trim() ? `${match[2].trim()}-` : `${match[2].trim()}`}${match[3].trim()}`;
                }
                return cleanNum;
            }
            return ___;
        };
        return formatedVaue(value, regex.changeRegex);
    };
    notifyObservers = (prevStore)=>{
        this.getFieldEntities().forEach((entity)=>{
            const { onStoreChange } = entity;
            onStoreChange(prevStore, this.getFieldsValue());
        });
    };
    setFieldsError = (curErrors)=>{
        if (curErrors) {
            this.errors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$utils$2f$valueUtil$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["setValues"])(this.errors, curErrors);
            this.notifyObservers(this.store);
        }
    };
    setFieldsValue = (curStore)=>{
        // eslint-disable-next-line no-undef
        const { onTouched = ()=>{} } = this.callbacks;
        const prevStore = this.store;
        if (curStore) {
            Object.entries(curStore).forEach(([key, value])=>{
                curStore[key] = this.transformField(key, value);
                this.validateField(key, curStore[key]);
            });
            this.store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$utils$2f$valueUtil$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["setValues"])(this.store, curStore);
        }
        onTouched(curStore);
        this.notifyObservers(prevStore);
    };
    registerField = (entity)=>{
        this.fieldEntities.push(entity);
        this.rules[entity.props.name] = entity.props.rules;
        return ()=>{
            this.fieldEntities = this.fieldEntities.filter((item)=>item !== entity);
            delete this.store[entity.props.name];
            delete this.rules[entity.props.name];
        };
    };
    submit = ()=>{
        const { onSubmit = ()=>{}, onError = ()=>{} } = this.callbacks;
        const values = {};
        Object.keys(this.rules ?? {}).forEach((_)=>{
            values[_] = this.transformField(_, this.getFieldValue(_)) ?? "";
        });
        const errors = Object.entries(values).map((_)=>this.validateField(_[0], _[1])).filter((_)=>_);
        if (!errors.length) {
            onSubmit(this.getFieldsValue());
        } else {
            onError(this.getFieldsErrors());
            this.notifyObservers(this.getFieldsValue());
        }
    };
    getInitialValue = (namePath)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$utils$2f$valueUtil$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getValue"])(this.initialValues, namePath);
    setInitialValues = (initialValues, init)=>{
        this.initialValues = initialValues;
        if (init) {
            Object.entries(initialValues ?? {}).forEach(([key, value])=>{
                initialValues[key] = this.transformField(key, value);
                this.validateField(key, initialValues[key]);
            });
            this.initialValues = initialValues;
            this.store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$utils$2f$valueUtil$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["setValues"])(this.store, initialValues);
            this.notifyObservers(this.store);
        }
    };
    setFieldRules = (fieldName, rules)=>{
        this.rules[fieldName] = rules;
    };
    removeFieldError = (fieldName)=>{
        if (this.errors[fieldName]) {
            delete this.errors[fieldName];
            this.notifyObservers(this.store);
        }
    };
    hasFieldError = (name)=>{
        const error = this.getFieldError(name);
        return !!error;
    };
    setCallbacks = (callbacks)=>{
        this.callbacks = callbacks;
    };
    resetForm = ()=>{
        const initialValues = this.getFieldsValue();
        if (initialValues) {
            const resetValues = {};
            Object.keys(initialValues).forEach((key)=>{
                resetValues[key] = this.transformField(key, this.getInitialValue(key));
            });
            this.setFieldsValue(resetValues);
        }
        Object.keys(this.errors).forEach((key)=>{
            this.removeFieldError(key);
        });
    };
    getForm = ()=>({
            validateFields: this.validateFields,
            getFieldsErrors: this.getFieldsErrors,
            setFieldsError: this.setFieldsError,
            getFieldError: this.getFieldError,
            getFieldValue: this.getFieldValue,
            getFieldsValue: this.getFieldsValue,
            setFieldsValue: this.setFieldsValue,
            registerField: this.registerField,
            setFieldRules: this.setFieldRules,
            hasFieldError: this.hasFieldError,
            removeFieldError: this.removeFieldError,
            resetForm: this.resetForm,
            submit: this.submit,
            getInternalHooks: ()=>({
                    setInitialValues: this.setInitialValues,
                    setCallbacks: this.setCallbacks
                })
        });
}
function useForm(form) {
    const formRef = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useRef"])();
    if (!formRef.current) {
        if (form) {
            formRef.current = form;
        } else {
            const formStore = new FormStore();
            formRef.current = formStore.getForm();
        }
    }
    return [
        formRef.current
    ];
}
}}),
"[project]/src/components/molecules/Form/FieldContext.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
;
const fun = ()=>{};
const Context = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__.createContext({
    getFieldValue: fun,
    getFieldError: fun,
    getFieldsValue: fun,
    setFieldsValue: fun,
    registerField: fun,
    submit: fun
});
const __TURBOPACK__default__export__ = Context;
}}),
"[project]/src/components/molecules/Form/Form.jsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable react/display-name */ /* eslint-disable react/prop-types */ __turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
// eslint-disable-next-line no-unused-vars
var __TURBOPACK__imported__module__$5b$externals$5d2f$styled$2d$components__$5b$external$5d$__$28$styled$2d$components$2c$__cjs$29$__ = __turbopack_import__("[externals]/styled-components [external] (styled-components, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/useForm.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$FieldContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/FieldContext.js [ssr] (ecmascript)");
;
;
;
;
;
const __TURBOPACK__default__export__ = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["default"].forwardRef((props, ref)=>{
    const { form, children, initialValues, onSubmit, onError, onTouched, ...restProps } = props;
    const [formInstance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"])(form);
    const { setInitialValues, setCallbacks } = formInstance.getInternalHooks();
    __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["default"].useImperativeHandle(ref, ()=>formInstance);
    const mountRef = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useRef"])(null);
    setInitialValues(initialValues, !mountRef.current);
    if (!mountRef.current) {
        mountRef.current = true;
    }
    setCallbacks({
        onSubmit,
        onError,
        onTouched
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("form", {
        ...restProps,
        onSubmit: (event)=>{
            event.preventDefault();
            event.stopPropagation();
            formInstance.submit();
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$FieldContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].Provider, {
            value: formInstance,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/Form/Form.jsx",
            lineNumber: 46,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/Form/Form.jsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
});
}}),
"[project]/src/components/molecules/Form/Field.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Field)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
// eslint-disable-next-line no-unused-vars
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$FieldContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/FieldContext.js [ssr] (ecmascript)");
;
;
class Field extends __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["Component"] {
    // eslint-disable-next-line react/static-property-placement
    static contextType = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$FieldContext$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"];
    cancelRegisterFunc;
    componentDidMount() {
        const { registerField } = this.context;
        this.cancelRegisterFunc = registerField(this);
    }
    componentWillUnmount() {
        if (this.cancelRegisterFunc) {
            this.cancelRegisterFunc();
        }
    }
    onStoreChange = (prevStore, curStore)=>{
        const { shouldUpdate } = this.props;
        if (typeof shouldUpdate === 'function') {
            if (shouldUpdate(prevStore, curStore)) {
                this.forceUpdate();
            }
        } else {
            this.forceUpdate();
        }
    };
    getControlled = ()=>{
        const { name, children, ...rest } = this.props;
        const { getFieldValue, setFieldsValue, getFieldError } = this.context;
        return {
            error: getFieldError(name) ?? '',
            ...rest,
            value: getFieldValue(name) ?? '',
            onChange: (event)=>{
                let newValue;
                if (event instanceof File) {
                    newValue = event;
                } else {
                    newValue = event.target.value ?? '';
                }
                setFieldsValue({
                    [name]: newValue
                });
            }
        };
    };
    render() {
        const { children, ...rest } = this.props;
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["default"].cloneElement(children, {
            ...this.getControlled(),
            ...rest
        });
    }
}
}}),
"[project]/src/components/molecules/Form/index.js [ssr] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/Form.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Field$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/Field.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/useForm.js [ssr] (ecmascript)");
;
;
;
const Form = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"];
Form.Item = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Field$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"];
Form.useForm = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"];
;
const __TURBOPACK__default__export__ = Form;
}}),
"[project]/src/components/molecules/Form/index.js [ssr] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/Form.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Field$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/Field.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/useForm.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/src/components/molecules/Form/index.js [ssr] (ecmascript) <locals>");
}}),
"[project]/src/components/molecules/Form/useForm.js [ssr] (ecmascript) <export default as useForm>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_esm__({
    "useForm": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/useForm.js [ssr] (ecmascript)");
}}),
"[project]/src/pages/sign-up.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_import__("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_import__("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$email$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$email$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/email-icon.svg.mjs { IMAGE => "[project]/src/assets/images/email-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$password$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$password$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/password-icon.svg.mjs { IMAGE => "[project]/src/assets/images/password-icon.svg [ssr] (static)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginTemplate$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/LoginTemplate/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Field/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Form/Form.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/src/components/molecules/Form/index.js [ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Button/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/authService.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Toast/index.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/router.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__useForm$3e$__ = __turbopack_import__("[project]/src/components/molecules/Form/useForm.js [ssr] (ecmascript) <export default as useForm>");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const signUp = ()=>{
    const [form] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$useForm$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__useForm$3e$__["useForm"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    async function handleSubmit(e) {
        const payload = {
            first_name: e.first_name,
            last_name: e.last_name,
            email: e.email,
            password: e.confirm_password
        };
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].signUp(payload);
            sessionStorage.setItem("userEmail", e.email);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                type: "success",
                message: res.message
            });
            router.push("/verify-email");
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"])({
                type: "error",
                message: error.message
            });
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginTemplate$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
            form: form,
            onSubmit: handleSubmit,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                    className: "heading",
                    children: "Create Account!"
                }, void 0, false, {
                    fileName: "[project]/src/pages/sign-up.js",
                    lineNumber: 42,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                    children: "Kindly provide the following details to proceed with your account creation request."
                }, void 0, false, {
                    fileName: "[project]/src/pages/sign-up.js",
                    lineNumber: 43,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "sign-up-head",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"].Item, {
                            label: "First Name",
                            type: "text",
                            name: "first_name",
                            placeholder: "Enter first name",
                            rules: [
                                {
                                    required: true,
                                    message: "Please enter first name"
                                }
                            ],
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/pages/sign-up.js",
                                lineNumber: 56,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/pages/sign-up.js",
                            lineNumber: 45,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"].Item, {
                            label: "Last Name",
                            type: "text",
                            name: "last_name",
                            placeholder: "Enter last name",
                            rules: [
                                {
                                    required: true,
                                    message: "Please enter last name "
                                }
                            ],
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/src/pages/sign-up.js",
                                lineNumber: 69,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/pages/sign-up.js",
                            lineNumber: 58,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/sign-up.js",
                    lineNumber: 44,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"].Item, {
                    label: "Email Address",
                    type: "email",
                    name: "email",
                    placeholder: "Enter email address",
                    prefix: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$email$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$email$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "emailIcon"
                    }, void 0, false, {
                        fileName: "[project]/src/pages/sign-up.js",
                        lineNumber: 77,
                        columnNumber: 29
                    }, void 0),
                    rules: [
                        {
                            required: true,
                            message: "Please enter your email address "
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/pages/sign-up.js",
                        lineNumber: 84,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/pages/sign-up.js",
                    lineNumber: 72,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"].Item, {
                    label: "New Password",
                    type: "password",
                    name: "new_password",
                    placeholder: "Enter new password",
                    prefix: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$password$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$password$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "passwordIcon"
                    }, void 0, false, {
                        fileName: "[project]/src/pages/sign-up.js",
                        lineNumber: 91,
                        columnNumber: 29
                    }, void 0),
                    rules: [
                        {
                            required: true
                        },
                        {
                            password: true
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/pages/sign-up.js",
                        lineNumber: 98,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/pages/sign-up.js",
                    lineNumber: 86,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Form$2f$Form$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"].Item, {
                    label: "Confirm Password",
                    type: "password",
                    name: "confirm_password",
                    placeholder: "confirm new password",
                    prefix: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$password$2d$icon$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$password$2d$icon$2e$svg__$5b$ssr$5d$__$28$static$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                        alt: "passwordIcon"
                    }, void 0, false, {
                        fileName: "[project]/src/pages/sign-up.js",
                        lineNumber: 105,
                        columnNumber: 29
                    }, void 0),
                    rules: [
                        {
                            required: true
                        },
                        {
                            transform: (value)=>value !== form.getFieldValue("new_password")
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Field$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/pages/sign-up.js",
                        lineNumber: 114,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/pages/sign-up.js",
                    lineNumber: 100,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$index$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    width: "100%",
                    className: "btn",
                    children: "Create my Account"
                }, void 0, false, {
                    fileName: "[project]/src/pages/sign-up.js",
                    lineNumber: 116,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                    className: "create-account",
                    children: [
                        "Already have an account? ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: "/login",
                            children: "Sign In"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/sign-up.js",
                            lineNumber: 121,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/sign-up.js",
                    lineNumber: 119,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/pages/sign-up.js",
            lineNumber: 41,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/pages/sign-up.js",
        lineNumber: 40,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = signUp;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__75207d._.js.map