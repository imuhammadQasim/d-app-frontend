"use strict";exports.id=510,exports.ids=[510],exports.modules={9969:(e,t,i)=>{i.d(t,{A:()=>r});let r={src:"/_next/static/media/upload-img.1bde27d1.svg",height:40,width:41,blurWidth:0,blurHeight:0}},9465:(e,t,i)=>{i.d(t,{A:()=>j});var r=i(8732);i(2015);var n=i(2770),a=i.n(n),o=i(1550),s=i(6102),l=i(8509),d=i(8395),c=i.n(d);let p=a().div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10px 15px;
`,x=a().button`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  line-height: 1;
  width: 25px;
  height: 25px;
`,h=a().select`
  border: none;
  background: none;
  outline: none;
  font-weight: 400;
  font-size: 16px;
  line-height: 1;
  text-align: center;
  font-family: var(--base-font-sans-serif);
  option {
    font-size: 12px;
  }
`,g=a().div`
  display: flex;
  align-items: center;
  select {
    margin: 0 10px;
  }
`;var m=i(8978);let f=function({date:e,changeYear:t,changeMonth:i,decreaseMonth:n,increaseMonth:a,prevMonthButtonDisabled:d,nextMonthButtonDisabled:f}){let u=c()(1920,(0,s.C)((0,o.wR)(new Date))+9,1),b=["January","February","March","April","May","June","July","August","September","October","November","December"];return(0,r.jsxs)(p,{children:[(0,r.jsx)(x,{type:"button",onClick:n,disabled:d,children:(0,r.jsx)(m.l7J,{})}),(0,r.jsxs)(g,{children:[(0,r.jsx)(h,{value:b[(0,l.t)(e)],onChange:({target:{value:e}})=>i(b.indexOf(e)),children:b.map(e=>(0,r.jsx)("option",{value:e,children:e},e))}),(0,r.jsx)(h,{value:(0,s.C)(e),onChange:({target:{value:e}})=>t(e),children:u.map(e=>(0,r.jsx)("option",{value:e,children:e},e))})]}),(0,r.jsx)(x,{type:"button",onClick:a,disabled:f,children:(0,r.jsx)(m.mf,{})})]})};var u=i(9780),b=i.n(u);i(3048);var v=i(8391);let y=a()(b())`
  ${v.R7}
  padding-left: ${({prefix:e})=>e&&"2.5rem"};
  padding-right: ${({$suffix:e})=>e?"2.5rem":"2rem"};
`;a().div`
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 12px;
`;let j=function({prefix:e,suffix:t,disabled:i,excludeDateIntervals:n,invalid:a,error:o,onChange:s,timeOnly:l,excludeTimes:d,startTime:c,endTime:p,...x}){let h=new Date;return(0,r.jsx)(r.Fragment,{children:l?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(y,{disabled:i,prefix:e,suffix:t,invalid:a||o,showTimeSelectOnly:!0,showTimeSelect:!0,selected:c,startDate:c,onChange:e=>{s({target:{value:e,name:"startTime"}})},timeIntervals:30,timeCaption:"Time",dateFormat:"HH:mm",placeholderText:"Select Start Time",...x}),(0,r.jsx)(y,{disabled:i,prefix:e,suffix:t,invalid:a||o,showTimeSelectOnly:!0,showTimeSelect:!0,selected:p,endDate:p,onChange:e=>{s({target:{value:e,name:"endTime"}})},timeIntervals:30,timeCaption:"Time",dateFormat:"HH:mm",placeholderText:"Select End Time",...x})]}):(0,r.jsx)(y,{disabled:i,excludeDateIntervals:n,prefix:e,suffix:t,invalid:a||o,renderCustomHeader:({date:e,changeYear:t,changeMonth:i,decreaseMonth:n,increaseMonth:a,prevMonthButtonDisabled:o,nextMonthButtonDisabled:s})=>(0,r.jsx)(f,{date:e,changeYear:t,changeMonth:i,decreaseMonth:n,increaseMonth:a,prevMonthButtonDisabled:o,nextMonthButtonDisabled:s}),minDate:h,...x,onChange:e=>{s({target:{value:e,name:x.name}})}})})}},9676:(e,t,i)=>{i.d(t,{A:()=>a});var r=i(2770),n=i.n(r);let a=n().span`
  display: block;
  position: relative;
  width: 18px;
  height: 18px;
  border: 1px solid ${({$radioBorder:e})=>e??"var(--white)"};
  margin-right: 8px;
  border-radius: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  line-height: 1px;

  ${({$labelReverse:e})=>e&&(0,r.css)`
      position: absolute;
      right: 0;
      margin: 0 0 0 10px;
    `}

  .icon {
    color: transparent;
  }
`},5444:(e,t,i)=>{i.d(t,{A:()=>l});var r=i(8732);i(2015);var n=i(2770),a=i.n(n);let o=a().span`
  display: block;
  font-size: 16px;
  line-height: 20px;
  font-weight: 400;
  line-height: 1;
  color: ${({$labelColor:e})=>e||"var(--white)"};
  /* color: var(--black); */
`,s=a().span`
  color: var(--danger);
  margin-left: 3px;
`,l=function({children:e,required:t,labelIcon:i,...n}){return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)(o,{...n,children:[t?(0,r.jsx)(s,{}):"",e,i??null]})})}},3179:(e,t,i)=>{i.d(t,{$:()=>a,B:()=>o});var r=i(2770),n=i.n(r);let a=n().span`
  text-align: left;
  display: block;
  color: var(--danger);
  min-height: 26px;
  height: auto;
  opacity: 1;
  font-size: 12px;
  line-height: 16px;
  padding-top: 3px;
  /* margin-bottom: 10px; */
  &:first-letter {
    text-transform: uppercase;
  }
`,o=n().div`
  @media (min-width: 576px) {
    position: relative;
  }
  @media (max-width: 575px) {
    position: ${({$searchField:e})=>!e&&"relative"};
  }
`},2701:(e,t,i)=>{i.a(e,async(e,r)=>{try{i.d(t,{A:()=>j});var n=i(8732),a=i(2015),o=i(555),s=i(1601),l=i(6977),d=i(5444),c=i(9676),p=i(9153),x=i(3179),h=i(9465),g=i(4062),m=i(7099),f=i(2758),u=i(7923),b=i(3582),v=e([f,u,b]);[f,u,b]=v.then?(await v)():v;let y=(0,a.forwardRef)(({rules:e,error:t,name:i,invalid:r,label:v,type:y,prefix:j,suffix:w,rounded:$,noMargin:k,margin:_,button:z,searchField:A,onlyRead:C,labelIcon:S,disabled:I,datePicker:F,clear:N,labelReverse:P,radioBorder:D,labelColor:M,onAutoPasscodeGenerate:R,country:T,...B},O)=>{let[E,L]=(0,a.useState)(!1),U=(0,a.useRef)(null),H={id:B.id??i,name:i,type:y,invalid:r,"aria-describedby":`${i}Error`,...B},Z="checkbox"===y||"radio"===y;return(0,n.jsxs)(p.hZ,{$invalid:r||t,$noMargin:k,css:`
          margin-bottom: ${_};
        `,children:[Z&&v&&(0,n.jsxs)(o.A,{htmlFor:H.id,labelIcon:S,onlyRead:C,clear:N,labelReverse:P,noLabelMargin:!0,css:"display: flex !important; align-items:center; margin-bottom:0 !important;",children:[(0,n.jsx)(s.A,{...H,ref:O,disabled:I,$invalid:r||t,checked:H?.value,onChange:({target:{name:e,checked:t}})=>H?.onChange?.({target:{name:e,value:t}})}),(0,n.jsx)(c.A,{$radioBorder:D,$labelReverse:P,children:"checkbox"===y&&(0,n.jsx)(m.RUR,{className:"icon"})}),(0,n.jsx)(d.A,{$labelColor:M,required:e?.filter(({required:e})=>e).length,children:v})]}),Z||(0,n.jsxs)(n.Fragment,{children:[v&&(0,n.jsx)(o.A,{onClear:()=>H?.onChange?.({target:{name:i,value:"datepicker"===y?[null,null]:""}}),clear:N,labelIcon:S,htmlFor:H.id,required:e?.filter(({required:e})=>e).length,children:v}),(0,n.jsxs)(x.B,{$searchField:A,children:[j&&(0,n.jsx)(l.A,{disabled:I,prefix:j,invalid:r||t,css:"search"===y&&"color: var(--primary); font-size: 25px; left: 11px;",children:j}),w&&(0,n.jsx)(l.A,{suffix:w,disabled:I,invalid:r||t,children:w}),"password"===y?(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.A,{ref:O,...H,$prefix:j,$suffix:w,$invalid:r||t,type:E?"text":"password",$rounded:$,disabled:I,$button:z&&!0,autoComplete:"new-password"}),(0,n.jsx)(l.A,{disabled:I,suffix:!0,css:"cursor: pointer",onClick:()=>L(e=>!e),children:E?(0,n.jsx)(g.Ny1,{}):(0,n.jsx)(g.mx3,{})})]}):"datepicker"===y?(0,n.jsx)(h.A,{...H,prefix:j,$invalid:r||t}):"img"===y?(0,n.jsx)(b.A,{type:"img",...H,$invalid:r||t}):"select"===y?(0,n.jsx)(u.A,{...H,$invalid:r||t,noMargin:!0}):"phone"===y?(0,n.jsx)(f.A,{...H,defaultCountry:T,prefix:j,disabled:I,$invalid:r||t,noMargin:!0,rounded:$}):"passcode"===y?(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.A,{ref:O||U,...H,$prefix:j,$suffix:w,$invalid:r||t,$rounded:$,disabled:I}),(0,n.jsx)(l.A,{suffix:!0,style:{cursor:"pointer"},onClick:R,children:(0,n.jsx)("span",{className:"material-icons-outlined",children:"sync"})})]}):(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.A,{ref:O,...H,$prefix:j,disabled:I,$suffix:w,$invalid:r||t,$rounded:$,$button:z&&!0}),w&&(0,n.jsx)(l.A,{suffix:w,disabled:I,invalid:r||t,children:w}),z&&(0,n.jsx)("div",{css:`
                        position: absolute;
                        top: 50%;
                        transform: translateY(-50%);
                        right: 10px;
                      `,children:z})]})]})]}),r||t&&(0,n.jsx)(x.$,{id:`${i}Error`,role:"alert",children:t})]})});y.defaultProps={type:"text"};let j=y;r()}catch(e){r(e)}})},6977:(e,t,i)=>{i.d(t,{A:()=>s});var r=i(8732);i(2015);var n=i(2770),a=i.n(n);let o=a().span`
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  left: ${({$prefix:e})=>e&&"10px"};
  right: ${({$suffix:e})=>e&&"10px"};
  color: ${({$invalid:e})=>e?"var(--danger)":"var(--white)"};
  font-size: 16px;
  line-height: 1px;
  background: none;
  border: none;
  padding: 0;
  z-index: 1;
  ${({disabled:e})=>e&&"opacity: 0.5"};
  i {
    display: block;
  }
`,s=function({prefix:e,invalid:t,suffix:i,children:n,disabled:a,...s}){return(0,r.jsx)(r.Fragment,{children:(0,r.jsx)(o,{$prefix:e,$invalid:t,$suffix:i,disabled:a,...s,children:(0,r.jsx)("span",{className:"pref-suf",children:n})})})}},8391:(e,t,i)=>{i.d(t,{R7:()=>o,_S:()=>s,sQ:()=>l});var r=i(2770),n=i.n(r),a=i(9676);let o=(0,r.css)`
  border: 1px solid
    ${({$invalid:e})=>e?"var(--danger)":"transparent"};
  outline: none;
  height: ${({lg:e})=>e?"56px":"45px"};
  padding: ${({lg:e})=>e?"19px 30px":"13px 15px"};
  width: 100%;
  transition: border var(--animation-speed) ease-in-out;
  font-family: inherit;
  color: var(--white);
  background: rgba(255, 255, 255, 0.16);
  font-size: 14px;
  line-height: 18px;
  font-weight: 400;
  border-radius: ${({$rounded:e})=>e?"60px":"10px"};
  padding-left: ${({$prefix:e})=>e&&"2.5rem"};
  padding-right: ${({$suffix:e,$button:t})=>e?"2.5rem":t?"3.6rem":""};

  ${({type:e})=>"search"===e&&(0,r.css)`
      transition: all var(--animation-speed) ease-in-out;

      ${({responsive:e})=>e&&(0,r.css)`
          @media (max-width: 767px) {
            position: absolute;
            top: -22px;
            right: 7px;
            z-index: 9;
            box-shadow: 0px 23px 44px rgba(176, 183, 195, 0.3);
            background: var(--white);
            border: 1px solid var(--light);
            opacity: 0;
            visibility: hidden;
            transform: translateX(10px);
            width: 0;
          }
          @media (max-width: 575px) {
            top: 100%;
            left: 0;
            right: 0;
            width: 100%;
          }
        `}

      ${({openSearch:e})=>e&&(0,r.css)`
          @media (max-width: 767px) {
            opacity: 1;
            visibility: visible;
            transform: translateX(0);
            width: 350px;
          }
          @media (max-width: 575px) {
            transform: translateY(0);
            width: 100%;
          }
        `}
    `}

  ${({disabled:e})=>e&&(0,r.css)`
      background: var(--light);
      cursor: not-allowed;
      color: var(--light-gray);
    `}


  ::-webkit-input-placeholder {
    /* Chrome/Opera/Safari */
    color: var(--white);
    opacity: 0.6;
  }
  &::placeholder {
    color: var(--white);
  }
  ::-moz-placeholder {
    /* Firefox 19+ */
    color: var(--white);
    opacity: 0.6;
  }
  :-ms-input-placeholder {
    /* IE 10+ */
    color: var(--white);
    opacity: 0.6;
  }
  :-moz-placeholder {
    /* Firefox 18- */
    color: var(--white);
    opacity: 0.6;
  }

  &[type="radio"] {
    + ${a.A} {
      border-radius: 100%;
      &:before {
        content: "";
        background: linear-gradient(116.03deg, #355b85 5.04%, #1b2e44 86.56%);
        border: 2px solid white;
        border-radius: 100%;
        width: 15px;
        height: 15px;
      }
    }
  }

  + ${a.A} {
    transition: background var(--animation-speed) ease-in-out;
    &:before,
    .icon-check {
      position: absolute;
      top: 50%;
      left: 50%;
      opacity: 0;
      transform: translate(-50%, -50%);
      transition: opacity var(--animation-speed) ease-in-out;
    }
  }

  &[type="checkbox"] {
    + ${a.A} {
      .icon-check {
        color: var(--white);
        font-size: var(--font-size-xs);
      }
    }
  }

  &[type="checkbox"],
  &[type="radio"] {
    display: none;
    &:checked {
      + ${a.A} {
        background: var(--primary);
        border: 1px solid var(--secondary);

        .icon {
          color: var(--secondary);
        }

        .icon-check,
        &:before {
          opacity: 1;
        }
      }
    }
    &:disabled {
      ${a.A} {
        opacity: 0.5;
      }
    }
  }
  &:disabled {
    opacity: 0.5;
  }
  &:-webkit-autofill {
    -webkit-text-fill-color: var(--white);
  }
`,s=n().textarea`
  ${o}
  resize: vertical;
  min-height: 9.375rem;
  border-radius: 12px;
`,l=n().input`
  ${o}
`},1601:(e,t,i)=>{i.d(t,{A:()=>o});var r=i(8732),n=i(2015),a=i(8391);let o=(0,n.forwardRef)(({...e},t)=>{let{type:i}=e;return"textarea"===i?(0,r.jsx)(a._S,{...e,ref:t}):(0,r.jsx)(a.sQ,{...e,ref:t})})},555:(e,t,i)=>{i.d(t,{A:()=>l});var r=i(8732);i(2015);var n=i(2770),a=i.n(n);let o=a().label`
  font-size: 15px;
  line-height: 20px;
  color: var(--white);
  font-weight: 400;
  margin-bottom: ${({$noLabelMargin:e})=>e?"0":" 0.625rem"};
  display: block;
  pointer-events: ${({$onlyRead:e})=>e&&"none"};
  ${({labelIcon:e})=>e&&(0,n.css)`
      display: flex;
      align-items: center;
    `}
  ${({$labelReverse:e})=>e&&(0,n.css)`
      position: relative;
      .label {
        flex-direction: row-reverse;
      }
    `};
  .label {
    display: flex;
    align-items: center;
  }
`,s=a().span`
  color: var(--danger);
  font-size: 14px;
`,l=function({children:e,onlyRead:t,required:i,labelIcon:n,clear:a,labelReverse:l,noLabelMargin:d,onClear:c=()=>{},...p}){return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)(o,{$onlyRead:t,labelIcon:n,$labelReverse:l,$noLabelMargin:d,...p,children:[(0,r.jsxs)("div",{css:"display: flex; justify-content: space-between;",children:[(0,r.jsxs)("div",{css:"display: flex; align-items: center;",className:"label",children:[e,i?(0,r.jsx)(s,{children:"*"}):""]}),a&&(0,r.jsx)("span",{css:"color: var(--danger); cursor: pointer;",onClick:c,children:"Clear"})]}),n&&(0,r.jsx)("span",{css:"margin-left: 5px;",children:n})]})})}},7435:(e,t,i)=>{i.d(t,{_:()=>n});var r=i(2770);let n=r.styled.div`
  position: relative;
  font-size: 18px;
  line-height: 22px;
  font-weight: 400;
  font-family: var(--base-font-sans-serif);
  color: var(--white);
  label {
    display: block;
    margin-bottom: 10px;
  }
  .PhoneInput {
    /* background: #f1f1f1; */
    border: ${({$invalid:e})=>e?"1px solid var(--danger)":"1px solid transparent"};
    border-radius: 8px;
    /* background: rgba(255, 255, 255, 0.1); */
    color: var(--white);
  }
  .PhoneInput--focus {
    box-shadow: none;
  }
  .PhoneInputCountrySelect:focus + .PhoneInputCountryIcon--border {
    box-shadow: none;
  }
  .PhoneInputCountry {
    border-radius: 10px;
    width: 55px;
    display: flex;
    justify-content: flex-end;
    background: rgba(255, 255, 255, 0.2);
    margin-right: 10px;
    flex-shrink: 0;

    .PhoneInputCountryIcon {
      box-shadow: none;
      overflow: hidden;
      width: 22px;
      height: 22px;
      border-radius: 100px;
      &:focus {
        box-shadow: none;
      }
      img {
        width: 100%;
        object-fit: cover;
      }
    }
  }
  .PhoneInputCountrySelect {
    font-family: inherit;
    background: rgba(255, 255, 255, 0.1);
    font-size: 14px;
    line-height: 18px;
  }
  .PhoneInputCountrySelect > option:hover {
    background: rgba(255, 255, 255, 0.1);
    font-size: 14px;
    line-height: 18px;
  }
  .PhoneInputCountrySelectArrow {
    width: 0;
    height: 0;
    border-radius: 2px;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 5px solid #313131;
    border-bottom: none;
    opacity: 1;
    transform: none;
    visibility: hidden;
  }
  input {
    height: 45px;
    border-radius: 10px;
    border: none;
    padding: 0 0 0 10px;
    font-size: 14px;
    line-height: 18px;
    outline: none;
    margin: 0 !important;
    background: rgba(255, 255, 255, 0.2);
    font-weight: 400;
    color: var(--white);
    font-family: inherit;
    &::placeholder {
      color: var(--white);
    }
  }
  .error {
    font-size: 12px;
    line-height: 14px;
    font-weight: 400;
    position: absolute;
    left: 5px;
    bottom: -15px;
    color: var(--danger);
    p {
      margin: 0;
    }
  }
`},2758:(e,t,i)=>{i.a(e,async(e,r)=>{try{i.d(t,{A:()=>d});var n=i(8732);i(2015);var a=i(3127);i(3855);var o=i(7435),s=i(9153),l=e([a]);a=(l.then?(await l)():l)[0];let d=({onChange:e,value:t,placeholder:i,country:r,defaultCountry:l="US",bgWhite:d,noFlagWidth:c,error:p,invalid:x,prefix:h,suffix:g,noMargin:m,rounded:f,...u})=>(0,n.jsx)(s.hZ,{$noMargin:m,$rounded:f,children:(0,n.jsx)(o._,{...u,$bgWhite:d,$noFlagWidth:c,children:(0,n.jsx)(a.default,{placeholder:i,value:t,onChange:e,country:r,defaultCountry:l,maxLength:16,international:!0,invalid:x||p,...u})})});r()}catch(e){r(e)}})},6321:(e,t,i)=>{i.a(e,async(e,r)=>{try{i.d(t,{I:()=>p,q:()=>x});var n=i(9800),a=i(9355),o=i(2770),s=i.n(o),l=i(8391),d=e([n,a]);[n,a]=d.then?(await d)():d;let c=(0,o.css)`
  .react-select__control {
    ${l.R7}
    color: var(--white);
    min-height: inherit;
    padding-top: 0;
    padding-bottom: 0;
    padding-left: 20px;
    padding-right: 20px;
    font-size: 14px;
    border-color: ${({error:e})=>e&&"var(--danger) !important"};
    box-shadow: none;
    ${({$gray:e})=>e&&(0,o.css)`
        background: var(--gray-4);
        /* border-color: var(--light-secondary); */
      `}
    &:hover {
      border-color: transparent;
    }
    &.react-select__control--is-focused,
    &.react-select__control--menu-is-open {
      /* border-color: var(--primary); */
      font-size: 14px;
    }
  }
  .react-select__placeholder {
    color: var(--light-gray);
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    max-width: calc(100% - 8px);
    /* font-size: 12px; */
  }
  .react-select__value-container {
    padding-left: 0;
    padding-right: 0;
  }
  .react-select__menu {
    background: rgba(0, 0, 0, 1);
    box-shadow: 3px 18px 44px rgba(176, 183, 195, 0.28);
    border-radius: 8px;
    border: 1px solid var(--light);
    z-index: 9;
  }
  .react-select__option {
    font-size: 12px;
    cursor: pointer;
    &:active {
      color: black;
      background: var(--primary);
    }
  }
  .react-select__single-value {
    color: var(--white);
  }
  .react-select__input-container {
    color: var(--white);
  }
  .react-select__option--is-focused {
    color: black;
    background: var(--primary);
  }
  .react-select__option--is-selected {
    color: black;
    background: var(--primary);
  }
  .react-select__indicator,
  .react-select__dropdown-indicator,
  .css-1xc3v61-indicatorContainer {
    color: var(--white) !important;

    svg {
      width: 16px;
    }
  }
  ${({isMulti:e})=>e&&(0,o.css)`
      .react-select__control {
        height: auto;
        min-height: 45px;
        font-size: 14px;
      }
      .react-select__option {
        position: relative;
        /* font-size: 14px; */
        padding-left: 42px;
        padding-top: 15px;
        padding-bottom: 15px;
        font-size: 14px;
        text-transform: uppercase;

        &:before,
        &:after {
          content: "";
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          border: 1px solid var(--primary);
          border-radius: 5px;
          width: 16px;
          height: 16px;
        }
        &:hover {
          &:before,
          &:after {
            border: 1px solid var(--white);
          }
        }
        &:after {
          content: "\\e876";
          font-family: "Material Icons Round";
          background: var(--primary);
          opacity: 0;
          visibility: hidden;
          transition: 0.3s linear;
          color: var(--white);
          /* font-size: 10px; */
          line-height: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        &.react-select__option--is-selected {
          background: none;
          color: #0f2546;
          &:after {
            opacity: 1;
            visibility: visible;
          }
          &.react-select__option--is-focused {
            background: var(--light-secondary);
          }
        }
      }
      .react-select__multi-value {
        background: rgba(53, 91, 133, 0.1);
        /* font-size: 12px; */
        line-height: 12px;
        border-radius: 60px;
        color: var(--primary);
      }
      .react-select__multi-value__label {
        color: var(--primary);
      }
    `}
`,p=s()(n.default)`
  ${c}
`,x=s()(a.default)`
  ${c}
`;r()}catch(e){r(e)}})},7923:(e,t,i)=>{i.a(e,async(e,r)=>{try{i.d(t,{A:()=>b});var n=i(8732);i(2770);var a=i(2015),o=i.n(a),s=i(9800),l=i(1429),d=i.n(l),c=i(9153),p=i(6321),x=i(6977),h=i(555),g=i(2965),m=i(3179),f=e([s,p]);[s,p]=f.then?(await f)():f;let u=e=>s.components.DropdownIndicator&&(0,n.jsx)(s.components.DropdownIndicator,{...e,children:(0,n.jsx)(x.A,{$suffix:!0,children:(0,n.jsx)(g.pte,{size:20})})}),b=function({prefix:e,suffix:t,disabled:i,invalid:r,options:a,label:s,noMargin:l,error:g,rules:f,clear:b,async:v,labelIcon:y,width:j,placeholder:w,noPlaceholder:$,...k}){let _=o().useRef(0),z=async e=>await new Promise(t=>{d()(e=>{_.current+=1;let i=_.current;setTimeout(()=>{i===_.current&&k.loadOptions(e).then(e=>{t(e)})},300)},300)(e)});return(0,n.jsxs)(c.hZ,{$width:j,$invalid:r||g,$noMargin:l,dir:"ltr",children:[s&&(0,n.jsx)(h.A,{labelIcon:y,onClear:()=>{k?.onChange?.({target:{value:a&&a[0],name:k.name??""}})},required:f?.filter(({required:e})=>e).length,clear:b,children:s}),(0,n.jsxs)(m.B,{children:[e&&(0,n.jsx)(x.A,{disabled:i,prefix:e,prefixFont:prefixFont,invalid:r||g,children:e}),v?(0,n.jsx)(p.q,{...k,$prefix:e,$suffix:t,options:a,disabled:i,classNamePrefix:"react-select",loadOptions:z,error:g,components:{DropdownIndicator:u,IndicatorSeparator:()=>null},onChange:e=>{k?.onChange?.({target:{value:e,name:k.name}})}}):(0,n.jsx)(p.I,{...k,$prefix:e,$suffix:t,options:a,classNamePrefix:"react-select",placeholder:$?"":w||"Select...",error:g,components:{DropdownIndicator:u,IndicatorSeparator:()=>null},onChange:e=>{k?.onChange?.({target:{value:e,name:k.name}})}})]}),g&&(0,n.jsx)(m.$,{id:`${k.name}Error`,role:"alert",children:g})]})};r()}catch(e){r(e)}})},1723:(e,t,i)=>{i.d(t,{Dy:()=>x,Lp:()=>a,P6:()=>l,Qs:()=>o,US:()=>d,ZG:()=>p,o3:()=>c,ph:()=>s});var r=i(2770),n=i.n(r);let a=n().div`
  width: 100%;

  .label-text {
    display: block;
    font-size: 20px;
    line-height: 24px;
    color: var(--matte-black);
    margin-bottom: ${({$noLabelMargin:e})=>e?"0":"8px"};
  }
  .labelButton {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 200px;
    overflow: hidden;
    cursor: pointer;
    padding: 5px;
    background: ${({$bg:e})=>e?"var(--white)":"#2f2f2f"};
    border-radius: 16px;
    border: 1px dashed #666666;

    .upload-text {
      display: block;
      text-align: center;
      font-size: 12px;
      line-height: 16px;
      font-weight: 300;
      color: var(--matte-black);

      .icon-img {
        display: block;
        width: 50px;
        height: auto;
        margin: 0 auto 15px;
      }

      .text-lg {
        display: block;
        font-size: 16px;
        line-height: 20px;
        font-weight: 400;
        margin: 0 0 8px;
      }

      .text {
        display: block;
        max-width: 220px;
        margin: 0 auto;
      }
    }
  }

  input {
    display: none;
  }

  img {
    display: block;
    max-width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .uploaded-file-name {
    font-weight: 600;
  }
`,o=n().label``,s=n().div`
  background: var(--bg-primary);
  border-radius: 20px;
  display: flex;
  position: relative;
  z-index: 10;
  height: 120px;
  width: 120px;
  flex-direction: column;
  justify-content: center;
`,l=n().div`
  align-items: center;
  display: flex;
  flex-direction: column;
  padding-left: 10px;
  padding-right: 10px;
`,d=n().span`
  border-radius: 3px;
  margin-bottom: 0.5em;
  justify-content: center;
  display: flex;
`,c=n().span`
  border-radius: 3px;
  font-size: 12px;
  margin-bottom: 0.5em;
`,p=n().div`
  bottom: 14px;
  position: absolute;
  width: 100%;
  padding-left: 10px;
  padding-right: 10px;
`,x=n().div`
  height: 23px;
  position: absolute;
  right: 6px;
  top: 6px;
  width: 23px;
  svg {
    fill: var(--danger);
  }
  &:hover {
    opacity: 0.8;
  }
`},3582:(e,t,i)=>{i.a(e,async(e,r)=>{try{i.d(t,{A:()=>h});var n=i(8732),a=i(2015),o=i(7605),s=i(1723),l=i(9969),d=i(1540),c=i(9965),p=i.n(c),x=e([d]);d=(x.then?(await x)():x)[0];let h=({bgWhite:e,onChange:t,disc:i="File size must be less than 5MB in PDF, JPG, or PNG format.",title:r,uploadTitle:c="Upload Image",label:x=!0,fileSize:h=2,accept:g="image/jpeg, image/jpg, image/png",type:m="img",csv:f,icon:u,img:b="",id:v="upload",noLabelMargin:y,...j})=>{let{CSVReader:w}=(0,o.useCSVReader)(),[$,k]=(0,a.useState)("");return(0,a.useEffect)(()=>{b?k(b):k("")},[b]),(0,n.jsxs)(s.Lp,{$bg:e,$noLabelMargin:y,children:[x&&(0,n.jsx)("span",{className:"label-text",children:r}),"img"===m&&(0,n.jsxs)("label",{htmlFor:v,className:"labelButton",children:[!$&&(0,n.jsxs)("span",{className:"upload-text",children:[(0,n.jsx)(p(),{className:"icon-img",src:l.A,alt:"icon"}),(0,n.jsx)("span",{className:"text-lg",children:c}),(0,n.jsx)("span",{className:"text",children:i})]}),$&&"string"==typeof $?(0,n.jsx)("img",{src:$,alt:"img",width:250,height:300}):$&&(0,n.jsx)("img",{src:URL.createObjectURL($),alt:"img",width:250,height:300})]}),"file"===m&&(0,n.jsx)("label",{htmlFor:v,className:"labelButton",children:(0,n.jsxs)("span",{className:"upload-text",children:[(0,n.jsx)(p(),{className:"icon-img",src:l.A,alt:"icon"}),(0,n.jsx)("span",{className:"text-lg",children:c}),(0,n.jsx)("span",{className:"text",children:i}),$&&(0,n.jsxs)("span",{className:"uploaded-file-name",children:[(()=>{if($){let e=$.name.split("."),t=e.length>1?e.slice(0,-1).join("."):$.name;return t.length>20&&(t=`${t.slice(0,20)}...`),t}return""})(),".",(()=>{if($){let e=$.name.split(".");if(e.length>1)return e[e.length-1]}return""})()]})]})}),(0,n.jsx)("input",{type:"file",id:v,accept:g,onChange:e=>(function(e){let i=e.target.files[0];if(!i)return;let r=g.split(",").map(e=>e.trim());if(!r?.includes(i?.type)){let e=r.map(e=>e.split("/")[1].toUpperCase()).join(", ").replace(/,(?=[^,]*$)/," and");(0,d.A)({type:"error",message:`File Must be in ${e} format!`});return}i&&(i.size/1048576<=h?(k(e.target.files[0]),t(e.target.files[0])):(0,d.A)({type:"error",message:"File Size Exceeded!"}))})(e)}),"csv"===m&&(0,n.jsx)(w,{onDragOver:e=>{e.preventDefault()},onDragLeave:e=>{e.preventDefault()},...j,children:({getRootProps:e,acceptedFile:t,ProgressBar:r,getRemoveFileProps:a,Remove:d})=>(0,n.jsx)(s.Qs,{as:"div",...e(),css:`
                padding: 38px;
              `,className:"labelButton",children:(0,n.jsx)("div",{children:t?(0,n.jsxs)(s.ph,{children:[(0,n.jsxs)(s.P6,{children:[(0,n.jsx)(s.US,{children:(0,o.formatFileSize)(t.size)}),(0,n.jsx)(s.o3,{children:t.name})]}),(0,n.jsx)(s.ZG,{children:(0,n.jsx)(r,{})}),(0,n.jsx)(s.Dy,{...a(),onMouseOver:e=>{e.preventDefault()},onMouseOut:e=>{e.preventDefault()},children:(0,n.jsx)(d,{})})]}):(0,n.jsxs)("div",{className:"upload-text",children:[u&&(0,n.jsx)("img",{className:"icon-img",src:l.A,alt:"icon"}),(0,n.jsx)("span",{className:"text-lg",children:c}),(0,n.jsx)("span",{className:"text",children:i})]})})})})]})};r()}catch(e){r(e)}})},6530:(e,t,i)=>{i.r(t),i.d(t,{default:()=>s});var r=i(8732),n=i(883),a=i.n(n),o=i(2770);class s extends a(){static async getInitialProps(e){let t=new o.ServerStyleSheet,i=e.renderPage;try{e.renderPage=()=>i({enhanceApp:e=>i=>t.collectStyles((0,r.jsx)(e,{...i}))});let n=await a().getInitialProps(e);return{...n,styles:(0,r.jsxs)(r.Fragment,{children:[n.styles,t.getStyleElement()]})}}finally{t.seal()}}render(){let{locale:e}=this.props.__NEXT_DATA__;return(0,r.jsxs)(n.Html,{lang:e,children:[(0,r.jsxs)(n.Head,{children:[(0,r.jsx)("link",{rel:"preconnect",href:"https://fonts.googleapis.com"}),(0,r.jsx)("link",{rel:"preconnect",href:"https://fonts.gstatic.com",crossorigin:!0}),(0,r.jsx)("link",{href:"https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap",rel:"stylesheet"}),(0,r.jsx)("link",{href:"https://fonts.googleapis.com/css2?family=Vina+Sans&display=swap",rel:"stylesheet"})]}),(0,r.jsxs)("body",{children:[(0,r.jsx)(n.Main,{}),(0,r.jsx)(n.NextScript,{}),(0,r.jsx)("div",{id:"modal-root"})]})]})}}},9153:(e,t,i)=>{i.d(t,{hZ:()=>a});var r=i(2770),n=i.n(r);n().div`
  display: flex;
  flex-wrap: ${e=>!e.nowrap&&"wrap"};

  ${e=>"column"===e.direction&&(0,r.css)`
      flex-direction: column;
    `}

  ${e=>"columnReverse"===e.direction&&(0,r.css)`
      flex-direction: column;
    `}

  ${e=>"center"===e.justify&&(0,r.css)`
      justify-content: center;
    `}

  ${e=>"space-between"===e.justify&&(0,r.css)`
      justify-content: space-between;
    `}

  ${e=>"end"===e.justify&&(0,r.css)`
      justify-content: flex-end;
    `}

  ${e=>"top"===e.align&&(0,r.css)`
      align-items: flex-start;
    `}

  ${e=>"middle"===e.align&&(0,r.css)`
      align-items: center;
    `}

    ${e=>"bottom"===e.align&&(0,r.css)`
      align-items: flex-end;
    `}
`,(0,r.css)`
  display: flex;
  align-items: center;
  justify-content: center;
`;let a=n().div`
  width: 100%;
  min-width: ${({$width:e})=>e||""};
  margin-bottom: ${({$invalid:e,$noMargin:t})=>e||t?"0px":"15px"};
  /* position: relative; */

  /* &:nth-last-child(1) {
    margin-bottom: 0;
  } */
  @media (min-width: 768px) {
    margin-bottom: ${({$invalid:e,$noMargin:t})=>e||t?"0px":"15px"};
  }
`;n().div`
  position: relative;
`,n().div`
  display: grid;
  grid-template-columns: repeat(
    ${({numOfBtns:e})=>4===e?4:3},
    minmax(20px, 20px)
  );
  align-items: center;
  justify-content: center;
  position: absolute;
  top: 5px;
  right: 17px;
  gap: 20px;
  margin: 0 auto;
  .tooltip-holder {
    display: flex;
    align-items: center;
    justify-content: center;

    &.red_dot {
      .detail-btn {
        position: relative;

        &:before {
          content: "";
          position: absolute;
          top: 0;
          right: 0;
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: var(--danger);
        }
      }
    }
  }
  .tooltip-holder:only-child {
    /* justify-content: flex-end;
    @media (min-width: 992px) {
      justify-content: center;
    } */
    @media (max-width: 992px) {
      grid-column: ${({numOfBtns:e})=>4===e?"span 4 / span 4":"span 3 / span 3"};
    }
  }
  @media (min-width: 992px) {
    position: static;
  }
  button {
    font-size: var(--font-size-xl);
    line-height: calc(var(--font-size-xl) + 0.3125rem);
    display: flex;
    align-items: center;
  }

  .delete-btn {
    color: var(--danger);
  }

  .detail-btn {
    color: var(--primary);
  }
`,n().div`
  padding: 0 15px;
  width: 100%;
  @media (min-width: 1500px) {
    padding: 0 50px;
  }
`,n().div`
  .actions {
    @media (max-width: 650px) {
      flex-direction: column;
      gap: 15px !important;
    }
    @media (max-width: 576px) {
      width: 100%;
    }
    button {
      padding: 13px 15px;
      max-width: 100%;
    }
    .Search {
      @media (max-width: 576px) {
        width: 100% !important;
      }
    }
  }
`}};