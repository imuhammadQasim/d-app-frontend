exports.id=13,exports.ids=[13],exports.modules={7063:(t,e,i)=>{"use strict";i.d(e,{A:()=>a});let a={src:"/_next/static/media/map-gif.296462af.gif",height:200,width:200,blurWidth:0,blurHeight:0}},4784:(t,e,i)=>{"use strict";i.d(e,{t:()=>r});var a=i(2770),o=i.n(a);let r=o().div`
  height: 350px;
  border: 1px solid var(--dark-100);
  border-radius: 16px;
  position: relative;
  overflow: hidden;
  @media (min-width: 768px) {
    height: 500px;
  }
  @media (min-width: 992px) {
    width: 50%;
    height: auto;
  }

  .head {
    position: absolute;
    top: 15px;
    left: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
    z-index: 2;
    
    @media (min-width: 576px) {
      top: 20px;
      left: 20px;
    }

    img {
      width: 30px;
      height: 30px;
    }

    .heading {
      display: block;
      font-size: 20px;
      line-height: 24px;
      font-weight: 600;
    }
  }

  .map-container {
    height: 100%;
    width: 100%;
    outline: none;
    border: none;
    z-index: 1;
  }

  .leaflet-bottom {
    display: none;
  }
  .leaflet-left .leaflet-control {
    margin: 0;
  }

  .leaflet-top,
  .leaflet-bottom {
    top: auto;
    right: 10px;
    bottom: 10px;
    left: auto;
  }

  .leaflet-marker-icon {
    width: 50px !important;
    height: 50px !important;
    border: 2px solid var(--white);
    border-radius: 50%;
  }

  .leaflet-touch .leaflet-bar a:first-child,
  .leaflet-touch .leaflet-bar a:last-child {
    background: var(--dark-100);
    color: var(--white);
    border-bottom: 0;
    border-radius: 6px;
    margin: 0 0 4px;

    &:hover {
      background: var(--dark-100);
    }
  }
`},2013:(t,e,i)=>{"use strict";i.a(t,async(t,a)=>{try{i.r(e),i.d(e,{default:()=>m});var o=i(8732),r=i(7173),l=i(5165),n=i.n(l);i(8534);var d=i(4784),s=i(7063),p=i(9965),h=i.n(p),c=t([r]);r=(c.then?(await c)():c)[0];let m=()=>{let t=t=>n().icon({iconUrl:t,iconSize:[30,30],iconAnchor:[15,30]});return(0,o.jsxs)(d.t,{children:[(0,o.jsxs)("div",{className:"head",children:[(0,o.jsx)(h(),{src:s.A,alt:"mapGif"}),(0,o.jsx)("span",{className:"heading",children:"Promotions Map"})]}),(0,o.jsxs)(r.MapContainer,{center:[31.5204,74.3587],zoom:16,scrollWheelZoom:!1,className:"map-container",children:[(0,o.jsx)(r.TileLayer,{url:"https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png",attribution:'\xa9 <a href="https://www.carto.com/">CartoDB</a>'}),[{position:[31.5204,74.3587],imageUrl:"https://res.cloudinary.com/dbamrlmjd/image/upload/v1737633743/binance-icon_yd2trw.svg"},{position:[31.5209,74.3599],imageUrl:"https://res.cloudinary.com/dbamrlmjd/image/upload/v1737634329/dollar-icon_qa1nrz.svg"}].map((e,i)=>(0,o.jsx)(r.Marker,{position:e.position,icon:t(e.imageUrl)},i))]})]})};a()}catch(t){a(t)}})},8534:()=>{}};