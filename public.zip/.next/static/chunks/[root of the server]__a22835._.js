(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/[root of the server]__a22835._.js", {

"[turbopack]/browser/dev/hmr-client/websocket.ts [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// Adapted from https://github.com/vercel/next.js/blob/canary/packages/next/src/client/dev/error-overlay/websocket.ts
__turbopack_esm__({
    "addMessageListener": (()=>addMessageListener),
    "connectHMR": (()=>connectHMR),
    "sendMessage": (()=>sendMessage)
});
let source;
const eventCallbacks = [];
// TODO: add timeout again
// let lastActivity = Date.now()
function getSocketProtocol(assetPrefix) {
    let protocol = location.protocol;
    try {
        // assetPrefix is a url
        protocol = new URL(assetPrefix).protocol;
    } catch (_) {}
    return protocol === "http:" ? "ws" : "wss";
}
function addMessageListener(cb) {
    eventCallbacks.push(cb);
}
function sendMessage(data) {
    if (!source || source.readyState !== source.OPEN) return;
    return source.send(data);
}
function connectHMR(options) {
    const { timeout = 5 * 1000 } = options;
    function init() {
        if (source) source.close();
        console.log("[HMR] connecting...");
        function handleOnline() {
            const connected = {
                type: "turbopack-connected"
            };
            eventCallbacks.forEach((cb)=>{
                cb(connected);
            });
            if (options.log) console.log("[HMR] connected");
        // lastActivity = Date.now()
        }
        function handleMessage(event) {
            // lastActivity = Date.now()
            const message = {
                type: "turbopack-message",
                data: JSON.parse(event.data)
            };
            eventCallbacks.forEach((cb)=>{
                cb(message);
            });
        }
        // let timer: NodeJS.Timeout
        function handleDisconnect() {
            source.close();
            setTimeout(init, timeout);
        }
        const { hostname, port } = location;
        const protocol = getSocketProtocol(options.assetPrefix || "");
        const assetPrefix = options.assetPrefix.replace(/^\/+/, "");
        let url = `${protocol}://${hostname}:${port}${assetPrefix ? `/${assetPrefix}` : ""}`;
        if (assetPrefix.startsWith("http")) {
            url = `${protocol}://${assetPrefix.split("://")[1]}`;
        }
        source = new window.WebSocket(`${url}${options.path}`);
        source.onopen = handleOnline;
        source.onerror = handleDisconnect;
        source.onmessage = handleMessage;
    }
    init();
}
}}),
"[turbopack]/browser/dev/hmr-client/hmr-client.ts [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/// <reference path="../../../shared/runtime-types.d.ts" />
/// <reference path="../../runtime/base/dev-globals.d.ts" />
/// <reference path="../../runtime/base/dev-protocol.d.ts" />
/// <reference path="../../runtime/base/dev-extensions.ts" />
__turbopack_esm__({
    "connect": (()=>connect),
    "setHooks": (()=>setHooks),
    "subscribeToUpdate": (()=>subscribeToUpdate)
});
var __TURBOPACK__imported__module__$5b$turbopack$5d2f$browser$2f$dev$2f$hmr$2d$client$2f$websocket$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[turbopack]/browser/dev/hmr-client/websocket.ts [client] (ecmascript)");
;
function connect({ // TODO(WEB-1465) Remove this backwards compat fallback once
// vercel/next.js#54586 is merged.
addMessageListener = __TURBOPACK__imported__module__$5b$turbopack$5d2f$browser$2f$dev$2f$hmr$2d$client$2f$websocket$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["addMessageListener"], // TODO(WEB-1465) Remove this backwards compat fallback once
// vercel/next.js#54586 is merged.
sendMessage = __TURBOPACK__imported__module__$5b$turbopack$5d2f$browser$2f$dev$2f$hmr$2d$client$2f$websocket$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["sendMessage"], onUpdateError = console.error }) {
    addMessageListener((msg)=>{
        switch(msg.type){
            case "turbopack-connected":
                handleSocketConnected(sendMessage);
                break;
            default:
                try {
                    if (Array.isArray(msg.data)) {
                        for(let i = 0; i < msg.data.length; i++){
                            handleSocketMessage(msg.data[i]);
                        }
                    } else {
                        handleSocketMessage(msg.data);
                    }
                    applyAggregatedUpdates();
                } catch (e) {
                    console.warn("[Fast Refresh] performing full reload\n\n" + "Fast Refresh will perform a full reload when you edit a file that's imported by modules outside of the React rendering tree.\n" + "You might have a file which exports a React component but also exports a value that is imported by a non-React component file.\n" + "Consider migrating the non-React component export to a separate file and importing it into both files.\n\n" + "It is also possible the parent component of the component you edited is a class component, which disables Fast Refresh.\n" + "Fast Refresh requires at least one parent function component in your React tree.");
                    onUpdateError(e);
                    location.reload();
                }
                break;
        }
    });
    const queued = globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS;
    if (queued != null && !Array.isArray(queued)) {
        throw new Error("A separate HMR handler was already registered");
    }
    globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS = {
        push: ([chunkPath, callback])=>{
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    };
    if (Array.isArray(queued)) {
        for (const [chunkPath, callback] of queued){
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    }
}
const updateCallbackSets = new Map();
function sendJSON(sendMessage, message) {
    sendMessage(JSON.stringify(message));
}
function resourceKey(resource) {
    return JSON.stringify({
        path: resource.path,
        headers: resource.headers || null
    });
}
function subscribeToUpdates(sendMessage, resource) {
    sendJSON(sendMessage, {
        type: "turbopack-subscribe",
        ...resource
    });
    return ()=>{
        sendJSON(sendMessage, {
            type: "turbopack-unsubscribe",
            ...resource
        });
    };
}
function handleSocketConnected(sendMessage) {
    for (const key of updateCallbackSets.keys()){
        subscribeToUpdates(sendMessage, JSON.parse(key));
    }
}
// we aggregate all pending updates until the issues are resolved
const chunkListsWithPendingUpdates = new Map();
function aggregateUpdates(msg) {
    const key = resourceKey(msg.resource);
    let aggregated = chunkListsWithPendingUpdates.get(key);
    if (aggregated) {
        aggregated.instruction = mergeChunkListUpdates(aggregated.instruction, msg.instruction);
    } else {
        chunkListsWithPendingUpdates.set(key, msg);
    }
}
function applyAggregatedUpdates() {
    if (chunkListsWithPendingUpdates.size === 0) return;
    hooks.beforeRefresh();
    for (const msg of chunkListsWithPendingUpdates.values()){
        triggerUpdate(msg);
    }
    chunkListsWithPendingUpdates.clear();
    finalizeUpdate();
}
function mergeChunkListUpdates(updateA, updateB) {
    let chunks;
    if (updateA.chunks != null) {
        if (updateB.chunks == null) {
            chunks = updateA.chunks;
        } else {
            chunks = mergeChunkListChunks(updateA.chunks, updateB.chunks);
        }
    } else if (updateB.chunks != null) {
        chunks = updateB.chunks;
    }
    let merged;
    if (updateA.merged != null) {
        if (updateB.merged == null) {
            merged = updateA.merged;
        } else {
            // Since `merged` is an array of updates, we need to merge them all into
            // one, consistent update.
            // Since there can only be `EcmascriptMergeUpdates` in the array, there is
            // no need to key on the `type` field.
            let update = updateA.merged[0];
            for(let i = 1; i < updateA.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateA.merged[i]);
            }
            for(let i = 0; i < updateB.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateB.merged[i]);
            }
            merged = [
                update
            ];
        }
    } else if (updateB.merged != null) {
        merged = updateB.merged;
    }
    return {
        type: "ChunkListUpdate",
        chunks,
        merged
    };
}
function mergeChunkListChunks(chunksA, chunksB) {
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    return chunks;
}
function mergeChunkUpdates(updateA, updateB) {
    if (updateA.type === "added" && updateB.type === "deleted" || updateA.type === "deleted" && updateB.type === "added") {
        return undefined;
    }
    if (updateA.type === "partial") {
        invariant(updateA.instruction, "Partial updates are unsupported");
    }
    if (updateB.type === "partial") {
        invariant(updateB.instruction, "Partial updates are unsupported");
    }
    return undefined;
}
function mergeChunkListEcmascriptMergedUpdates(mergedA, mergedB) {
    const entries = mergeEcmascriptChunkEntries(mergedA.entries, mergedB.entries);
    const chunks = mergeEcmascriptChunksUpdates(mergedA.chunks, mergedB.chunks);
    return {
        type: "EcmascriptMergedUpdate",
        entries,
        chunks
    };
}
function mergeEcmascriptChunkEntries(entriesA, entriesB) {
    return {
        ...entriesA,
        ...entriesB
    };
}
function mergeEcmascriptChunksUpdates(chunksA, chunksB) {
    if (chunksA == null) {
        return chunksB;
    }
    if (chunksB == null) {
        return chunksA;
    }
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeEcmascriptChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    if (Object.keys(chunks).length === 0) {
        return undefined;
    }
    return chunks;
}
function mergeEcmascriptChunkUpdates(updateA, updateB) {
    if (updateA.type === "added" && updateB.type === "deleted") {
        // These two completely cancel each other out.
        return undefined;
    }
    if (updateA.type === "deleted" && updateB.type === "added") {
        const added = [];
        const deleted = [];
        const deletedModules = new Set(updateA.modules ?? []);
        const addedModules = new Set(updateB.modules ?? []);
        for (const moduleId of addedModules){
            if (!deletedModules.has(moduleId)) {
                added.push(moduleId);
            }
        }
        for (const moduleId of deletedModules){
            if (!addedModules.has(moduleId)) {
                deleted.push(moduleId);
            }
        }
        if (added.length === 0 && deleted.length === 0) {
            return undefined;
        }
        return {
            type: "partial",
            added,
            deleted
        };
    }
    if (updateA.type === "partial" && updateB.type === "partial") {
        const added = new Set([
            ...updateA.added ?? [],
            ...updateB.added ?? []
        ]);
        const deleted = new Set([
            ...updateA.deleted ?? [],
            ...updateB.deleted ?? []
        ]);
        if (updateB.added != null) {
            for (const moduleId of updateB.added){
                deleted.delete(moduleId);
            }
        }
        if (updateB.deleted != null) {
            for (const moduleId of updateB.deleted){
                added.delete(moduleId);
            }
        }
        return {
            type: "partial",
            added: [
                ...added
            ],
            deleted: [
                ...deleted
            ]
        };
    }
    if (updateA.type === "added" && updateB.type === "partial") {
        const modules = new Set([
            ...updateA.modules ?? [],
            ...updateB.added ?? []
        ]);
        for (const moduleId of updateB.deleted ?? []){
            modules.delete(moduleId);
        }
        return {
            type: "added",
            modules: [
                ...modules
            ]
        };
    }
    if (updateA.type === "partial" && updateB.type === "deleted") {
        // We could eagerly return `updateB` here, but this would potentially be
        // incorrect if `updateA` has added modules.
        const modules = new Set(updateB.modules ?? []);
        if (updateA.added != null) {
            for (const moduleId of updateA.added){
                modules.delete(moduleId);
            }
        }
        return {
            type: "deleted",
            modules: [
                ...modules
            ]
        };
    }
    // Any other update combination is invalid.
    return undefined;
}
function invariant(_, message) {
    throw new Error(`Invariant: ${message}`);
}
const CRITICAL = [
    "bug",
    "error",
    "fatal"
];
function compareByList(list, a, b) {
    const aI = list.indexOf(a) + 1 || list.length;
    const bI = list.indexOf(b) + 1 || list.length;
    return aI - bI;
}
const chunksWithIssues = new Map();
function emitIssues() {
    const issues = [];
    const deduplicationSet = new Set();
    for (const [_, chunkIssues] of chunksWithIssues){
        for (const chunkIssue of chunkIssues){
            if (deduplicationSet.has(chunkIssue.formatted)) continue;
            issues.push(chunkIssue);
            deduplicationSet.add(chunkIssue.formatted);
        }
    }
    sortIssues(issues);
    hooks.issues(issues);
}
function handleIssues(msg) {
    const key = resourceKey(msg.resource);
    let hasCriticalIssues = false;
    for (const issue of msg.issues){
        if (CRITICAL.includes(issue.severity)) {
            hasCriticalIssues = true;
        }
    }
    if (msg.issues.length > 0) {
        chunksWithIssues.set(key, msg.issues);
    } else if (chunksWithIssues.has(key)) {
        chunksWithIssues.delete(key);
    }
    emitIssues();
    return hasCriticalIssues;
}
const SEVERITY_ORDER = [
    "bug",
    "fatal",
    "error",
    "warning",
    "info",
    "log"
];
const CATEGORY_ORDER = [
    "parse",
    "resolve",
    "code generation",
    "rendering",
    "typescript",
    "other"
];
function sortIssues(issues) {
    issues.sort((a, b)=>{
        const first = compareByList(SEVERITY_ORDER, a.severity, b.severity);
        if (first !== 0) return first;
        return compareByList(CATEGORY_ORDER, a.category, b.category);
    });
}
const hooks = {
    beforeRefresh: ()=>{},
    refresh: ()=>{},
    buildOk: ()=>{},
    issues: (_issues)=>{}
};
function setHooks(newHooks) {
    Object.assign(hooks, newHooks);
}
function handleSocketMessage(msg) {
    sortIssues(msg.issues);
    handleIssues(msg);
    switch(msg.type){
        case "issues":
            break;
        case "partial":
            // aggregate updates
            aggregateUpdates(msg);
            break;
        default:
            // run single update
            const runHooks = chunkListsWithPendingUpdates.size === 0;
            if (runHooks) hooks.beforeRefresh();
            triggerUpdate(msg);
            if (runHooks) finalizeUpdate();
            break;
    }
}
function finalizeUpdate() {
    hooks.refresh();
    hooks.buildOk();
    // This is used by the Next.js integration test suite to notify it when HMR
    // updates have been completed.
    // TODO: Only run this in test environments (gate by `process.env.__NEXT_TEST_MODE`)
    if (globalThis.__NEXT_HMR_CB) {
        globalThis.__NEXT_HMR_CB();
        globalThis.__NEXT_HMR_CB = null;
    }
}
function subscribeToChunkUpdate(chunkPath, sendMessage, callback) {
    return subscribeToUpdate({
        path: chunkPath
    }, sendMessage, callback);
}
function subscribeToUpdate(resource, sendMessage, callback) {
    // TODO(WEB-1465) Remove this backwards compat fallback once
    // vercel/next.js#54586 is merged.
    if (callback === undefined) {
        callback = sendMessage;
        sendMessage = __TURBOPACK__imported__module__$5b$turbopack$5d2f$browser$2f$dev$2f$hmr$2d$client$2f$websocket$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["sendMessage"];
    }
    const key = resourceKey(resource);
    let callbackSet;
    const existingCallbackSet = updateCallbackSets.get(key);
    if (!existingCallbackSet) {
        callbackSet = {
            callbacks: new Set([
                callback
            ]),
            unsubscribe: subscribeToUpdates(sendMessage, resource)
        };
        updateCallbackSets.set(key, callbackSet);
    } else {
        existingCallbackSet.callbacks.add(callback);
        callbackSet = existingCallbackSet;
    }
    return ()=>{
        callbackSet.callbacks.delete(callback);
        if (callbackSet.callbacks.size === 0) {
            callbackSet.unsubscribe();
            updateCallbackSets.delete(key);
        }
    };
}
function triggerUpdate(msg) {
    const key = resourceKey(msg.resource);
    const callbackSet = updateCallbackSets.get(key);
    if (!callbackSet) {
        return;
    }
    for (const callback of callbackSet.callbacks){
        callback(msg);
    }
    if (msg.type === "notFound") {
        // This indicates that the resource which we subscribed to either does not exist or
        // has been deleted. In either case, we should clear all update callbacks, so if a
        // new subscription is created for the same resource, it will send a new "subscribe"
        // message to the server.
        // No need to send an "unsubscribe" message to the server, it will have already
        // dropped the update stream before sending the "notFound" message.
        updateCallbackSets.delete(key);
    }
}
}}),
"[project]/src/components/LoginTemplate/LoginTemplate.styles.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledLoginTemplate": (()=>StyledLoginTemplate)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [client] (ecmascript)");
;
const StyledLoginTemplate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].div`
  display: flex;
  gap: 10px;
  padding: 15px;
  min-height: 100vh;

  .form-section {
    width: 100%;
    display: flex;
    align-items: center;
    @media (min-width: 992px) {
      width: 50%;
    }

    .form-holder {
      width: 100%;
      max-width: 400px;
      margin: 0 auto;

      .heading {
        display: block;
        font-size: 28px;
        line-height: 32px;
        font-weight: 700;
        text-align: center;
        margin: 0 0 16px;
      }

      .logo-holder {
        width: 100%;
        max-width: 260px;
        margin: 0 auto 16px;

        img {
          display: block;
          width: 100%;
          height: auto;
        }
      }

      p {
        text-align: center;
        margin: 0 0 25px;
      }
    }
  }

  .img-holder {
    width: 50%;
    border-radius: 30px;
    background: linear-gradient(to bottom, #2b4731 0%, #49724f 100%);
    position: relative;
    overflow: hidden;
    user-select: none;
    display: none;

    @media (min-width: 992px) {
      display: block;
    }

    img {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      display: block;
      max-width: 100%;
      height: auto;
    }
  }

  .login-form-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 0 0 25px;

    a {
      flex-shrink: 0;
      color: var(--golden);
    }
  }

  .btn {
    margin: 10px 0 20px;
  }

  .create-account {
    display: block;
    text-align: center;

    a {
      font-weight: 600;
      color: var(--primary);
      text-decoration: underline;
    }
  }

  .sign-up-head {
    display: flex;
    gap: 16px;
  }
`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/images/login-img.png [client] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/login-img.11fd156a.png");}}),
"[project]/src/assets/images/login-img.png.mjs { IMAGE => \"[project]/src/assets/images/login-img.png [client] (static)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png__$5b$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/login-img.png [client] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png__$5b$client$5d$__$28$static$29$__["default"],
    width: 1068,
    height: 1140,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAYAAAA1BOUGAAAA5klEQVR42iWOu4rCQBiFx4wmM242l8k9QXedyCa4ypqFBVltRcFLaWOholhYWYuNiLVvYG3nY2jpA/gs4ox+8Dcfh/8cABjCCyhi6V2z9HyKwT2AEKYN18yZvlXUXRK5n14JZZEMeAC9ISUjZXC5Xh53pu0TTcLRR1xIvirxDyh8h7VKLe4utpPr/ri+92etixGYCXsfADvvRC71qpPV4Lw7LO+9efOm2GqVOFoRiEhEqqkF9JfOG8P/M/0LN8yplq9HvDclYUnWbZIjnlHCStbBMpbZcvRczBOWZ/sKUYkAhTQ7yPUDF6keu86jYM0AAAAASUVORK5CYII=",
    blurWidth: 7,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/images/logo.svg [client] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/logo.29630a6b.svg");}}),
"[project]/src/assets/images/logo.svg.mjs { IMAGE => \"[project]/src/assets/images/logo.svg [client] (static)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/logo.svg [client] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$client$5d$__$28$static$29$__["default"],
    width: 232,
    height: 27,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/LoginTemplate/index.jsx [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginTemplate$2f$LoginTemplate$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/LoginTemplate/LoginTemplate.styles.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png__$5b$client$5d$__$28$static$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/login-img.png.mjs { IMAGE => "[project]/src/assets/images/login-img.png [client] (static)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$client$5d$__$28$static$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/logo.svg.mjs { IMAGE => "[project]/src/assets/images/logo.svg [client] (static)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [client] (ecmascript)");
;
;
;
;
;
;
const LoginTemplate = ({ children })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginTemplate$2f$LoginTemplate$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__["StyledLoginTemplate"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "form-section",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "form-holder",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("figure", {
                            className: "logo-holder",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$logo$2e$svg__$5b$client$5d$__$28$static$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                alt: "logo"
                            }, void 0, false, {
                                fileName: "[project]/src/components/LoginTemplate/index.jsx",
                                lineNumber: 13,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/LoginTemplate/index.jsx",
                            lineNumber: 12,
                            columnNumber: 11
                        }, this),
                        children
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/LoginTemplate/index.jsx",
                    lineNumber: 11,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/LoginTemplate/index.jsx",
                lineNumber: 10,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("figure", {
                className: "img-holder",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$login$2d$img$2e$png__$5b$client$5d$__$28$static$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                    alt: "loginImg"
                }, void 0, false, {
                    fileName: "[project]/src/components/LoginTemplate/index.jsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/LoginTemplate/index.jsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/LoginTemplate/index.jsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
};
_c = LoginTemplate;
const __TURBOPACK__default__export__ = LoginTemplate;
var _c;
__turbopack_refresh__.register(_c, "LoginTemplate");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/molecules/Toast/Toast.styles.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Message": (()=>Message),
    "StyledAlert": (()=>StyledAlert)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [client] (ecmascript)");
;
const StyledAlert = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].div`
    width: 100%;
    border-radius: 8px;
    padding: 1rem;
    display: flex;
    align-items: center;
    font-size: var(--font-size-sm);
    line-height: calc(var(--font-size-sm) + 0.3125rem);
    @media (min-width: 768px) {
        padding: 1rem 3.9375rem 1rem 1rem;
    }

    ${({ $type })=>$type === "success" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
            color: var(--secondary);
            background: #97fa93;
        `}

    ${({ $type })=>$type === "info" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
            color: var(--info-text);
            background: var(--info);
        `}

    ${({ $type })=>$type === "error" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
            color: var(--danger-100);
            background: #fef0f4;
        `}

    ${({ $type })=>$type === "warning" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
            color: var(--warning);
            background: #fffaf2;
        `}
`;
const Message = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].p`
    color: inherit;
    margin: 0;
`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/molecules/AlertIcon/AlertIcon.styles.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledIcon": (()=>StyledIcon)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [client] (ecmascript)");
;
const StyledIcon = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].span`
  font-size: 1.625rem;
  line-height: 1;
  margin-right: 1.125rem;
`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/molecules/AlertIcon/index.jsx [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$AlertIcon$2f$AlertIcon$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/AlertIcon/AlertIcon.styles.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$rx$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/rx/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/io/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/io5/index.mjs [client] (ecmascript)");
;
;
;
;
;
;
const AlertIcon = ({ $type })=>{
    const iconType = ()=>{
        switch($type){
            case "error":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$rx$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["RxCrossCircled"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 11,
                    columnNumber: 16
                }, this);
            case "info":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["IoMdInformationCircleOutline"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 13,
                    columnNumber: 16
                }, this);
            case "warning":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["IoWarningOutline"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 15,
                    columnNumber: 16
                }, this);
            case "success":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["IoCheckmarkSharp"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 17,
                    columnNumber: 16
                }, this);
            default:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["IoMdInformationCircleOutline"], {}, void 0, false, {
                    fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
                    lineNumber: 19,
                    columnNumber: 16
                }, this);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$AlertIcon$2f$AlertIcon$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__["StyledIcon"], {
        $type: $type,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "material-icons-outlined",
            children: iconType()
        }, void 0, false, {
            fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
            lineNumber: 24,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/molecules/AlertIcon/index.jsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
};
_c = AlertIcon;
const __TURBOPACK__default__export__ = AlertIcon;
var _c;
__turbopack_refresh__.register(_c, "AlertIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/molecules/Toast/index.jsx [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-toastify/dist/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$Toast$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Toast/Toast.styles.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$AlertIcon$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/AlertIcon/index.jsx [client] (ecmascript)");
;
;
;
;
;
function Toast({ type, message, ...props }) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["toast"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$Toast$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__["StyledAlert"], {
        $type: type,
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$AlertIcon$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                $type: type
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Toast/index.jsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$Toast$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Message"], {
                $type: type,
                children: message
            }, void 0, false, {
                fileName: "[project]/src/components/molecules/Toast/index.jsx",
                lineNumber: 10,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/molecules/Toast/index.jsx",
        lineNumber: 8,
        columnNumber: 5
    }, this), {
        hideProgressBar: true,
        autoClose: 2000,
        ...props
    });
}
_c = Toast;
const __TURBOPACK__default__export__ = Toast;
var _c;
__turbopack_refresh__.register(_c, "Toast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/helpers/common.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable react/jsx-filename-extension */ /* eslint-disable no-unused-vars */ /* eslint-disable react/react-in-jsx-scope */ /* eslint-disable no-plusplus */ __turbopack_esm__({
    "GeoCode": (()=>GeoCode),
    "bas64toFile": (()=>bas64toFile),
    "calculateTotalNights": (()=>calculateTotalNights),
    "capitalize": (()=>capitalize),
    "checkAge": (()=>checkAge),
    "checkInValidImage": (()=>checkInValidImage),
    "clearCookie": (()=>clearCookie),
    "convertDateToISO": (()=>convertDateToISO),
    "convertPdfBase64": (()=>convertPdfBase64),
    "convertReadable": (()=>convertReadable),
    "convertToBase64": (()=>convertToBase64),
    "convertToCurrencyFormat": (()=>convertToCurrencyFormat),
    "convertToFormData": (()=>convertToFormData),
    "daysLeft": (()=>daysLeft),
    "debounce": (()=>debounce),
    "formatDate": (()=>formatDate),
    "formatDateWithSuffix": (()=>formatDateWithSuffix),
    "formatNumber": (()=>formatNumber),
    "generatePsscode": (()=>generatePsscode),
    "getCookie": (()=>getCookie),
    "getDateObject": (()=>getDateObject),
    "getOfferDetailsAppView": (()=>getOfferDetailsAppView),
    "getStatusIconClass": (()=>getStatusIconClass),
    "getVisitNo": (()=>getVisitNo),
    "removeSpaces": (()=>removeSpaces),
    "setCookie": (()=>setCookie),
    "shortenString": (()=>shortenString)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/date-fns/format.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarDays$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/differenceInCalendarDays.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$setHours$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/setHours.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isBefore$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/isBefore.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInDays$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/date-fns/differenceInDays.js [client] (ecmascript)");
;
;
;
const setCookie = (name, value, days, domain)=>{
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        expires = `; expires=${date.toUTCString()}`;
    }
    const domainString = domain ? `; domain=${domain}` : "";
    document.cookie = `${name}=${value || ""}${expires}; path=/${domainString}`;
    return true;
};
const getCookie = (name)=>{
    const nameEQ = `${name}=`;
    const ca = typeof document !== "undefined" && document.cookie.split(";");
    for(let i = 0; i < ca.length; i++){
        let c = ca[i];
        while(c.charAt(0) === " ")c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
};
const clearCookie = (name)=>{
    if (typeof document !== "undefined") {
        document.cookie = `${name}=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;`;
    } else {
        console.warn("clearCookie function called in a non-browser environment");
    }
    return true;
};
const formatNumber = (number)=>{
    return new Intl.NumberFormat().format(number);
};
const convertPdfBase64 = (file)=>new Promise((resolve)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = ()=>{
            resolve(reader.result);
        };
    });
const capitalize = (str = "")=>{
    const arr = str.toLowerCase().split(" ");
    for(let i = 0; i < arr.length; i++){
        arr[i] = arr[i].charAt(0).toUpperCase() + arr[i].slice(1);
    }
    const str2 = arr.join(" ");
    return str2;
};
const getStatusIconClass = (status = "")=>{
    switch(status.trim().toLowerCase()){
        case "pending":
            return "icon-clock";
        case "processing":
            return "icon-clock";
        case "approved":
            return "icon-check-circle";
        case "rejected":
            return "icon-error-circle";
        case "cancelled":
            return "icon-times-circle";
        default:
            return "icon-warning";
    }
};
function changeTimezone(date, ianatz) {
    // suppose the date is 12:00 UTC
    const invdate = new Date(date.toLocaleString("en-US", {
        timeZone: ianatz
    }));
    // then invdate will be 07:00 in Toronto
    // and the diff is 5 hours
    const diff = date.getTime() - invdate.getTime();
    // so 12:00 in Toronto is 17:00 UTC
    return new Date(date.getTime() - diff); // needs to substract
}
const getDateObject = (e)=>changeTimezone(new Date(e), "Canada/Eastern");
const convertToCurrencyFormat = (amount = "0")=>`$${Number(amount).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
const shortenString = (str, len = 10)=>{
    if (!str) return null;
    if (str.length > len) {
        return `${str.substring(0, len)}...`;
    }
    return str;
};
const convertReadable = (amount = 0)=>`${Math.abs(amount) > 999 ? `${Math.sign(amount) * (Math.abs(amount) / 1000).toFixed(1)}K` : Math.sign(amount) * Math.abs(amount)}`;
const convertToBase64 = (file)=>new Promise((resolve)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = ()=>{
            resolve(reader.result);
        };
    });
const getVisitNo = (visit)=>{
    switch(visit){
        case 1:
            return `${String(visit)}st`;
        case 2:
            return `${String(visit)}nd`;
        case 3:
            return `${String(visit)}rd`;
        default:
            return `${String(visit)}th`;
    }
};
const generatePsscode = (length)=>{
    let zero = "";
    for(let index = 1; index < length; index++){
        zero += "0";
    }
    const firstVal = 1 + zero;
    const secondVal = 9 + zero;
    return Math.floor(Number(firstVal) + Math.random() * Number(secondVal));
};
const getOfferDetailsAppView = ({ offer_type, // eslint-disable-next-line no-unused-vars
offer_details: { minimum_amount, minimum_visit, maximum_amount, plastk_points_value, plastk_points, initial_offer, every_day_offer }, stores, duration: { startDate, endDate } })=>{
    if (!stores.length || !offer_type || !plastk_points_value || !startDate || !endDate) return "";
    try {
        switch(offer_type){
            case "dollarBased":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                "Spend at least ",
                                convertToCurrencyFormat(minimum_amount, 0),
                                " and receive",
                                " ",
                                plastk_points_value,
                                " plastk points. Offer valid between",
                                " ",
                                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(startDate).toString()), "MMM do yyyy hh:mm a")} To ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(endDate).toString()), "MMM do yyyy hh:mm a")}`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 190,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 198,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
            case "repeatVisit":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                "Visit ",
                                minimum_visit,
                                " times and receive ",
                                plastk_points_value,
                                " plastk points on the",
                                " ",
                                (()=>{
                                    switch(+String(minimum_visit).split("")[String(minimum_visit).split("").length - 1]){
                                        case 1:
                                            return `${String(minimum_visit)}st`;
                                        case 2:
                                            return `${String(minimum_visit)}nd`;
                                        case 3:
                                            return `${String(minimum_visit)}rd`;
                                        default:
                                            return `${String(minimum_visit)}th`;
                                    }
                                })(),
                                " ",
                                "visit. Offer valid between",
                                " ",
                                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(startDate).toString()), "MMM do yyyy hh:mm a")} to ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(endDate).toString()), "MMM do yyyy hh:mm a")}`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 205,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 225,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
            case "percentBased":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                "Spend $",
                                minimum_amount,
                                " or more and receive ",
                                plastk_points,
                                "% in plastk points, up to a maximum of",
                                " ",
                                plastk_points_value % 1 !== 0 ? convertToCurrencyFormat(plastk_points_value, 2, false) : convertToCurrencyFormat(plastk_points_value, 0, false),
                                "points. Offer valid between",
                                " ",
                                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(startDate).toString()), "MMM do yyyy hh:mm a")} to ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(endDate).toString()), "MMM do yyyy hh:mm a")}`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 232,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 244,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
            case "initialOffer":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                "Visit ",
                                minimum_visit,
                                " times and receive ",
                                plastk_points_value,
                                " plastk points on the  ",
                                (()=>{
                                    switch(+String(minimum_visit).split("")[String(minimum_visit).split("").length - 1]){
                                        case 1:
                                            return `${String(minimum_visit)}st`;
                                        case 2:
                                            return `${String(minimum_visit)}nd`;
                                        case 3:
                                            return `${String(minimum_visit)}rd`;
                                        default:
                                            return `${String(minimum_visit)}th`;
                                    }
                                })(),
                                " ",
                                "visit. Offer valid between",
                                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(startDate).toString()), "MMM do yyyy hh:mm a")} to ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(getDateObject(new Date(endDate).toString()), "MMM do yyyy hh:mm a")}`
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 250,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 270,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
            default:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Wrong Offer Type ...."
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 289,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Offer valid between ---- ----"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 290,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "*Terms And Conditions Apply"
                        }, void 0, false, {
                            fileName: "[project]/src/helpers/common.js",
                            lineNumber: 291,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true);
        }
    } catch (e) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: e.message
                }, void 0, false, {
                    fileName: "[project]/src/helpers/common.js",
                    lineNumber: 298,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Offer valid between ---- ----"
                }, void 0, false, {
                    fileName: "[project]/src/helpers/common.js",
                    lineNumber: 299,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "*Terms And Conditions Apply"
                }, void 0, false, {
                    fileName: "[project]/src/helpers/common.js",
                    lineNumber: 300,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true);
    }
};
const validateImage = (url)=>new Promise((resolve, reject)=>{
        const img = new Image(url);
        // eslint-disable-next-line no-multi-assign
        img.onerror = img.onabort = async function() {
            reject();
        };
        img.onload = function() {
            resolve();
        };
        img.src = url;
    });
const checkValidImageProtocol = (url)=>{
    if (/(http(s?)):\/\//i.test(url)) {
        return true;
    }
    return false;
};
const checkValidImageExtension = (url)=>{
    if ([
        "png",
        "PNG",
        "jpg",
        "JPG",
        "jpeg",
        "JPEG"
    ].includes(url.split(/[#?]/)[0].split(".").pop().trim())) {
        return true;
    }
    return false;
};
const checkInValidImage = async (url)=>{
    try {
        await validateImage(url);
        return !(checkValidImageExtension(url) && checkValidImageProtocol(url));
    } catch (ex) {
        return true;
    }
};
const convertToFormData = (obj)=>{
    const formData = new FormData();
    Object.keys(obj).forEach((key)=>{
        if (key === "bankInfo" || key === "inheritanceInfo" && typeof obj[key] === "object") {
            formData.append(key, JSON.stringify(obj[key]));
        } else {
            formData.append(key, obj[key]);
        }
    });
    return formData;
};
const convertDateToISO = (dateStr)=>{
    const [day, month, year] = dateStr.split("/");
    return `${year}-${month}-${day}`;
};
// Format the date
const getOrdinalSuffix = (day)=>{
    if (day > 3 && day < 21) return "th";
    switch(day % 10){
        case 1:
            return "st";
        case 2:
            return "nd";
        case 3:
            return "rd";
        default:
            return "th";
    }
};
const formatDateWithSuffix = (dateObj)=>{
    const date = new Date(dateObj);
    const day = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, "d"); // get the day without leading zeros
    const monthYear = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(date, "MMMM, yyyy"); // get the month and year
    const ordinalSuffix = getOrdinalSuffix(parseInt(day)); // get the ordinal suffix
    return `${day}${ordinalSuffix} ${monthYear}`;
};
const daysLeft = (dateObj)=>{
    const date = new Date(dateObj);
    const daysLeft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInCalendarDays$2e$js__$5b$client$5d$__$28$ecmascript$29$__["differenceInCalendarDays"])(date, new Date());
    return daysLeft < 10 ? `0${daysLeft} days` : `${daysLeft.toString()} days`;
// return formatDistanceToNow(date, {addSuffix: false});
};
const bas64toFile = async (dataUrl, fileName)=>{
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return new File([
        blob
    ], fileName, {
        type: "image/jpg"
    });
};
const checkAge = (birthdate)=>{
    let birthDate = new Date(birthdate);
    if (isNaN(birthDate)) {
        return "Invalid date format. Please enter a valid date.";
    }
    let today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    let monthDifference = today.getMonth() - birthDate.getMonth();
    let dayDifference = today.getDate() - birthDate.getDate();
    if (monthDifference < 0 || monthDifference === 0 && dayDifference < 0) {
        age--;
    }
    // Check if age is at least 18
    if (age >= 18) {
        return true;
    } else {
        return false;
    }
};
const removeSpaces = (str = "")=>{
    return str.replace(/ /g, "");
};
const debounce = (func, delay)=>{
    let timeoutId;
    return (...args)=>{
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
        timeoutId = setTimeout(()=>{
            func(...args);
        }, delay);
    };
};
const GeoCode = async (value)=>{
    try {
        const { results } = "object" !== "undefined" && await new window.google.maps.Geocoder().geocode(value);
        if (!results) {
            throw Error("Unable to load maps");
        }
        const { address_components, geometry, place_id, formatted_address, types } = results[0];
        const address = {};
        // eslint-disable-next-line no-shadow
        address_components?.forEach(({ short_name, types })=>{
            if (types.includes("administrative_area_level_1")) {
                address.state = short_name;
            } else if (types.includes("administrative_area_level_2")) {
                address.county = short_name;
            } else if (types.includes("locality")) {
                address.city = short_name;
            } else address[types[0]] = short_name;
        });
        return {
            ...address,
            types,
            place_id,
            latlng: {
                lat: geometry?.location?.lat(),
                lng: geometry?.location?.lng()
            },
            formatted_address
        };
    } catch (err) {
        throw Error(err?.message ?? "Unable to load maps");
    }
};
_c = GeoCode;
const formatDate = (date)=>{
    const offset = date.getTimezoneOffset();
    const localDate = new Date(date.getTime() - offset * 60 * 1000);
    return localDate.toISOString().split("T")[0];
};
const calculateTotalNights = (startDate, endDate)=>{
    // Parse the start and end dates into Date objects
    const start = new Date(startDate);
    const end = new Date(endDate);
    // Ensure the provided dates are valid
    if (isNaN(start) || isNaN(end)) {
        return "Invalid date format. Please provide valid dates.";
    }
    // Adjust check-in time to 3 PM (15:00) on the start date
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$setHours$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setHours"])(start, 15, 0, 0, 0); // Set check-in to 3 PM on the start date
    // Adjust check-out time to 11 AM (11:00) on the next day of the end date
    end.setDate(end.getDate()); // Move the checkout date to the next day
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$setHours$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setHours"])(end, 11, 0, 0, 0); // Set the checkout time to 11 AM on the next day
    // Ensure the check-out time is after the check-in time
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$isBefore$2e$js__$5b$client$5d$__$28$ecmascript$29$__["isBefore"])(end, start)) {
        return "Check-out time should be after check-in time.";
    }
    // Calculate the difference in days (inclusive of both dates)
    const totalNights = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$differenceInDays$2e$js__$5b$client$5d$__$28$ecmascript$29$__["differenceInDays"])(end, start);
    return totalNights;
};
var _c;
__turbopack_refresh__.register(_c, "GeoCode");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/helpers/fetchWrapper.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Fetch": (()=>Fetch)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/helpers/common.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
;
let trigger = false;
const debounceInterval = 1000;
let debounceTimeout;
function debounceFetch(url, requestOptions) {
    if (debounceTimeout) {
        clearTimeout(debounceTimeout);
    }
    return new Promise((resolve)=>{
        debounceTimeout = setTimeout(()=>{
            fetch(url, requestOptions).then((res)=>{
                resolve(handleResponse(res));
            });
        }, debounceInterval);
    });
}
function handleResponse(response) {
    if (response.status === 401 && !trigger && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))) {
        trigger = true;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["clearCookie"])(("TURBOPACK compile-time value", "intd_d"));
        // clearCookie(process.env.REACT_APP_ALLOWED_PAGES_COOKIE);
        window.location.reload();
    }
    return response;
}
function get(url, debounce = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "GET",
        headers
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function post(url, body, debounce = false, signUp = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: signUp ? "Bearer intd-secret-token" : `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "POST",
        headers,
        body: JSON.stringify(body)
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function upload(url, method, body) {
    const headers = {
        // 'Content-Type': 'multipart/form-data',
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: method === "POST" ? "POST" : "PUT",
        headers,
        body
    };
    return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function put(url, body, debounce = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "PUT",
        headers,
        body: JSON.stringify(body)
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function _delete(url, body, debounce = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "DELETE",
        headers,
        body: JSON.stringify(body)
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
function patch(url, body, debounce = false) {
    const headers = {
        "X-path": window.location.pathname,
        "Content-Type": "application/json",
        authorization: `Bearer ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["getCookie"])(("TURBOPACK compile-time value", "intd_d"))}`
    };
    const requestOptions = {
        method: "PATCH",
        headers,
        body: JSON.stringify(body)
    };
    if (debounce) return debounceFetch(url, requestOptions);
    else return fetch(url, requestOptions).then((res)=>handleResponse(res));
}
const Fetch = {
    get,
    post,
    put,
    delete: _delete,
    patch,
    upload
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/services/authService.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
const { Fetch } = __turbopack_require__("[project]/src/helpers/fetchWrapper.js [client] (ecmascript)");
const authService = {
    _url: `${("TURBOPACK compile-time value", "https://internationaldigitaldollar.com/user")}`,
    async login (payload) {
        let res = await Fetch.post(`${this._url}/login`, payload, false, true);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async fetchUserDetails () {
        let res = await Fetch.get(`${this._url}/get-user-details`);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async signUp (payload) {
        let res = await Fetch.post(`${this._url}/register`, payload, false, true);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async verifyEmail (payload) {
        let res = await Fetch.post(`${this._url}/verify-email`, payload, false, true);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async verifyKyc (formData) {
        let res = await Fetch.upload(`${this._url}/get-kyc-verified`, "POST", formData);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async forgotPassword (payload) {
        let res = await Fetch.post(`${this._url}/send-verification-email`, payload, false, true);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    },
    async resetPassword (payload) {
        let res = await Fetch.post(`${this._url}/set-password`, payload, false, false);
        if (res.status >= 200 && res.status < 300) {
            res = await res.json();
            return res;
        }
        const { message } = await res.json();
        throw new Error(message ?? "Something went wrong");
    }
};
const __TURBOPACK__default__export__ = authService;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/context/AuthContext.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "AuthContext": (()=>AuthContext),
    "AuthContextProvider": (()=>AuthContextProvider)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/molecules/Toast/index.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/helpers/common.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/services/authService.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/router.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])();
const AuthContextProvider = ({ children })=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"])();
    // 👇 This line is checking login state by cookie, we comment it to allow all access
    // const [isLoggedIn, setIsLoggedIn] = useState(!!getCookie(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE));
    const [isLoggedIn, setIsLoggedIn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(true); // 🔧 temporarily always logged in
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const verifyEmail = async (payload)=>{
        try {
            setLoading(true);
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].verifyEmail(payload);
            if (!res?.token) {
                throw new Error(res?.message);
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$helpers$2f$common$2e$js__$5b$client$5d$__$28$ecmascript$29$__["setCookie"])(("TURBOPACK compile-time value", "intd_d"), res?.token);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"])({
                    type: "success",
                    message: res.message
                });
                setLoading(false);
                return true;
            }
        } catch (err) {
            setLoading(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"])({
                type: "error",
                message: err.message
            });
        }
    };
    const onLogin = async ({ email, password })=>{
        setLoading(true);
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$authService$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].login({
                email,
                password
            });
            if (!res?.token) {
                throw new Error(res?.message);
            }
            // 👇 Commenting out actual login logic and redirects for now
            // setIsLoggedIn(true);
            // setCookie(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE, res?.token);
            // const userDetails = await authService.fetchUserDetails();
            // if (userDetails?.user?.status === "VERIFY_EMAIL") {
            //     router.push("/verify-email");
            //     Toast({type: "info", message: "Pleader Verify Your Email"});
            // }
            // if (userDetails?.user?.status === "KYC_VERIFICATION") {
            //     router.push("/kyc-verification");
            //     Toast({type: "info", message: "Pleader Verify Your KYC"});
            // }
            // if (userDetails?.user?.status === "KYC_VERIFICATION_INITIATED") {
            //     router.push("/kyc-verification-pending");
            // }
            // if (userDetails?.user?.status === "ACTIVE") {
            //     router.push("/");
            //     Toast({type: "success", message: "Login Successfully"});
            // }
            // 🔧 Just fake a successful login for now
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"])({
                type: "success",
                message: "Login bypassed (auth disabled)"
            });
            return true;
        } catch ({ message }) {
            setIsLoggedIn(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$molecules$2f$Toast$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"])({
                type: "error",
                message
            });
            return false;
        } finally{
            setLoading(false);
        }
    };
    const contextValue = {
        loading,
        verifyEmail,
        onLogin,
        isLoggedIn
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/AuthContext.js",
        lineNumber: 90,
        columnNumber: 5
    }, this);
};
_s(AuthContextProvider, "qlobW1yR7hRwA9eBS8dM8hud1Rk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AuthContextProvider;
var _c;
__turbopack_refresh__.register(_c, "AuthContextProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Otp/Otp.styles.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "OtpInputWrapper": (()=>OtpInputWrapper)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [client] (ecmascript)");
;
const OtpInputWrapper = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["styled"].div`
  max-width: ${({ $width })=>$width || "440px"};
  margin: 0 auto 20px;

  .otp-fields {
    width: 100%;
    display: flex;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 20px;

    /* @media (min-width: 576px) {
      gap: 20px;
    } */
  }

  input {
    width: 100%;
    max-width: ${({ $inputWidth })=>$inputWidth || "70px"};
    height: 50px;
    border: 1px solid transparent;
    background: var(--dark);
    color: var(--white);
    border-radius: 10px;
    padding: 10px;
    font-size: 28px;
    line-height: 32px;
    box-sizing: border-box;
    outline: none;
    text-align: center;

    @media (max-width: 576px) {
      height: 50px;
      padding: 10px 10px 5px;
      font-size: 20px;
      line-height: 24px;
    }

    &::placeholder {
      font-size: 35px;
      line-height: 20px;
      color: var(--white);
    }
  }

  input:focus::placeholder {
    color: transparent;
  }

  .timer {
    display: flex;
    align-items: center;
    justify-content: space-between;

    .resend-code {
      color: var(--golden);
      cursor: pointer;

      ${({ $disable })=>$disable && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
          pointer-events: none;
        `}
    }
  }
`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Otp/index.jsx [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/index.js [client] (ecmascript)");
// import { useTranslation } from "react-i18next";
// import { useDispatch } from "react-redux";
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Otp$2f$Otp$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Otp/Otp.styles.js [client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
;
;
// import { sendOTP } from "../../store/reducers/authSlice";
const OtpInput = ({ numInputs = 6, inputWidth, width, inputBg, noTimer, email, setOtpValue = ()=>{} })=>{
    _s();
    // const { t } = useTranslation();
    const [timeLeft, setTimeLeft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(30);
    const [otp, setOtp] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(new Array(numInputs).fill(""));
    const refs = [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])()
    ];
    // const dispatch = useDispatch();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OtpInput.useEffect": ()=>{
            const timer = setInterval({
                "OtpInput.useEffect.timer": ()=>{
                    setTimeLeft({
                        "OtpInput.useEffect.timer": (prevTime)=>{
                            if (prevTime <= 1) {
                                clearInterval(timer);
                                return 0;
                            }
                            return prevTime - 1;
                        }
                    }["OtpInput.useEffect.timer"]);
                }
            }["OtpInput.useEffect.timer"], 1000);
            // Cleanup timer on component unmount
            return ({
                "OtpInput.useEffect": ()=>clearInterval(timer)
            })["OtpInput.useEffect"];
        }
    }["OtpInput.useEffect"], []);
    const formatTime = (seconds)=>{
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
    };
    const handleChange = (index, value)=>{
        if (otp[index] !== "" && index + 1 === numInputs) {
            return;
        }
        if (otp[index] !== "") {
            if (refs[index + 1]?.current) {
                refs[index + 1].current.focus();
            }
            const newOtp = [
                ...otp
            ];
            const [, second] = value.split("");
            newOtp[index + 1] = second;
            setOtp(newOtp);
            setOtpValue(newOtp);
            return;
        }
        if (parseInt(value, 10) <= 9) {
            const newOtp = [
                ...otp
            ];
            newOtp[index] = value;
            setOtp(newOtp);
            setOtpValue(newOtp);
        }
        if (refs[index + 1]?.current) {
            refs[index + 1].current.focus();
        }
    };
    const handleKeyDown = (index, e)=>{
        if (e.key === "Backspace") {
            e.preventDefault(); // Prevent the default behavior to avoid unintended navigation
            // Clear the current input
            setOtp((prev)=>{
                const newOtp = [
                    ...prev
                ];
                newOtp[index] = ""; // Clear the current index
                return newOtp;
            });
            // Move focus to the previous input if available
            if (refs[index - 1]?.current) {
                refs[index - 1].current.focus();
            }
        }
    };
    const handleSubmit = async ()=>{
        // const res = await dispatch(sendOTP(email));
        // if (res?.payload?.success) {
        setTimeLeft(30);
    // }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Otp$2f$Otp$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__["OtpInputWrapper"], {
        $width: width,
        $inputWidth: inputWidth,
        $inputBg: inputBg,
        $disable: timeLeft > 0,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "otp-fields",
                children: otp.map((value, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        placeholder: "-",
                        type: "number",
                        maxLength: 1,
                        value: value,
                        onChange: (e)=>handleChange(index, e.target.value),
                        onKeyDown: (e)=>handleKeyDown(index, e),
                        ref: refs[index]
                    }, index, false, {
                        fileName: "[project]/src/components/Otp/index.jsx",
                        lineNumber: 109,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/Otp/index.jsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            noTimer ? "" : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "timer",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "resend-code",
                        onClick: handleSubmit,
                        children: "Resend OTP"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Otp/index.jsx",
                        lineNumber: 125,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            " ",
                            formatTime(timeLeft),
                            " "
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Otp/index.jsx",
                        lineNumber: 128,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Otp/index.jsx",
                lineNumber: 124,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Otp/index.jsx",
        lineNumber: 102,
        columnNumber: 5
    }, this);
};
_s(OtpInput, "go4L3DToG3tGBKTu2LBTa+CmY/M=");
_c = OtpInput;
const __TURBOPACK__default__export__ = OtpInput;
var _c;
__turbopack_refresh__.register(_c, "OtpInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Button/Button.styles.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "StyledButton": (()=>StyledButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [client] (ecmascript)");
;
const StyledButton = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].button`
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: ${({ $gap })=>$gap ? $gap : "5px"};
  padding: 12px 15px;
  border-radius: ${({ $rounded })=>$rounded ? "60px" : "8px"};
  font-size: 14px;
  line-height: 18px;
  font-weight: 400;
  width: ${({ $width })=>$width ? $width : "140px"};
  min-width: 140px;
  background: var(--off-white);
  color: var(--secondary);
  transition: 0.5s all ease-in-out;
  box-shadow: 0px 4px 3px 0px #ffffff45 inset, 0px -3px 5px 0px #ffffff40 inset;
  overflow: hidden;
  z-index: 1;

  @media (min-width: 768px) {
    font-size: 15px;
    line-height: 19px;
  }

  ${({ $loader, disabled })=>$loader || disabled && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
        cursor: not-allowed;
      `}

  ${({ $lg })=>$lg && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
      width: ${({ $width })=>$width ? $width : "200px"};
      padding: 15px;
    `}

  @media screen and (max-width:786px) {
    padding: 8px 15px;
  }
  /***** Background-Variants-Start *****/

  ${({ $variant })=>$variant == "secondary" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
        background: var(--primary);
        color: var(--secondary);
      ` || $variant == "outline" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
        background: var(--white);
        border: 1px solid var(--primary);
        color: var(--primary);
      ` || $variant == "danger" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
        background: var(--danger);
        color: var(--text-color);
      `}

  /*****************Background Variants End*********************/


  /*****************Border Variants Start*********************/

  ${({ $outline })=>$outline && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
      border: 1px solid var(--blue);
      background: transparent;
      color: var(--blue);
    `}
  /*****************Border Variants End*********************/

    .loader {
    width: 17px;
    height: 17px;
    border-radius: 50%;
    display: inline-block;
    border-top: 3px solid var(--secondary);
    border-right: 3px solid transparent;
    box-sizing: border-box;
    animation: rotation 1s linear infinite;
  }

  @keyframes rotation {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }

  &:before,
  &:after {
    content: "";
    position: absolute;
    height: 1px;
    width: 1px;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0);
    border-radius: 50%;
    z-index: -1;
  }

  &:before {
    display: none;
    background: var(--secondary);
    transition: 0.6s ease-in;
    transition-delay: 0.1s;
  }

  &:after {
    background: var(--primary);
    transition: 0.8s ease;
    transition-delay: 0.4s;

    ${({ $variant })=>$variant == "secondary" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
        background: var(--white);
      `}

    ${({ $variant })=>$variant == "danger" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__["css"]`
        background: #dc4320;
      `}
  }

  &:hover {
    &:before,
    &:after {
      transform: translate(-50%, -50%) scale(1000);
      z-index: -1;
    }
  }
`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Button/index.jsx [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$Button$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Button/Button.styles.js [client] (ecmascript)");
;
;
;
const Button = ({ children, gap, lg, outline, variant, width, loader, disabled, rounded, delayAnimation, ...rest })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$Button$2e$styles$2e$js__$5b$client$5d$__$28$ecmascript$29$__["StyledButton"], {
        $lg: lg,
        $outline: outline,
        $variant: variant,
        $gap: gap,
        $width: width,
        $delayAnimation: delayAnimation,
        $rounded: rounded,
        disabled: loader || disabled,
        ...rest,
        children: loader ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "loader"
        }, void 0, false, {
            fileName: "[project]/src/components/Button/index.jsx",
            lineNumber: 29,
            columnNumber: 17
        }, this) : children
    }, void 0, false, {
        fileName: "[project]/src/components/Button/index.jsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
};
_c = Button;
const __TURBOPACK__default__export__ = Button;
var _c;
__turbopack_refresh__.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/pages/verify-email.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginTemplate$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/LoginTemplate/index.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/context/AuthContext.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Otp$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Otp/index.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/Button/index.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/router.js [client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
;
;
;
;
;
const VerifyEmail = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [otpValue, setOtpValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(new Array(6).fill(""));
    const { verifyEmail } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$client$5d$__$28$ecmascript$29$__["AuthContext"]);
    async function handelVerifyEmail() {
        const userEmail = sessionStorage.getItem("userEmail");
        const payload = {
            email: userEmail,
            code: otpValue.join("")
        };
        const success = await verifyEmail(payload);
        if (success) {
            router.push("/kyc-verification");
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginTemplate$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "heading",
                children: "Verify OTP!"
            }, void 0, false, {
                fileName: "[project]/src/pages/verify-email.js",
                lineNumber: 27,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "We’ve sent an 5-digit otp to your mail johnduo@gmail.com"
            }, void 0, false, {
                fileName: "[project]/src/pages/verify-email.js",
                lineNumber: 28,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Otp$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                setOtpValue: setOtpValue
            }, void 0, false, {
                fileName: "[project]/src/pages/verify-email.js",
                lineNumber: 29,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Button$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                width: "100%",
                onClick: handelVerifyEmail,
                children: "Verify OTP"
            }, void 0, false, {
                fileName: "[project]/src/pages/verify-email.js",
                lineNumber: 30,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/pages/verify-email.js",
        lineNumber: 26,
        columnNumber: 9
    }, this);
};
_s(VerifyEmail, "mYzyynESAn4K63asnOQvCnqzK8E=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = VerifyEmail;
const __TURBOPACK__default__export__ = VerifyEmail;
var _c;
__turbopack_refresh__.register(_c, "VerifyEmail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/verify-email.js [client] (ecmascript)\" } [client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const PAGE_PATH = "/verify-email";
(window.__NEXT_P = window.__NEXT_P || []).push([
    PAGE_PATH,
    ()=>{
        return __turbopack_require__("[project]/src/pages/verify-email.js [client] (ecmascript)");
    }
]);
// @ts-expect-error module.hot exists
if (module.hot) {
    // @ts-expect-error module.hot exists
    module.hot.dispose(function() {
        window.__NEXT_P.push([
            PAGE_PATH
        ]);
    });
}
}}),
"[project]/src/pages/verify-email (hmr-entry)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_require__("[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/verify-email.js [client] (ecmascript)\" } [client] (ecmascript)");
}}),
}]);

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__a22835._.js.map