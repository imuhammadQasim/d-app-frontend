(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_donate-money_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_donate-money_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__8944b7._.js",
    "static/chunks/node_modules_next_8233f5._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_bf0636._.js",
    "static/chunks/node_modules_f3b6b9._.js",
    "static/chunks/node_modules_react-icons_md_index_mjs_57194a._.js",
    "static/chunks/node_modules_react-icons_io_index_mjs_0372f8._.js",
    "static/chunks/node_modules_react-icons_rx_index_mjs_424fb2._.js",
    "static/chunks/node_modules_react-icons_io5_index_mjs_e31071._.js",
    "static/chunks/node_modules_react-icons_tb_index_mjs_68ac2a._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e._.js",
    "static/chunks/node_modules_react-icons_lib_75a63d._.js",
    "static/chunks/node_modules_@floating-ui_react_dist_f42242._.js",
    "static/chunks/node_modules_react-datepicker_dist_react-datepicker_min_403fe8.js",
    "static/chunks/node_modules_libphonenumber-js_f0794c._.js",
    "static/chunks/node_modules_react-phone-number-input_777b26._.js",
    "static/chunks/node_modules_react-select_341f0e._.js",
    "static/chunks/node_modules_8c53ee._.js",
    "static/chunks/_7d4a2b._.css"
  ],
  "source": "entry"
});
