(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_verify-email_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_verify-email_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_171db7._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_react-icons_rx_index_mjs_424fb2._.js",
    "static/chunks/node_modules_react-icons_io_index_mjs_0372f8._.js",
    "static/chunks/node_modules_react-icons_io5_index_mjs_e31071._.js",
    "static/chunks/node_modules_react-icons_lib_75a63d._.js",
    "static/chunks/node_modules_1cc960._.js",
    "static/chunks/[root of the server]__a22835._.js"
  ],
  "source": "entry"
});
