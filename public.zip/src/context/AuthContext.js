import Toast from "@/components/molecules/Toast";
import { getCookie, setCookie } from "@/helpers/common";
import authService from "@/services/authService";
import { useRouter } from "next/router";
import React, { createContext, useState } from "react";

export const AuthContext = createContext();
export const AuthContextProvider = ({ children }) => {
  const router = useRouter();

  // 👇 This line is checking login state by cookie, we comment it to allow all access
  // const [isLoggedIn, setIsLoggedIn] = useState(!!getCookie(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE));
  const [isLoggedIn, setIsLoggedIn] = useState(true); // 🔧 temporarily always logged in

  const [loading, setLoading] = useState(false);

  const verifyEmail = async (payload) => {
    try {
      setLoading(true);
      const res = await authService.verifyEmail(payload);
      if (!res?.token) {
        throw new Error(res?.message);
      } else {
        setCookie(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE, res?.token);
        Toast({ type: "success", message: res.message });
        setLoading(false);
        return true;
      }
    } catch (err) {
      setLoading(false);
      Toast({ type: "error", message: err.message });
    }
  };

  const onLogin = async ({ email, password }) => {
    setLoading(true);
    try {
      const res = await authService.login({
        email,
        password,
      });
      if (!res?.token) {
        throw new Error(res?.message);
      }

      // 👇 Commenting out actual login logic and redirects for now
      // setIsLoggedIn(true);
      // setCookie(process.env.NEXT_PUBLIC_CRM_TOKEN_COOKIE, res?.token);
      // const userDetails = await authService.fetchUserDetails();

      // if (userDetails?.user?.status === "VERIFY_EMAIL") {
      //     router.push("/verify-email");
      //     Toast({type: "info", message: "Pleader Verify Your Email"});
      // }

      // if (userDetails?.user?.status === "KYC_VERIFICATION") {
      //     router.push("/kyc-verification");
      //     Toast({type: "info", message: "Pleader Verify Your KYC"});
      // }

      // if (userDetails?.user?.status === "KYC_VERIFICATION_INITIATED") {
      //     router.push("/kyc-verification-pending");
      // }

      // if (userDetails?.user?.status === "ACTIVE") {
      //     router.push("/");
      //     Toast({type: "success", message: "Login Successfully"});
      // }

      // 🔧 Just fake a successful login for now
      Toast({ type: "success", message: "Login bypassed (auth disabled)" });
      return true;
    } catch ({ message }) {
      setIsLoggedIn(false);
      Toast({ type: "error", message });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const contextValue = {
    loading,
    verifyEmail,
    onLogin,
    isLoggedIn,
  };

  return (
    <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
  );
};
