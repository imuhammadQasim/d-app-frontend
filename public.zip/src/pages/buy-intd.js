import BuyIntd from "@/components/BuyIntd";
import React from "react";

const BuyINTD = () => {
  return (
    <div>
      <BuyIntd />
    </div>
  );
};

export default BuyINTD;
