import LoginTemplate from "@/components/LoginTemplate";
import {AuthContext} from "@/context/AuthContext";
import OtpInput from "@/components/Otp";
import React, {useContext, useState} from "react";
import Button from "@/components/Button";
import {useRouter} from "next/router";

const VerifyEmail = () => {
    const router = useRouter();
    const [otpValue, setOtpValue] = useState(new Array(6).fill(""));
    const {verifyEmail} = useContext(AuthContext);

    async function handelVerifyEmail() {
        const userEmail = sessionStorage.getItem("userEmail");
        const payload = {
            email: userEmail,
            code: otpValue.join(""),
        };
        const success = await verifyEmail(payload);
        if (success) {
            router.push("/kyc-verification");
        }
    }

    return (
        <LoginTemplate>
            <span className="heading">Verify OTP!</span>
            <p>We’ve sent an 5-digit otp to your mail johnduo@gmail.com</p>
            <OtpInput setOtpValue={setOtpValue} />
            <Button width="100%" onClick={handelVerifyEmail}>
                Verify OTP
            </Button>
        </LoginTemplate>
    );
};

export default VerifyEmail;
