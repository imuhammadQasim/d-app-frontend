import React from "react";
import emailIcon from "@/assets/images/email-icon.svg";
import passwordIcon from "@/assets/images/password-icon.svg";
import LoginTemplate from "@/components/LoginTemplate";
import Field from "@/components/molecules/Field";
import Form from "@/components/molecules/Form/Form";
import {useForm} from "@/components/molecules/Form";
import Button from "@/components/Button";
import Image from "next/image";
import Link from "next/link";
import authService from "@/services/authService";
import Toast from "@/components/molecules/Toast";
import {useRouter} from "next/router";

const signUp = () => {
    const [form] = useForm();
    const router = useRouter();

    async function handleSubmit(e) {
        const payload = {
            first_name: e.first_name,
            last_name: e.last_name,
            email: e.email,
            password: e.confirm_password,
        };
        try {
            const res = await authService.signUp(payload);
            sessionStorage.setItem("userEmail", e.email);
            Toast({
                type: "success",
                message: res.message,
            });
            router.push("/verify-email");
        } catch (error) {
            Toast({type: "error", message: error.message});
        }
    }

    return (
        <LoginTemplate>
            <Form form={form} onSubmit={handleSubmit}>
                <span className="heading">Create Account!</span>
                <p>Kindly provide the following details to proceed with your account creation request.</p>
                <div className="sign-up-head">
                    <Form.Item
                        label="First Name"
                        type="text"
                        name="first_name"
                        placeholder="Enter first name"
                        rules={[
                            {
                                required: true,
                                message: "Please enter first name",
                            },
                        ]}>
                        <Field />
                    </Form.Item>
                    <Form.Item
                        label="Last Name"
                        type="text"
                        name="last_name"
                        placeholder="Enter last name"
                        rules={[
                            {
                                required: true,
                                message: "Please enter last name ",
                            },
                        ]}>
                        <Field />
                    </Form.Item>
                </div>
                <Form.Item
                    label="Email Address"
                    type="email"
                    name="email"
                    placeholder="Enter email address"
                    prefix={<Image src={emailIcon} alt="emailIcon" />}
                    rules={[
                        {
                            required: true,
                            message: "Please enter your email address ",
                        },
                    ]}>
                    <Field />
                </Form.Item>
                <Form.Item
                    label="New Password"
                    type="password"
                    name="new_password"
                    placeholder="Enter new password"
                    prefix={<Image src={passwordIcon} alt="passwordIcon" />}
                    rules={[
                        {
                            required: true,
                        },
                        {password: true},
                    ]}>
                    <Field />
                </Form.Item>
                <Form.Item
                    label="Confirm Password"
                    type="password"
                    name="confirm_password"
                    placeholder="confirm new password"
                    prefix={<Image src={passwordIcon} alt="passwordIcon" />}
                    rules={[
                        {
                            required: true,
                        },
                        {
                            transform: value => value !== form.getFieldValue("new_password"),
                        },
                    ]}>
                    <Field />
                </Form.Item>
                <Button width="100%" className="btn">
                    Create my Account
                </Button>
                <span className="create-account">
                    Already have an account?&nbsp;
                    <Link href="/login">Sign In</Link>
                </span>
            </Form>
        </LoginTemplate>
    );
};

export default signUp;
