import WalletChart from "@/components/Dashboard/WalletChart";
import React from "react";
import dynamic from "next/dynamic";
import LiveGraph from "@/components/Dashboard/LiveGraph";
import PromotionalRewards from "@/components/Dashboard/PromotionalRewards";
import { StyledDashboard } from "@/components/Dashboard/Dashboard.styles";
import Loader from "@/components/Loader";

const PromotionsMap = dynamic(
  () => import("@/components/Dashboard/PromotionMap"),
  {
    ssr: false,
  }
);
const index = () => {
  return (
    <StyledDashboard>
      <div className="graph-holder">
        <div className="head">
          <WalletChart />
          <PromotionsMap />
        </div>
        <LiveGraph />
      </div>
      <div className="promotions">
        <PromotionalRewards />
      </div>
    </StyledDashboard>
  );
};

export default index;
