// import React from "react";
// import LoginTemplate from "@/components/LoginTemplate";
// import Image from "next/image";
// import logo from "/_next/static/media/logo.b8e2b55a.svg";

// const paymentMethod = () => {
//   return (
//     <LoginTemplate>
//       <Image src={logo} alt="" />
//       <h4>Complete Your Subscription</h4>
//       <p>
//         Subscribe for just <span> $4.99 </span> and gain access to exclusive
//         early access features.
//       </p>
//       <div className="paymentCart">
//         <p>Choose Payment Method</p>
//         <label>
//           <input
//             type="radio"
//             value="option1"
//             checked={selected === "option1"}
//             onChange={() => setSelected("option1")}
//           />
//           Pay with Credit Card (Stripe)
//         </label>
//         <label>
//           <input
//             type="radio"
//             value="option1"
//             checked={selected === "option1"}
//             onChange={() => setSelected("option1")}
//           />
//           Pay with USDT (Crypto Wallet)
//         </label>
//       </div>
//     </LoginTemplate>
//   );
// };

// export default paymentMethod;

import React from "react";

const PaymentMethod = () => {
  return <div>hello</div>;
};

export default PaymentMethod;
