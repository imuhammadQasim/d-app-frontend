import React from "react";
import { StyledLoader } from "./Loader.styles";

const Loader = () => {
  return (
    <StyledLoader>
      <span class="loader"></span>
    </StyledLoader>
  );
};

export default Loader;
