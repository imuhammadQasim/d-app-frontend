const DOTS = '...';
export default DOTS;
