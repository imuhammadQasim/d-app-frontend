import styled from "styled-components";

export const StyledIcon = styled.span`
  font-size: 1.625rem;
  line-height: 1;
  margin-right: 1.125rem;
`;
