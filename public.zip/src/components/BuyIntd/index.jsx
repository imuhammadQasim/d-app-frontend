import React, {useContext, useState} from "react";
import {StyledBuyIntd} from "./BuyIntd.styles";
import arrow from "@/assets/images/bidirectional-arrow.svg";
import logo from "@/assets/images/logo-sm.svg";
import cardIcon from "@/assets/images/card-icon.svg";
import infoIcon from "@/assets/images/info-icon.svg";
import Image from "next/image";
import Button from "../Button";
import {useRouter} from "next/router";
import Form from "../molecules/Form/Form";
import Field from "../molecules/Field";
import {useForm} from "../molecules/Form";
import Process from "../Process";
import {SubmitContext} from "@/context/SubmitContext";

const currencies = [
    {
        label: "USD",
        value: "USD",
        symbol: "$",
    },
    {
        label: "EUR",
        value: "EUR",
        symbol: "€",
    },
];
const BuyIntd = () => {
    const {form} = useForm();
    const router = useRouter();
    const [currency, setCurrency] = useState(currencies[0]);
    const [step, setStep] = useState(1);
    const {handleData} = useContext(SubmitContext);

    const processObj = {
        heading: "Request in Process...",
        text: "Your password reset request is in processing, \nplease wait a bit.",
        inProcess: true,
    };
    const success = {
        heading: "Payment Successful!",
        text: "Congratulations! Your purchase of 50 INTD$ \nwas successful",
        btnText: "Go to Dashboard!",
        onClick: () => router.push("/"),
    };

    function handleSubmit() {
        handleData(processObj);
        setTimeout(() => {
            handleData(success);
        }, 3000);
    }

    return (
        <>
            <StyledBuyIntd>
                {step === 1 && (
                    <div className="wrapper">
                        <h1 className="h3">Buy INTD$!</h1>

                        <div className="cards-holder">
                            <div className="card">
                                <span className="head-text">You Pay</span>
                                <div className="currency-holder">
                                    <div className="select">
                                        <Field
                                            type="select"
                                            value={currency}
                                            options={currencies}
                                            onChange={e => setCurrency(e.target.value)}
                                            prefix={currency.symbol}
                                        />
                                    </div>
                                    <h3>
                                        50.00 <span>USDT</span>
                                    </h3>
                                </div>
                                <span className="text">
                                    The current exchange rate is $1 (USDT) equivalent to 1.00 <br />
                                    International Digital Dollars (INTD$)
                                </span>
                            </div>
                            <div className="arrow-holder">
                                <figure className="icon-holder">
                                    <Image src={arrow} alt="arrow" />
                                </figure>
                            </div>
                            <div className="card">
                                <span className="head-text">You Get</span>
                                <div className="currency-holder">
                                    <div className="currency-name">
                                        <figure className="img-holder">
                                            <Image src={logo} alt="dollarCoin" />
                                        </figure>
                                        <span className="heading">INTD$</span>
                                    </div>
                                    <h3>
                                        50.00 <span>INTD$</span>
                                    </h3>
                                </div>
                                <span className="text">
                                    You will receive 50.00 INTD$, with a processing time of <br />
                                    approximately 05 minutes.
                                </span>
                            </div>
                        </div>
                        <div className="btn-holder">
                            <Button width="400px" type="submit" onClick={() => setStep(2)}>
                                Buy INTD$
                            </Button>
                        </div>
                        <div className="btn-holder">
                            <button onClick={() => router.push("/")}>Go Back!</button>
                        </div>
                    </div>
                )}
                {step === 2 && (
                    <div className="wrapper">
                        <h1 className="h3">Add Card Details!</h1>
                        <Form form={form} onSubmit={handleSubmit}>
                            <div className="form-holder">
                                <Form.Item
                                    label="Name on Card"
                                    type="text"
                                    name="name"
                                    placeholder="Enter name on card"
                                    rules={[
                                        {
                                            required: true,
                                            message: "Please enter your name",
                                        },
                                    ]}>
                                    <Field />
                                </Form.Item>
                                <Form.Item
                                    label="Card Number"
                                    type="number"
                                    name="card_number"
                                    placeholder="Enter card number"
                                    suffix={<Image src={cardIcon} alt="walletIcon" />}
                                    rules={[
                                        {
                                            required: true,
                                            message: "Please enter your card number ",
                                        },
                                    ]}>
                                    <Field />
                                </Form.Item>
                                <div className="input-holder">
                                    <Form.Item
                                        label="Expiry"
                                        type="number"
                                        name="expiry"
                                        placeholder="MM/YY"
                                        rules={[
                                            {
                                                required: true,
                                                message: "Please enter expiry date ",
                                            },
                                        ]}>
                                        <Field />
                                    </Form.Item>
                                    <Form.Item
                                        label="CVC"
                                        type="number"
                                        name="cvc"
                                        placeholder="Enter cvc number"
                                        suffix={<Image src={infoIcon} alt="infoIcon" />}
                                        rules={[
                                            {
                                                required: true,
                                                message: "Please enter cvc ",
                                            },
                                        ]}>
                                        <Field />
                                    </Form.Item>
                                </div>
                                <Form.Item
                                    label="Save card details for future purchases."
                                    type="checkbox"
                                    name="save_card_details"
                                    noMargin>
                                    <Field />
                                </Form.Item>
                            </div>
                            <div className="btn-holder">
                                <Button width="400px" onClick={() => setStep(2)}>
                                    Buy INTD$
                                </Button>
                            </div>
                            <div className="btn-holder">
                                <button onClick={() => setStep(1)}>Go Back!</button>
                            </div>
                        </Form>
                    </div>
                )}
            </StyledBuyIntd>
        </>
    );
};

export default BuyIntd;
