import styled from "styled-components";

export const StyledLoginTemplate = styled.div`
  display: flex;
  gap: 10px;
  padding: 15px;
  min-height: 100vh;

  .form-section {
    width: 100%;
    display: flex;
    align-items: center;
    @media (min-width: 992px) {
      width: 50%;
    }

    .form-holder {
      width: 100%;
      max-width: 400px;
      margin: 0 auto;

      .heading {
        display: block;
        font-size: 28px;
        line-height: 32px;
        font-weight: 700;
        text-align: center;
        margin: 0 0 16px;
      }

      .logo-holder {
        width: 100%;
        max-width: 260px;
        margin: 0 auto 16px;

        img {
          display: block;
          width: 100%;
          height: auto;
        }
      }

      p {
        text-align: center;
        margin: 0 0 25px;
      }
    }
  }

  .img-holder {
    width: 50%;
    border-radius: 30px;
    background: linear-gradient(to bottom, #2b4731 0%, #49724f 100%);
    position: relative;
    overflow: hidden;
    user-select: none;
    display: none;

    @media (min-width: 992px) {
      display: block;
    }

    img {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      display: block;
      max-width: 100%;
      height: auto;
    }
  }

  .login-form-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 0 0 25px;

    a {
      flex-shrink: 0;
      color: var(--golden);
    }
  }

  .btn {
    margin: 10px 0 20px;
  }

  .create-account {
    display: block;
    text-align: center;

    a {
      font-weight: 600;
      color: var(--primary);
      text-decoration: underline;
    }
  }

  .sign-up-head {
    display: flex;
    gap: 16px;
  }
`;
