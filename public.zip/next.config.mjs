/** @type {import('next').NextConfig} */
const nextConfig = {
    reactStrictMode: true,
    experimental: {
        disableFastRefresh: true,
    },
};

export default nextConfig;
